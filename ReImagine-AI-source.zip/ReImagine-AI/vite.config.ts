import { createHash } from 'node:crypto'
import { readdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import react from '@vitejs/plugin-react'
import tailwind from '@tailwindcss/vite'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  plugins: [
    react(),
    tailwind(),
    {
      name: 'offline-application-shell',
      apply: 'build',
      async writeBundle(options) {
        const output = resolve(options.dir ?? 'dist')
        const files = (await readdir(output, { recursive: true, withFileTypes: true }))
          .filter(entry => entry.isFile() && entry.name !== 'sw.js' && !entry.name.endsWith('.map'))
          .map(entry => resolve(entry.parentPath, entry.name).slice(output.length).replaceAll('\\', '/'))
          .sort()
        const version = createHash('sha256')
        for (const file of files) version.update(await readFile(resolve(output, '.' + file)))
        const worker = await readFile(resolve('src/config/offline.js'), 'utf8')
        version.update(worker)
        await writeFile(resolve(output, 'sw.js'),
          'const SHELL = ' + JSON.stringify(files) + ';\nconst VERSION = ' +
          JSON.stringify(version.digest('hex').slice(0, 12)) + ';\n' + worker)
      },
    },
  ],
  test: { include: ['src/**/*.test.ts', 'src/**/*.test.tsx'] },
})
