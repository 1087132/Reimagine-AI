import type { ConstructionGuide, ObjectAnalysis, TransformationConcept } from '../types/ai'

export type Example = {
  id: string
  before: string
  after: string
  analysis: ObjectAnalysis
  concept: TransformationConcept
  guide: ConstructionGuide
}

const herb: TransformationConcept = {
  title: 'Windowsill Herb Garden',
  description: 'Give an old wooden tool caddy a fresh purpose as a portable garden for the herbs you use most.',
  difficulty: 'Beginner', duration: '30–45 minutes', costMin: 0, costMax: 25, currency: 'AED', category: 'Garden and outdoor',
  materials: ['Used wooden tool caddy', 'Three nursery pots with saucers', 'Herbs in suitable potting mix'],
  tools: ['Cleaning cloth', 'Measuring tape'],
  benefits: ['Keeps one wooden caddy in use', 'Reuses nursery pots and saucers'],
  limitations: ['Needs a stable shelf with suitable daylight', 'Fit depends on your caddy dimensions'],
  safety: ['Use stable, untreated or known-safe wood. Keep edible herbs in separate pots and skip caddies with chemical residue.'],
}
const jars: TransformationConcept = {
  title: 'Glass Jar Propagation Station',
  description: 'Turn a set of empty jam jars into a windowsill station for growing new plants from cuttings.',
  difficulty: 'Beginner', duration: '15–25 minutes', costMin: 0, costMax: 10, currency: 'AED', category: 'Home decoration',
  materials: ['Clean jam jars', 'Suitable houseplant cuttings', 'Water'],
  tools: ['Cleaning cloth', 'Clean plant scissors'],
  benefits: ['Extends the useful life of several glass jars', 'Makes use of cuttings from a plant you have'],
  limitations: ['Choose cuttings suited to water propagation', 'Avoid direct sun that can overheat the water'],
  safety: ['Check for chips and cracks. Keep breakable glass away from pets, children, and shelf edges.'],
}
function example(
  id: string, name: string, material: string, condition: string, concept: TransformationConcept,
  steps: ConstructionGuide['steps'], maintenance: string,
): Example {
  return {
    id, before: '/images/' + id + '-before.jpg', after: '/images/' + id + '-after.jpg',
    concept,
    analysis: {
      name, category: 'Household item', materials: [material], condition, components: [name],
      damage: [], potential: concept.description, safety: concept.safety, confidence: 'medium',
      uncertainty: 'Example artwork. Check the condition and dimensions of your own object before starting.',
    },
    guide: {
      overview: concept.description, originalObject: name, transformation: concept.title,
      materials: concept.materials, tools: concept.tools,
      preparation: ['Gather what you already own. Clean the original object and let it dry. Measure the space where the project will sit.'],
      steps,
      finishing: ['Set the finished project on an even surface. Leave room around it for normal care.'],
      safety: concept.safety, cost: 'Estimated ' + concept.currency + ' ' + concept.costMin + '–' + concept.costMax + ', depending on materials you own.',
      duration: concept.duration,
      alternatives: ['Repurpose clean containers you already have of a suitable size.'],
      maintenance: [maintenance],
    },
  }
}

export const examples = [
  example('herb', 'Wooden tool caddy', 'Wood', 'Weathered wood with an intact handle', herb, [
    { title: 'Inspect and clean the caddy', instructions: 'Check that it sits flat and the handle is secure. Wipe it clean and let it dry.' },
    { title: 'Check the fit of the pots', instructions: 'Measure the inside width. Arrange the nursery pots with their saucers so each can lift out easily.' },
    { title: 'Set up your herb garden', instructions: 'Put the potted herbs into the caddy and set it on a stable, bright shelf. Water each pot as needed.' },
  ], 'Water the pots individually and empty the saucers. Wipe away spills to protect the wood.'),
  example('jars', 'Three glass jam jars', 'Glass', 'Intact clear glass with lids removed', jars, [
    { title: 'Wash and inspect each jar', instructions: 'Wash away any food and label residue. Set aside jars with cracks or chips.' },
    { title: 'Prepare the cuttings', instructions: 'Take a cutting from a plant suitable for water propagation. Keep the leaves above the waterline.' },
    { title: 'Arrange the station', instructions: 'Pour in enough water to cover the lower node. Set the jars on a stable surface with bright indirect light.' },
  ], 'Replace the water when it looks cloudy. Pot the rooted cuttings when they are ready for soil.'),
]
