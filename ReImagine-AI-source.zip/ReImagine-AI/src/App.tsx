import { useEffect, useRef, useState } from 'react'
import { Check, CircleAlert } from 'lucide-react'
import { motion, useReducedMotion } from 'framer-motion'
import { Home, routeNames, Shell, urlFor, type Route } from './components/Shell'
import { examples } from './config/examples'
import { AccountPage, SettingsPage, defaultPrivacySettings, privacySettingsSchema, type PrivacySettings } from './pages/Preferences'
import Scanner from './pages/Scanner'
import { ComparePage, Concepts, EmptyStudio, GuidePage, ImageStudio, ProjectOverview } from './pages/Studio'
import { Workshop, type WorkshopRoute, type CombinationInput } from './pages/Workshop'
import { analyzeObject, askAssistant, clearInferenceEvents, generateConcepts, generateGuide, generateImage, getInferenceEvents, getLocalAvailability, subscribeInferenceEvents } from './services/ai'
import { clearCloudData, defaultFlags, deleteAccount, firebaseCloudReady, loadFeatureFlags, observeAuth, syncCloudRecords } from './services/firebase'
import { useWorkshopData, type DeletedRecord, type InventoryItem, type Project, type SustainabilityRecord, type Tombstones } from './services/storage/workshop'
import type { AIOptions, FeatureFlags, LocalAvailability, ObjectAnalysis, TransformationConcept, UserProfile } from './types/ai'
import { asDataUrl } from './utils/media'

const workRoutes = new Set<Route>(['inventory', 'combine', 'rescue', 'budget', 'projects', 'impact', 'transparency', 'help'])
type Scan = { analysis: ObjectAnalysis; originalImage: string; notes: string; private: boolean }
type SharedRecord = Project | InventoryItem | SustainabilityRecord | DeletedRecord

function navigate(route: Route) {
  if (window.location.hash === urlFor(route)) window.scrollTo(0, 0)
  else window.location.hash = urlFor(route)
}

function currentRoute(): Route {
  const page = window.location.hash.replace(/^#\/?/, '')
  return Object.hasOwn(routeNames, page) ? page as Route : 'home'
}

function preferencesKey(scope: string) { return 'reimagine:preferences:' + scope }
function readSettings(scope: string): PrivacySettings {
  try {
    const result = privacySettingsSchema.safeParse(JSON.parse(localStorage.getItem(preferencesKey(scope)) || 'null'))
    if (result.success) return result.data
  } catch { /* Use conservative defaults when preferences are inaccessible. */ }
  return defaultPrivacySettings
}

const errorText = (error: unknown) => error instanceof Error ? error.message : 'The request did not finish. Try again.'
const time = () => new Date().toISOString()
const isDeleted = <T extends SharedRecord>(record: T): record is Extract<T, DeletedRecord> => 'deleted' in record && record.deleted

function newProject(concept: TransformationConcept, details: Partial<Project> = {}): Project {
  const started = time()
  return {
    id: crypto.randomUUID(), title: concept.title, concept, completedSteps: [], status: 'planned', private: false,
    createdAt: started, updatedAt: started, ...details,
  }
}

async function exampleAsset(url: string) {
  const response = await fetch(url)
  if (!response.ok) throw new Error('The example artwork could not be loaded.')
  return asDataUrl(await response.blob())
}

export default function App() {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [flags, setFlags] = useState<FeatureFlags>(defaultFlags)
  const [online, setOnline] = useState(navigator.onLine)
  const [route, setRoute] = useState(currentRoute)

  useEffect(() => observeAuth(setProfile), [])
  useEffect(() => {
    let live = true
    void loadFeatureFlags().then(flags => { if (live) setFlags(flags) })
    return () => { live = false }
  }, [online])
  useEffect(() => {
    const update = () => setOnline(navigator.onLine)
    const location = () => { setRoute(currentRoute()); window.scrollTo(0, 0) }
    window.addEventListener('online', update)
    window.addEventListener('offline', update)
    window.addEventListener('hashchange', location)
    return () => {
      window.removeEventListener('online', update)
      window.removeEventListener('offline', update)
      window.removeEventListener('hashchange', location)
    }
  }, [])
  return <Workspace key={profile?.uid ?? 'guest'} profile={profile} flags={flags} online={online} route={route} />
}

function Workspace({ profile, flags, online, route }: { profile: UserProfile | null; flags: FeatureFlags; online: boolean; route: Route }) {
  const scope = profile?.uid ?? 'guest'
  const [settings, setPreferences] = useState(() => readSettings(scope))
  const [local, setLocal] = useState<LocalAvailability>('unknown')
  const [downloadProgress, setDownloadProgress] = useState<number>()
  const [notice, setNotice] = useState<{ message: string; error?: boolean }>()
  const [pending, setPending] = useState(false)
  const running = useRef(false)
  const live = useRef(true)
  const [scan, setScan] = useState<Scan>()
  const [concepts, setConcepts] = useState<TransformationConcept[]>([])
  const [selected, setSelected] = useState<Project>()
  const projectRef = useRef<Project | undefined>(undefined)
  const [events, setEvents] = useState(getInferenceEvents)
  const { data, tombstones, ready, error, updateInventory, updateProject, updateImpact, mergeRemote, clearData } = useWorkshopData(scope)
  const reducedMotion = useReducedMotion()
  const [syncState, setSyncState] = useState('')
  const [syncTick, setSyncTick] = useState(0)
  const syncRunning = useRef(false)
  const syncConsent = useRef(false)
  const latestData = useRef({ data, tombstones })
  latestData.current = { data, tombstones }
  const allowSync = !!profile && online && firebaseCloudReady && flags.enableCloudSync && settings.cloudSync && settings.mode !== 'private'
  syncConsent.current = allowSync
  const sharedRevision = (['projects', 'inventory', 'impact'] as const).flatMap(collection =>
    [...data[collection], ...(tombstones[collection] ?? [])]
      .filter(item => !('private' in item && item.private) && !('example' in item && item.example))
      .map(item => collection + '/' + item.id + '/' + item.updatedAt)
  ).sort().join('|')

  useEffect(() => {
    live.current = true
    return () => { live.current = false; syncConsent.current = false }
  }, [])
  useEffect(() => subscribeInferenceEvents(() => setEvents(getInferenceEvents())), [])
  useEffect(() => {
    const color = window.matchMedia('(prefers-color-scheme: dark)')
    const update = () => {
      const theme = settings.theme === 'system' ? color.matches ? 'dark' : 'light' : settings.theme
      document.documentElement.dataset.theme = theme
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#151b17' : '#f8f7f2')
    }
    update()
    color.addEventListener('change', update)
    return () => color.removeEventListener('change', update)
  }, [settings.theme])
  useEffect(() => {
    let mounted = true
    let check: number | undefined
    const poll = async () => {
      try {
        const value = await getLocalAvailability()
        if (mounted) {
          setLocal(value)
          check = window.setTimeout(poll, ['downloading', 'downloadable'].includes(value) ? 3500 : 15000)
        }
      } catch { if (mounted) setLocal('unknown') }
    }
    void poll()
    return () => { mounted = false; clearTimeout(check) }
  }, [online])
  useEffect(() => { setNotice(undefined) }, [route])
  useEffect(() => {
    if (!allowSync) return
    const timer = window.setInterval(() => setSyncTick(value => value + 1), 60000)
    return () => window.clearInterval(timer)
  }, [allowSync])
  useEffect(() => {
    if (!allowSync || !ready || !profile) return
    const uid = profile.uid
    let active = true
    const start = window.setTimeout(async function synchronize() {
      if (!active || !syncConsent.current) return
      if (syncRunning.current) { setSyncTick(value => value + 1); return }
      syncRunning.current = true
      setSyncState('Syncing project records…')
      const { data, tombstones } = latestData.current
      const options = { allowMedia: settings.allowMediaSync, isAllowed: () => active && syncConsent.current && live.current }
      try {
        const [projects, inventory, impact] = await Promise.all([
          syncCloudRecords<Project | DeletedRecord>(uid, 'projects', [...data.projects.filter(p => !p.example), ...(tombstones.projects ?? [])], options),
          syncCloudRecords<InventoryItem | DeletedRecord>(uid, 'inventory', [...data.inventory, ...(tombstones.inventory ?? [])], options),
          syncCloudRecords<SustainabilityRecord | DeletedRecord>(uid, 'impact', [...data.impact, ...(tombstones.impact ?? [])], options),
        ])
        if (options.isAllowed()) {
          const deletes: Tombstones = { projects: projects.filter(isDeleted), inventory: inventory.filter(isDeleted), impact: impact.filter(isDeleted) }
          await mergeRemote({
            projects: projects.filter((item): item is Project => !isDeleted(item)),
            inventory: inventory.filter((item): item is InventoryItem => !isDeleted(item)),
            impact: impact.filter((item): item is SustainabilityRecord => !isDeleted(item)),
          }, deletes)
          if (options.isAllowed()) setSyncState('Cloud sync is up to date.')
        }
      } catch (error) {
        if (options.isAllowed()) setSyncState(errorText(error))
      } finally { syncRunning.current = false }
    }, 600)
    return () => { active = false; clearTimeout(start) }
  }, [allowSync, ready, profile, settings.allowMediaSync, sharedRevision, syncTick, mergeRemote])

  function setSettings(next: PrivacySettings) {
    syncConsent.current = !!profile && flags.enableCloudSync && next.cloudSync && next.mode !== 'private' && online
    setPreferences(next)
    try {
      localStorage.setItem(preferencesKey(scope), JSON.stringify(next))
    } catch { setNotice({ message: 'Browser preferences could not be saved.', error: true }) }
  }
  function options(privateProject = false): AIOptions {
    const mode = privateProject ? 'private' : settings.mode
    return {
      mode, flags, allowCloud: mode !== 'private' && settings.allowCloud,
      onDownloadProgress: fraction => { if (live.current) setDownloadProgress(Math.min(100, Math.max(0, fraction * 100))) },
    }
  }
  const mode = settings.mode.charAt(0).toUpperCase() + settings.mode.slice(1)
  const availability = downloadProgress !== undefined && downloadProgress < 100 ? 'downloading · ' + Math.round(downloadProgress) + '%' : local
  function selectProject(project?: Project) { projectRef.current = project; setSelected(project) }

  async function run<T>(task: () => Promise<T>, update: (value: T) => void): Promise<T | undefined> {
    if (running.current) return
    running.current = true
    setPending(true); setNotice(undefined)
    try {
      const value = await task()
      if (live.current) update(value)
      return value
    } catch (error) {
      if (live.current) setNotice({ message: errorText(error), error: true })
    } finally {
      running.current = false
      if (live.current) { setPending(false); setDownloadProgress(undefined) }
    }
  }

  function openExample(id: string) {
    const example = examples.find(example => example.id === id)
    if (!example) return
    void run(() => Promise.all([exampleAsset(example.before), exampleAsset(example.after)]), ([before, after]) => {
      setScan(undefined); setConcepts([])
      selectProject(newProject(example.concept, {
        example: true, private: settings.mode === 'private', analysis: example.analysis, originalImage: before,
        image: { dataUrl: after, style: 'Rustic', kind: 'Example concept', timestamp: time() },
        guide: example.guide,
      }))
      navigate('compare')
    })
  }

  function openConcept(concept: TransformationConcept, context: Partial<Scan> & { objectCount?: number; private?: boolean }) {
    selectProject(newProject(concept, {
      analysis: context.analysis, originalImage: context.originalImage, objectCount: context.objectCount, notes: context.notes,
      private: settings.mode === 'private' || !!context.private,
    }))
    navigate('studio')
  }

  async function saveProject(value = projectRef.current, announce = true) {
    if (!value) return
    try {
      const updated = { ...value, updatedAt: time() }
      await updateProject(updated)
      if (announce) setNotice({ message: 'Project saved to this device.' })
    } catch (error) { setNotice({ message: errorText(error), error: true }) }
  }
  function applyProjectPatch(id: string, patch: Partial<Project>) {
    const current = projectRef.current
    if (!current || current.id !== id) return
    const updated = { ...current, ...patch }
    selectProject(updated)
    if (data.projects.some(project => project.id === updated.id)) void saveProject(updated, false)
  }

  async function runCombination(input: CombinationInput) {
    const localOnly = settings.mode === 'private' || input.items.some(item => !!item.private)
    const materials = input.items.map(({ name, quantity, material, condition, dimensions }) =>
      ({ name, quantity, material, condition, dimensions }))
    const context = JSON.stringify({
      task: input.rescue ? 'Rescue unwanted objects' : 'Combine useful materials', objects: materials,
      availableTools: input.tools, skill: input.experience, criteria: 'Prefer owned materials, use multiple objects, prioritize budget and available tools',
    })
    const result = await generateConcepts(context, options(localOnly), input.budget)
    return { concepts: result.data }
  }

  async function clear() {
    syncConsent.current = false
    setSettings({ ...settings, cloudSync: false, allowMediaSync: false })
    if (profile && firebaseCloudReady) await clearCloudData(profile.uid)
    await clearData()
    clearInferenceEvents()
    setScan(undefined); setConcepts([]); selectProject(undefined)
  }

  async function removeAccount(password?: string) {
    syncConsent.current = false
    setSettings({ ...settings, cloudSync: false, allowMediaSync: false })
    await deleteAccount(password)
    await clearData()
    clearInferenceEvents()
    try { localStorage.removeItem(preferencesKey(scope)) } catch { /* Browser storage may be disabled. */ }
  }

  function content() {
    if (route === 'home' || route === 'landing') return <Home landing={route === 'landing'} busy={pending} onExample={openExample} openExamples={() => {
      const heading = document.getElementById('examples-heading')
      heading?.focus({ preventScroll: true })
      heading?.scrollIntoView({ behavior: reducedMotion ? 'instant' : 'smooth' })
    }} />
    if (route === 'scanner') return <Scanner options={options()} pending={pending} availability={availability} onAnalyze={async (image, originalImage, notes) => {
      const request = options()
      await run(() => analyzeObject(image, notes, request), response => {
        setScan({ analysis: response.data, originalImage, notes, private: request.mode === 'private' })
        setConcepts([]); selectProject(undefined); navigate('studio')
      })
    }} />
    if (route === 'account') return <AccountPage profile={profile} onDelete={removeAccount} />
    if (route === 'settings') return <><SettingsPage settings={settings} setSettings={setSettings} flags={flags} online={online} onClear={clear} />
      {allowSync && <p className="notice" role="status">{syncState || 'Cloud sync will start shortly.'}</p>}
    </>
    if (workRoutes.has(route)) return <Workshop key={route} route={route as WorkshopRoute} data={{ ...data, inference: events }} onInventoryChange={entry => updateInventory('deleted' in entry ? entry : { ...entry, private: settings.mode === 'private' || entry.private })}
      onProjectChange={async entry => {
        await updateProject(entry)
        if (projectRef.current?.id !== entry.id) return
        if ('deleted' in entry) selectProject(undefined)
        else selectProject(entry)
      }}
      onImpactChange={entry => updateImpact('deleted' in entry ? entry : { ...entry, private: settings.mode === 'private' || entry.private || data.projects.some(p => p.id === entry.projectId && p.private) })}
      onOpenProject={project => { setScan(undefined); setConcepts([]); selectProject(project); navigate('studio') }}
      onOpenConcept={(concept, context) => { setScan(undefined); setConcepts([]); openConcept(concept, context) }}
      availability={availability} online={online} mode={settings.mode} navigate={navigate} runCombination={runCombination} />

    const project = selected
    const saved = !!project && data.projects.some(row => row.id === project.id)
    if (route === 'studio' && !project && scan) {
      return <Concepts analysis={scan.analysis} originalImage={scan.originalImage} concepts={concepts} pending={pending}
        onGenerate={budget => void run(() => generateConcepts(scan.analysis, options(scan.private), budget), value => setConcepts(value.data))}
        onSelect={concept => openConcept(concept, scan)} />
    }
    if (!project) return <EmptyStudio route={route} />
    const requirePrivate = project.private || settings.mode === 'private'
    const save = () => void saveProject()
    if (route === 'studio') return <ProjectOverview key={project.id} project={project} saved={saved} pending={pending} onSave={save}
      onBack={scan && concepts.length ? () => selectProject(undefined) : undefined} onAsk={async (question, context) => {
        const outcome = await run(() => askAssistant(question, context, options(requirePrivate)), () => undefined)
        if (!outcome) throw new Error('Assistant request unavailable')
        return outcome.data
      }} />
    if (route === 'guide') return <GuidePage key={project.id} project={project} saved={saved} pending={pending} onSave={save}
      onGenerate={() => void run(() => generateGuide(project.concept, [project.analysis?.name, project.analysis?.condition, project.notes].filter(Boolean).join('\n'), options(requirePrivate)),
        value => applyProjectPatch(project.id, { guide: value.data, completedSteps: [], status: 'planned', private: requirePrivate }))}
      onStep={index => {
        const current = projectRef.current
        if (!current) return
        const completedSteps = current.completedSteps.includes(index) ? current.completedSteps.filter(v => v !== index) : [...current.completedSteps, index]
        applyProjectPatch(project.id, { completedSteps, status: completedSteps.length === current.guide?.steps.length && current.status === 'complete' ? 'complete' : 'in-progress', completedAt: undefined })
      }}
      onComplete={() => {
        const updated = { ...project, status: 'complete' as const, completedAt: time() }
        selectProject(updated); void saveProject(updated)
      }} />
    if (route === 'image') {
      const allowed = online && firebaseCloudReady && settings.allowCloud && flags.enableImageGeneration && !requirePrivate
      return <ImageStudio key={project.id} project={project} allowed={allowed} editing={flags.enableImageEditing} pending={pending} saved={saved} onSave={save}
        onGenerate={(style, kind, reference) => void run(async () => {
          const original = reference && project.originalImage ? await (await fetch(project.originalImage)).blob() : undefined
          return generateImage({ concept: project.concept, style, kind, reference: original }, options(requirePrivate), true)
        }, result => {
          applyProjectPatch(project.id, { image: result.data })
          if (project.originalImage) navigate('compare')
        })} />
    }
    return <ComparePage project={project} pending={pending} saved={saved} onSave={save} />
  }

  return <Shell route={route} mode={mode} online={online} account={profile?.displayName || profile?.email || undefined}>
    {(notice || error) && <div className={'app-message notice ' + (error || notice?.error ? 'error' : 'success')} role={error || notice?.error ? 'alert' : 'status'}>
      {error || notice?.error ? <CircleAlert size={19} /> : <Check size={19} />}<span>{error || notice?.message}</span>
    </div>}
    <motion.div key={route} initial={reducedMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.14 }}>{content()}</motion.div>
  </Shell>
}
