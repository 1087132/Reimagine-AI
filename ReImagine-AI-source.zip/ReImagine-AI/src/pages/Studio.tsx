import { useState, type ReactNode } from 'react'
import { BookOpen, Camera, CircleAlert, Clock3, Download, ImagePlus, Leaf, LockKeyhole, Save, SlidersHorizontal, Sparkles, Wallet, WandSparkles } from 'lucide-react'
import Comparison from '../components/Comparison'
import { PageTitle, urlFor, type Route } from '../components/Shell'
import type { Project } from '../services/storage/workshop'
import type { ObjectAnalysis, TransformationConcept } from '../types/ai'
import { downloadGuide } from '../utils/pdf'

export const styles = ['Minimalist', 'Modern', 'Industrial', 'Scandinavian', 'Rustic', 'Luxury', 'Artistic', 'Futuristic', 'Eco-friendly']
const kinds = ['Finished concept', 'Alternative design', 'Assembly illustration', 'Final product']
const categories = ['Home decoration', 'Garden and outdoor', 'Furniture', 'Art and creativity', 'Organization and storage']
export const currencies = ['AED', 'USD', 'EUR', 'GBP', 'INR']

export function EmptyStudio({ route }: { route: Route }) {
  return <><PageTitle title={route === 'studio' ? 'Transformation Studio' : route === 'image' ? 'Image Studio' : route === 'guide' ? 'Construction Guide' : 'Before & After'} />
    <div className="panel empty-state"><span className="quick-icon green"><Sparkles size={23} /></span>
      <h2>Start with an object or saved project</h2><p>Scan a photo to find reuse ideas or open a project to continue where you left off.</p>
      <div className="button-row"><a className="button primary" href={urlFor('scanner')}><Camera size={17} /> Scan an object</a><a className="button secondary" href={urlFor('projects')}>My Projects</a></div>
    </div></>
}

function Tag({ children }: { children: ReactNode }) { return <span className="tag">{children}</span> }

export function AnalysisCard({ analysis, originalImage, example }: { analysis: ObjectAnalysis; originalImage?: string; example?: boolean }) {
  return <section className="panel analysis-panel">
    {originalImage && <img src={originalImage} alt={example ? 'Example original object illustration' : 'Original object'} />}
    <div><p className="eyebrow">{example ? 'PRELOADED EXAMPLE' : 'VISUAL ANALYSIS'}</p>
      <h2>{analysis.name}</h2><p>{analysis.category} · {analysis.confidence} confidence</p>
      <dl className="analysis-details">
        <div><dt>Visible condition</dt><dd>{analysis.condition}</dd></div>
        <div><dt>Likely materials</dt><dd>{analysis.materials.join(', ') || 'Uncertain'}</dd></div>
        <div><dt>Reusable parts</dt><dd>{analysis.components.join(', ') || 'Uncertain'}</dd></div>
        <div><dt>Visible damage</dt><dd>{analysis.damage.join(', ') || 'None identified from this image'}</dd></div>
      </dl>
      <details><summary>Reuse potential, uncertainty and safety</summary><p>{analysis.potential}</p><p>{analysis.uncertainty}</p>{analysis.safety.length > 0 && <ul>{analysis.safety.map((note, i) => <li key={i}>{note}</li>)}</ul>}</details>
    </div>
  </section>
}

export function Concepts({ analysis, originalImage, concepts, onGenerate, onSelect, pending }: {
  analysis: ObjectAnalysis; originalImage?: string; concepts: TransformationConcept[];
  onGenerate: (budget: { maximum: number; currency: string }) => void; onSelect: (concept: TransformationConcept) => void; pending: boolean
}) {
  const [difficulty, setDifficulty] = useState('')
  const [category, setCategory] = useState('')
  const [price, setPrice] = useState('')
  const [currency, setCurrency] = useState('AED')
  const [maximum, setMaximum] = useState('50')
  const visible = concepts.filter(c => (!difficulty || c.difficulty === difficulty) &&
    (!category || c.category === category) &&
    (!price || (price === 'zero' ? c.costMax === 0 : c.currency === currency && c.costMax <= Number(maximum))))
  return <>
    <PageTitle title="Transformation Studio" description="Explore how this object could be used again." />
    <AnalysisCard analysis={analysis} originalImage={originalImage} />
    <section className="panel">
      <h2>Design brief</h2>
      <form className="inline-form" onSubmit={e => { e.preventDefault(); onGenerate({ currency, maximum: Number(maximum) }) }}>
        <label>Estimated maximum budget<input required type="number" min="0" max="100000" value={maximum} onChange={e => setMaximum(e.target.value)} /></label>
        <label>Currency<select value={currency} onChange={e => setCurrency(e.target.value)}>{currencies.map(value => <option key={value}>{value}</option>)}</select></label>
        <button className="button primary" disabled={pending}><Sparkles size={17} /> {pending ? 'Creating ideas…' : concepts.length ? 'Regenerate ideas' : 'Generate five ideas'}</button>
      </form>
      <p className="muted">Costs depend on what you own and local prices.</p>
    </section>
    {concepts.length > 0 && <section className="concepts-section">
      <div className="section-intro"><h2>Transformation ideas</h2><p>{visible.length} of {concepts.length} ideas</p></div>
      <div className="inline-form filters"><SlidersHorizontal size={19} /><label>Difficulty<select value={difficulty} onChange={e => setDifficulty(e.target.value)}><option value="">Any</option>{['Beginner', 'Intermediate', 'Advanced'].map(item => <option key={item}>{item}</option>)}</select></label>
        <label>Category<select value={category} onChange={e => setCategory(e.target.value)}><option value="">All categories</option>{Array.from(new Set([...categories, ...concepts.map(c => c.category)])).map(item => <option key={item}>{item}</option>)}</select></label>
        <label>Spending<select value={price} onChange={e => setPrice(e.target.value)}><option value="">Any budget</option><option value="zero">Zero cost</option><option value="low">Within budget</option></select></label></div>
      <div className="concept-grid">{visible.map((concept, i) => <article className="panel concept-card" key={concept.title + i}>
        <Tag>{concept.difficulty}</Tag><h3>{concept.title}</h3><p>{concept.description}</p>
        <ConceptFacts concept={concept} />
        <button type="button" className="button secondary" onClick={() => onSelect(concept)}>Choose concept</button>
      </article>)}</div>
      {!visible.length && <p>No ideas match these filters.</p>}
    </section>}
  </>
}

function ConceptFacts({ concept }: { concept: TransformationConcept }) {
  return <div className="concept-facts"><span><Clock3 size={16} /> {concept.duration}</span><span><Wallet size={16} /> Est. {concept.currency} {concept.costMin === concept.costMax ? concept.costMin : concept.costMin + '–' + concept.costMax}</span></div>
}

export function ProjectOverview({ project, onSave, onBack, saved, pending, onAsk }: {
  project: Project; onSave: () => void; onBack?: () => void; saved: boolean; pending: boolean;
  onAsk: (prompt: string, context: string) => Promise<string>
}) {
  const c = project.concept
  return <>
    <PageTitle title={project.title} description={project.example ? 'Preloaded example project' : 'Selected transformation concept'}>
      <button type="button" className="button primary" disabled={pending} onClick={onSave}><Save size={17} /> {saved ? 'Save changes' : 'Save project'}</button>
    </PageTitle>
    <div className="studio-tabs"><a href={urlFor('studio')} aria-current="page">Concept</a><a href={urlFor(project.image && project.originalImage ? 'compare' : 'image')}>Visual design</a><a href={urlFor('guide')}>Construction guide</a></div>
    <div className="scanner-grid">
      <section className="panel concept-detail">
        {(project.image?.dataUrl || project.originalImage) && <figure><img src={project.image?.dataUrl || project.originalImage} alt={project.image ? 'AI-generated concept illustration' : 'Input object'} /><figcaption>{project.image ? 'AI-generated concept illustration' : 'Original object'}</figcaption></figure>}
        <div className="button-row"><Tag>{c.difficulty}</Tag><Tag>{c.category}</Tag>{project.private && <Tag><LockKeyhole size={14} /> Private project</Tag>}</div>
        <h2>Design concept</h2><p>{c.description}</p><ConceptFacts concept={c} />
        <div className="detail-grid">
          <GuideList title="Materials" values={c.materials} /><GuideList title="Tools" values={c.tools} />
          <GuideList title="Sustainability benefits" values={c.benefits} /><GuideList title="Limitations" values={c.limitations} />
        </div>
        <GuideList title="Safety precautions" values={c.safety} />
        {onBack && <button className="button secondary" type="button" onClick={onBack}>Back to ideas</button>}
      </section>
      <div className="studio-stack">
        <section className="panel"><h2>Continue designing</h2>
          <div className="stack-actions"><a className="button secondary" href={urlFor(project.image && project.originalImage ? 'compare' : 'image')}><ImagePlus size={18} /> {project.image ? 'View design' : 'Open Image Studio'}</a>
            <a className="button secondary" href={urlFor('guide')}><BookOpen size={18} /> Construction Guide</a>
            <a className="button secondary" href={urlFor('budget')}><Wallet size={18} /> Budget Planner</a></div>
        </section>
        <Assistant pending={pending} project={project} onAsk={onAsk} />
      </div>
    </div>
  </>
}

function Assistant({ project, onAsk, pending }: { project: Project; onAsk: (prompt: string, context: string) => Promise<string>; pending: boolean }) {
  const [question, setQuestion] = useState('')
  const [history, setHistory] = useState<{ question: string; response: string }[]>([])
  return <section className="panel assistant">
    <h2><Sparkles size={19} /> Design assistant</h2><p>Ask for a cheaper version, a material swap, or a different style.</p>
    {history.length > 0 && <div className="chat-list" aria-live="polite">{history.map((item, i) => <div key={i}><strong>{item.question}</strong><p>{item.response}</p></div>)}</div>}
    <form onSubmit={async e => {
      e.preventDefault()
      if (!question.trim() || pending) return
      const prompt = question.trim()
      const context = [project.concept.title, project.concept.description, project.notes?.slice(0, 400), ...history.slice(-2).map(row => (row.question + ': ' + row.response).slice(0, 450))].join('\n').slice(0, 1600)
      try {
        const response = await onAsk(prompt, context)
        setHistory(items => [...items.slice(-7), { question: prompt, response }]); setQuestion('')
      } catch { /* The application reports inference errors. */ }
    }}><label>Ask about this design<textarea rows={3} maxLength={600} value={question} onChange={e => setQuestion(e.target.value)} placeholder="Make this project cheaper" /></label>
      <button type="submit" className="button primary" disabled={pending || !question.trim()}>Send question</button>
    </form>
  </section>
}

export function ImageStudio({ project, allowed, editing, pending, onGenerate, onSave, saved }: {
  project: Project; allowed: boolean; editing: boolean; pending: boolean; saved: boolean;
  onGenerate: (style: string, kind: string, reference: boolean) => void; onSave: () => void
}) {
  const [style, setStyle] = useState(project.image?.style || styles[0])
  const [kind, setKind] = useState(kinds[0])
  const [reference, setReference] = useState(false)
  const [confirm, setConfirm] = useState(false)
  return <>
    <PageTitle title="Image Studio" description={project.title} />
    <div className="scanner-grid">
      <section className="panel image-preview">
        {project.image ? <>
          <img src={project.image.dataUrl} alt="AI-generated concept illustration" />
          <div className="button-row"><Tag>AI-generated concept</Tag>{project.originalImage && <a className="button secondary" href={urlFor('compare')}>Before &amp; After</a>}</div>
        </> : <div className="empty-state"><span className="quick-icon green"><ImagePlus size={23} /></span><h2>Visualize the concept</h2><p>Choose a style and generate a visual direction for this project.</p></div>}
      </section>
      <section className="panel">
        <h2>Design options</h2>
        {!allowed && <div className="notice"><CircleAlert size={19} /><div>Image generation requires an enabled Firebase image model and your cloud consent. <a href={urlFor('settings')}>Review settings</a>.</div></div>}
        <form className="stack-actions" onSubmit={e => {
          e.preventDefault()
          if (!allowed || !confirm || pending) return
          setConfirm(false); onGenerate(style, kind, reference && editing)
        }}>
          <label>Visual style<select value={style} onChange={e => setStyle(e.target.value)}>{styles.map(s => <option key={s}>{s}</option>)}</select></label>
          <label>Image type<select value={kind} onChange={e => setKind(e.target.value)}>{kinds.map(s => <option key={s}>{s}</option>)}</select></label>
          {editing && project.originalImage && <label className="check-row"><input type="checkbox" checked={reference} onChange={e => setReference(e.target.checked)} /> Send the original object image as a reference</label>}
          <label className="check-row"><input type="checkbox" checked={confirm} onChange={e => setConfirm(e.target.checked)} disabled={!allowed} /> I confirm this may use billable cloud quota.</label>
          <button className="button primary" disabled={!allowed || !confirm || pending}><WandSparkles size={18} /> {pending ? 'Generating image…' : project.image ? 'Regenerate design' : 'Generate concept image'}</button>
        </form>
        <p className="muted">AI-generated concepts are illustrative. Verify materials and measurements before starting.</p>
        <button type="button" className="button secondary" disabled={pending} onClick={onSave}><Save size={16} /> {saved ? 'Save changes' : 'Save project'}</button>
      </section>
    </div>
  </>
}

export function ComparePage({ project, pending, saved, onSave }: {project: Project; pending: boolean; saved: boolean; onSave: () => void}) {
  if (!project.image || !project.originalImage) return <><PageTitle title="Before & After" description="Compare the source object with an AI-generated concept." />
    <section className="panel empty-state"><h2>Two images are required</h2><p>Open Image Studio to generate a visual for a project with a source photo.</p><a className="button primary" href={urlFor('image')}>Open Image Studio</a></section></>
  return <>
    <PageTitle title="Before & After" description={project.title} />
    {project.example && <p className="notice"><Leaf size={18} /> Preloaded example with AI-generated illustrations.</p>}
    <section className="panel compare-panel">
      <Comparison before={project.originalImage} after={project.image.dataUrl} example={project.example} />
      <p className="muted">Drag the divider or use the arrow keys to compare. The after image is an AI-generated concept.</p>
    </section>
    <div className="button-row page-actions">
      <button className="button primary" type="button" disabled={pending} onClick={onSave}><Save size={17} /> {saved ? 'Save changes' : 'Save project'}</button>
      <a className="button secondary" href={project.image.dataUrl} download="reimagine-ai-concept"><Download size={17} /> Download image</a>
      {!project.example && <a className="button secondary" href={urlFor('image')}>Style and regeneration</a>}
      <a className="button secondary" href={urlFor('guide')}><BookOpen size={17} /> Construction Guide</a>
    </div>
  </>
}

function GuideList({ title, values }: { title: string; values: string[] }) {
  if (!values.length) return null
  return <section><h3>{title}</h3><ul>{values.map((entry, i) => <li key={i}>{entry}</li>)}</ul></section>
}

export function GuidePage({ project, pending, saved, onGenerate, onSave, onStep, onComplete }: {
  project: Project; pending: boolean; saved: boolean; onGenerate: () => void; onSave: () => void;
  onStep: (index: number) => void; onComplete: () => void
}) {
  const [includePhoto, setIncludePhoto] = useState(false)
  const [includeConcept, setIncludeConcept] = useState(false)
  const [exporting, setExporting] = useState(false)
  const [error, setError] = useState('')
  const guide = project.guide
  return <>
    <PageTitle title="Construction Guide" description={project.title}>
      <button type="button" className="button primary" disabled={pending} onClick={onSave}><Save size={17} /> {saved ? 'Save changes' : 'Save project'}</button>
    </PageTitle>
    {!guide ? <section className="panel empty-state">
      <span className="quick-icon green"><BookOpen size={24} /></span><h2>Get step-by-step instructions</h2>
      <p>Generate a guide with a materials checklist, preparation, and safety precautions.</p>
      <button className="button primary" type="button" disabled={pending} onClick={onGenerate}><Sparkles size={17} /> {pending ? 'Preparing guide…' : 'Generate construction guide'}</button>
    </section> : <div className="scanner-grid">
      <article className="panel guide-content">
        <h2>{guide.transformation}</h2><p>{guide.overview}</p><p><strong>Original object:</strong> {guide.originalObject}</p>
        <div className="concept-facts"><span><Clock3 size={16} /> {guide.duration}</span><span><Wallet size={16} /> {guide.cost}</span></div>
        <div className="notice"><CircleAlert size={18} /> Verify the object’s condition and all dimensions before starting. Dimensions are estimates unless you supplied measurements.</div>
        <GuideList title="Safety precautions" values={guide.safety} />
        <div className="detail-grid"><GuideList title="Materials checklist" values={guide.materials} /><GuideList title="Tools checklist" values={guide.tools} /></div>
        <GuideList title="Preparation" values={guide.preparation} />
        <h3>Construction steps</h3><ol className="steps">{guide.steps.map((step, index) => <li key={index}>
          <label className="check-row" htmlFor={'step-' + index}><input id={'step-' + index} type="checkbox" checked={project.completedSteps.includes(index)} onChange={() => onStep(index)} /><span><strong>{index + 1}. {step.title}</strong><span>{step.instructions}</span></span></label>
        </li>)}</ol>
        <GuideList title="Finishing" values={guide.finishing} /><GuideList title="Alternative materials" values={guide.alternatives} /><GuideList title="Maintenance" values={guide.maintenance} />
      </article>
      <div className="studio-stack">
        <section className="panel"><h2>Project progress</h2>
          <p>{project.completedSteps.length} / {guide.steps.length} steps complete</p>
          <progress aria-label="Construction progress" value={project.completedSteps.length} max={guide.steps.length} />
          <button className="button secondary wide" type="button" onClick={onComplete} disabled={project.status === 'complete' || project.completedSteps.length < guide.steps.length || pending}>{project.status === 'complete' ? 'Project complete' : 'Mark project complete'}</button>
        </section>
        <section className="panel"><h2>Take it to your workshop</h2><p>Export a printable guide with your construction steps.</p>
          {project.originalImage && <label className="check-row"><input type="checkbox" checked={includePhoto} onChange={e => setIncludePhoto(e.target.checked)} /> Include original image</label>}
          {project.image && <label className="check-row"><input type="checkbox" checked={includeConcept} onChange={e => setIncludeConcept(e.target.checked)} /> Include concept illustration</label>}
          <button className="button secondary wide" type="button" disabled={exporting} onClick={async () => {
            setExporting(true); setError('')
            try { await downloadGuide(project, includePhoto, includeConcept) } catch (reason) { setError(reason instanceof Error ? reason.message : 'PDF could not be exported.') }
            finally { setExporting(false) }
          }}><Download size={17} /> {exporting ? 'Exporting…' : 'Download PDF'}</button>
          {error && <p className="notice error" role="alert">{error}</p>}
        </section>
      </div>
    </div>}
  </>
}
