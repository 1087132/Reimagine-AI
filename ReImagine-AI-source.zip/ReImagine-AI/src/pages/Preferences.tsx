import { useEffect, useState, type FormEvent } from 'react'
import { Cloud, Download, LockKeyhole, Mail, ShieldCheck, Trash2, UserRound } from 'lucide-react'
import { z } from 'zod'
import { PageTitle, urlFor } from '../components/Shell'
import { aiModeSchema } from '../schemas/ai'
import { getQuotaUsage, subscribeInferenceEvents } from '../services/ai/telemetry'
import {
  defaultFlags, firebaseAuthMessage, firebaseAuthReady, firebaseCloudReady,
  logInEmail, logInGoogle, logout, registerEmail,
} from '../services/firebase'
import type { FeatureFlags, UserProfile } from '../types/ai'

export const privacySettingsSchema = z.object({
  mode: aiModeSchema,
  allowCloud: z.boolean(),
  cloudSync: z.boolean(),
  allowMediaSync: z.boolean(),
  theme: z.enum(['light', 'dark', 'system']),
})

export type PrivacySettings = z.infer<typeof privacySettingsSchema>

export const defaultPrivacySettings: PrivacySettings = {
  mode: 'hybrid',
  allowCloud: false,
  cloudSync: false,
  allowMediaSync: false,
  theme: 'system',
}

const modeDescriptions = {
  hybrid: 'Uses the on-device model when available. With your consent, Firebase AI Logic can fall back to a cloud model.',
  private: 'Uses only the on-device model. New private projects and inventory stay in this browser.',
  cloud: 'Sends requests to a Gemini cloud model with your consent. Requires a configured Firebase project and internet access.',
}

export function SettingsPage({ settings, setSettings, flags, online, onClear }: {
  settings: PrivacySettings
  setSettings: (value: PrivacySettings) => void
  flags: FeatureFlags
  online: boolean
  onClear: () => Promise<void>
}) {
  const [quota, setQuota] = useState(getQuotaUsage)
  const [clearing, setClearing] = useState(false)
  const [feedback, setFeedback] = useState<{ text: string; error?: boolean }>()
  const privateMode = settings.mode === 'private'
  const syncAvailable = flags.enableCloudSync

  useEffect(() => {
    const refresh = () => setQuota(getQuotaUsage())
    const unsubscribe = subscribeInferenceEvents(refresh)
    const interval = window.setInterval(refresh, 60_000)
    return () => { unsubscribe(); window.clearInterval(interval) }
  }, [])

  async function clearData() {
    if (!window.confirm('Permanently clear your saved workshop data? Export any guides you want to keep first.')) return
    setClearing(true)
    setFeedback(undefined)
    try {
      await onClear()
      setFeedback({ text: 'Your saved workspace data was cleared.' })
    } catch (error) {
      setFeedback({ text: firebaseAuthMessage(error), error: true })
    } finally {
      setClearing(false)
    }
  }

  return <>
    <PageTitle title="Settings & Privacy" description="Choose which AI features can use the cloud and how your workshop is stored." />
    <div className="scanner-grid">
      <div className="studio-stack">
        <section className="panel stack-actions" aria-labelledby="model-settings">
          <h2 id="model-settings"><LockKeyhole size={20} aria-hidden="true" /> AI processing</h2>
          <label>Inference mode
            <select value={settings.mode} aria-describedby="mode-description" onChange={event => {
              const mode = aiModeSchema.parse(event.target.value)
              setSettings(mode === 'private'
                ? { ...settings, mode, allowCloud: false, cloudSync: false, allowMediaSync: false }
                : { ...settings, mode })
            }}>
              <option value="hybrid">Hybrid</option>
              <option value="private">Private</option>
              <option value="cloud">Cloud</option>
            </select>
          </label>
          <p id="mode-description">{modeDescriptions[settings.mode]}</p>
          <label className="check-row">
            <input type="checkbox" checked={!privateMode && settings.allowCloud} disabled={privateMode}
              onChange={event => setSettings({ ...settings, allowCloud: event.target.checked })} />
            Allow cloud AI processing
          </label>
          <p className="muted">Cloud processing can send the photo, notes and project context you submit to Firebase AI Logic. Optional image generation asks for separate confirmation.</p>
        </section>

        <section className="panel stack-actions" aria-labelledby="sync-settings">
          <h2 id="sync-settings"><Cloud size={20} aria-hidden="true" /> Cloud synchronization</h2>
          <label className="check-row">
            <input type="checkbox" checked={!privateMode && syncAvailable && settings.cloudSync}
              disabled={privateMode || !syncAvailable}
              onChange={event => setSettings({
                ...settings, cloudSync: event.target.checked, allowMediaSync: event.target.checked && settings.allowMediaSync,
              })} />
            Sync eligible projects and inventory
          </label>
          <label className="check-row">
            <input type="checkbox" checked={!privateMode && syncAvailable && settings.cloudSync && settings.allowMediaSync}
              disabled={privateMode || !syncAvailable || !settings.cloudSync}
              onChange={event => setSettings({ ...settings, allowMediaSync: event.target.checked })} />
            Include eligible photos and concept images in sync
          </label>
          <p className="muted">{syncAvailable
            ? 'Sync runs when you are signed in and connected. Photos require the Firebase Storage integration.'
            : 'Sync is disabled in this deployment. Your work is available in your local library.'}</p>
        </section>

        <section className="panel stack-actions" aria-labelledby="device-settings">
          <h2 id="device-settings"><Trash2 size={19} aria-hidden="true" /> Workspace data</h2>
          <p>Delete saved projects, inventory, impact records, and local AI history. For signed-in accounts, this also removes synchronized records. Export any guides and images you want to keep.</p>
          <div className="button-row">
            <button className="button secondary" type="button" disabled={clearing} onClick={() => void clearData()}>
              {clearing ? 'Clearing workspace…' : 'Clear workspace data'}
            </button>
            <a className="button secondary" href={urlFor('account')}>Manage account</a>
          </div>
          {feedback && <p className={'notice' + (feedback.error ? ' error' : '')} role={feedback.error ? 'alert' : 'status'}>{feedback.text}</p>}
        </section>
      </div>

      <div className="studio-stack">
        <section className="panel stack-actions" aria-labelledby="quota-settings">
          <h2 id="quota-settings"><ShieldCheck size={20} aria-hidden="true" /> Cloud quotas</h2>
          <p className="muted">{!firebaseCloudReady ? 'Cloud services need Firebase configuration and App Check.'
            : online ? 'Firebase is configured and your browser is online.' : 'You are offline.'}</p>
          <label>Cloud request slots used today
            <progress max={Math.max(1, flags.maxCloudRequestsPerDay)} value={quota.cloudRequests} />
          </label>
          <p>{quota.cloudRequests} of {flags.maxCloudRequestsPerDay}</p>
          <label>Image request slots used today
            <progress max={Math.max(1, flags.maxImageGenerationsPerDay)} value={quota.imageGenerations} />
          </label>
          <p>{flags.enableImageGeneration ? quota.imageGenerations + ' of ' + flags.maxImageGenerationsPerDay : 'Image generation is disabled for this Firebase project.'}</p>
          <p className="muted">Text model: {flags.enableAdvancedCloudModels ? flags.cloudTextModel : defaultFlags.cloudTextModel}.
            {flags.enableImageGeneration && <> Image model: {flags.cloudImageModel}.</>}</p>
          <p className="muted">Counters reset at midnight UTC. Cloud billing and provider quotas are managed separately in Firebase and Google Cloud.</p>
        </section>

        <section className="panel stack-actions" aria-labelledby="appearance-settings">
          <h2 id="appearance-settings">Appearance</h2>
          <label>Theme
            <select value={settings.theme} onChange={event => setSettings({
              ...settings, theme: privacySettingsSchema.shape.theme.parse(event.target.value),
            })}>
              <option value="system">Use system setting</option><option value="light">Light</option><option value="dark">Dark</option>
            </select>
          </label>
        </section>

        <section className="panel" aria-labelledby="install-settings">
          <h2 id="install-settings"><Download size={20} aria-hidden="true" /> Install the web app</h2>
          <p>Open this app in Chrome. When Chrome offers installation, use the Install icon in the address bar or the browser’s install option. Open the app once online to cache the workshop for offline access.</p>
        </section>
      </div>
    </div>
  </>
}

export function AccountPage({ profile, onDelete }: {
  profile: UserProfile | null
  onDelete: (password?: string) => Promise<void>
}) {
  const [registering, setRegistering] = useState(false)
  const [deleteForm, setDeleteForm] = useState(false)
  const [pending, setPending] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState('')

  async function withFeedback(action: () => Promise<unknown>, done?: string) {
    setPending(true)
    setError('')
    setStatus('')
    try {
      await action()
      if (done) setStatus(done)
    } catch (error) {
      setError(firebaseAuthMessage(error))
    } finally {
      setPending(false)
    }
  }

  async function submitEmail(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = event.currentTarget
    const data = new FormData(form)
    const email = String(data.get('email') ?? '')
    const password = String(data.get('password') ?? '')
    await withFeedback(() => registering ? registerEmail(email, password) : logInEmail(email, password))
    const field = form.elements.namedItem('password')
    if (field instanceof HTMLInputElement) field.value = ''
  }

  async function submitDeletion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!window.confirm('Permanently delete this account and its synchronized data?')) return
    const form = event.currentTarget
    const data = new FormData(form)
    await withFeedback(async () => {
      await onDelete(String(data.get('password') ?? '') || undefined)
      setDeleteForm(false)
    }, 'Account deleted.')
    const field = form.elements.namedItem('password')
    if (field instanceof HTMLInputElement) field.value = ''
  }

  return <>
    <PageTitle title={profile ? 'Your account' : registering ? 'Create an account' : 'Sign in'} description={
      profile ? 'Manage your Firebase account and its data.' : 'Use an account for opt-in synchronization, or continue in a local guest workspace.'
    } />
    <div className="scanner-grid">
      <section className="panel stack-actions" aria-label={profile ? 'Signed-in account' : 'Firebase Authentication'}>
        {error && <p className="notice error" role="alert">{error}</p>}
        {status && <p className="notice" role="status">{status}</p>}
        {profile ? <>
          <h2><UserRound size={20} aria-hidden="true" /> {profile.displayName || 'Signed in'}</h2>
          {profile.email && <p>{profile.email}</p>}
          <button type="button" className="button secondary" disabled={pending} onClick={() => void withFeedback(async () => {
            await logout()
            setDeleteForm(false)
          }, 'Signed out.')}>Sign out</button>
          <button type="button" className="button secondary" aria-expanded={deleteForm} disabled={pending}
            onClick={() => { setDeleteForm(value => !value); setError('') }}>
            <Trash2 size={17} aria-hidden="true" /> {deleteForm ? 'Cancel account deletion' : 'Delete account'}
          </button>
          {deleteForm && <form className="stack-actions" onSubmit={event => void submitDeletion(event)}>
            <p>Deleting your account removes the account and its synchronized data. Google sign-in opens a verification window. For email sign-in, enter your account password.</p>
            <label>Account password for email sign-in
              <input name="password" type="password" autoComplete="current-password" />
            </label>
            <button type="submit" className="button primary" disabled={pending}>{pending ? 'Deleting account…' : 'Permanently delete account'}</button>
          </form>}
        </> : <>
          <h2><Mail size={20} aria-hidden="true" /> {registering ? 'Register with email' : 'Sign in with email'}</h2>
          {!firebaseAuthReady && <p className="notice">Account sign-in is unavailable until Firebase Authentication and App Check are configured.</p>}
          <form className="stack-actions" onSubmit={event => void submitEmail(event)}>
            <label>Email address<input name="email" type="email" autoComplete="email" required /></label>
            <label>Password<input name="password" type="password" autoComplete={registering ? 'new-password' : 'current-password'}
              minLength={registering ? 6 : undefined} required /></label>
            <button className="button primary" type="submit" disabled={pending || !firebaseAuthReady}>
              {pending ? 'Connecting…' : registering ? 'Create account' : 'Sign in'}
            </button>
          </form>
          <button type="button" className="button secondary" disabled={pending || !firebaseAuthReady}
            onClick={() => void withFeedback(logInGoogle)}>Continue with Google</button>
          <button type="button" className="button secondary" disabled={pending}
            onClick={() => { setRegistering(value => !value); setError('') }}>
            {registering ? 'I already have an account' : 'Create an email account'}
          </button>
        </>}
      </section>
      <section className="panel stack-actions">
        <h2><LockKeyhole size={20} aria-hidden="true" /> {profile ? 'Privacy preferences' : 'Guest workspace'}</h2>
        <p>{profile ? 'Control your inference mode, optional cloud sync, and local workshop data in Settings.'
          : 'Explore examples, save projects, and track materials on this device without signing in.'}</p>
        <div className="button-row">
          <a className="button secondary" href={urlFor(profile ? 'settings' : 'home')}>{profile ? 'Settings & Privacy' : 'Continue as guest'}</a>
        </div>
      </section>
    </div>
  </>
}
