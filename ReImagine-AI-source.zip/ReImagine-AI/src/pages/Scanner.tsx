import { useEffect, useRef, useState } from 'react'
import { Camera, CircleAlert, ImagePlus, LockKeyhole, RotateCw, ScanLine, Upload, X } from 'lucide-react'
import type { AIOptions } from '../types/ai'
import { asDataUrl, editPhoto, validatePhoto } from '../utils/media'
import { PageTitle, urlFor } from '../components/Shell'

export default function Scanner({ options, onAnalyze, pending, availability }: {
  options: AIOptions; onAnalyze: (photo: Blob, image: string, notes: string) => Promise<void>; pending: boolean; availability: string
}) {
  const [photo, setPhoto] = useState<File>()
  const [preview, setPreview] = useState('')
  const [rotation, setRotation] = useState(0)
  const [crop, setCrop] = useState(0)
  const [cropX, setCropX] = useState(50)
  const [cropY, setCropY] = useState(50)
  const [notes, setNotes] = useState('')
  const [error, setError] = useState('')
  const [dragging, setDragging] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)
  const cameraInput = useRef<HTMLInputElement>(null)
  const cameraView = useRef<HTMLVideoElement>(null)
  const cameraStream = useRef<MediaStream | null>(null)
  const cameraRequest = useRef(0)
  const [cameraOpen, setCameraOpen] = useState(false)
  const [cameraPending, setCameraPending] = useState(false)
  const photoRequest = useRef(0)

  useEffect(() => {
    if (cameraOpen && cameraView.current) cameraView.current.srcObject = cameraStream.current
  }, [cameraOpen])
  useEffect(() => () => {
    cameraRequest.current++
    cameraStream.current?.getTracks().forEach(track => track.stop())
  }, [])

  useEffect(() => {
    if (!photo) return
    let current = true
    let url = ''
    void editPhoto(photo, rotation, crop, cropX, cropY).then(blob => {
      if (current) { url = URL.createObjectURL(blob); setPreview(url) }
    }).catch(reason => { if (current) setError(String(reason)) })
    return () => { current = false; if (url) URL.revokeObjectURL(url) }
  }, [photo, rotation, crop, cropX, cropY])

  async function choose(file?: File) {
    if (!file || pending) return
    const request = ++photoRequest.current
    setError('')
    try {
      await validatePhoto(file)
      if (request !== photoRequest.current) return
      setRotation(0); setCrop(0); setCropX(50); setCropY(50); setPhoto(file)
    } catch (reason) {
      if (request === photoRequest.current) setError(reason instanceof Error ? reason.message : String(reason))
    }
  }
  function remove() {
    photoRequest.current++
    setPhoto(undefined); setPreview(''); setError('')
    if (fileInput.current) fileInput.current.value = ''
    if (cameraInput.current) cameraInput.current.value = ''
  }
  async function openCamera() {
    if (!navigator.mediaDevices?.getUserMedia) {
      cameraInput.current?.click()
      return
    }
    const request = ++cameraRequest.current
    setCameraPending(true); setError('')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false })
      if (request !== cameraRequest.current) {
        stream.getTracks().forEach(track => track.stop())
        return
      }
      cameraStream.current = stream
      setCameraOpen(true)
    } catch {
      if (request === cameraRequest.current) setError('Camera unavailable. Check browser camera permissions or choose a photo.')
    } finally {
      if (request === cameraRequest.current) setCameraPending(false)
    }
  }
  function closeCamera() {
    cameraStream.current?.getTracks().forEach(track => track.stop())
    cameraStream.current = null
    setCameraOpen(false)
  }
  function capture() {
    const video = cameraView.current
    if (!video?.videoWidth) return
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext('2d')!.drawImage(video, 0, 0)
    closeCamera()
    canvas.toBlob(blob => {
      if (blob) void choose(new File([blob], 'camera-photo.jpg', { type: 'image/jpeg' }))
    }, 'image/jpeg', 0.9)
  }

  const privatePath = options.mode === 'private' || !options.allowCloud
  return <>
    <PageTitle title="Object Scanner" description="Photograph an item to explore its materials, condition, and reuse potential." />
    <form className="scanner-grid" onSubmit={async event => {
      event.preventDefault()
      if (!photo || pending) return
      setError('')
      try {
        const prepared = await editPhoto(photo, rotation, crop, cropX, cropY)
        await onAnalyze(prepared, await asDataUrl(prepared), notes.trim())
      } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)) }
    }}>
      <section className="panel scanner-main" aria-labelledby="photo-title">
        <h2 id="photo-title">Object photo</h2>
        <p>Use JPEG or PNG, up to 20 MB.</p>
        <input className="visually-hidden" ref={fileInput} aria-label="Upload an image" type="file" accept="image/jpeg,image/png" onChange={event => void choose(event.target.files?.[0])} />
        <input hidden ref={cameraInput} aria-label="Capture an image" type="file" accept="image/*" capture="environment" onChange={event => void choose(event.target.files?.[0])} />
        <div className={'photo-drop' + (dragging ? ' dragging' : '') + (photo ? ' with-photo' : '')}
          onDragOver={event => { event.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)}
          onDrop={event => { event.preventDefault(); setDragging(false); void choose(event.dataTransfer.files[0]) }}>
          {cameraOpen ? <><video ref={cameraView} autoPlay playsInline muted aria-label="Live camera preview" />
            <div className="button-row"><button type="button" className="button primary" onClick={capture}>Capture photo</button>
              <button type="button" className="button secondary" onClick={closeCamera}>Close camera</button></div></> :
          photo ? <><img src={preview || undefined} alt="Object photo preview" /><button type="button" className="icon-button photo-remove" aria-label="Remove image" disabled={pending} onClick={remove}><X size={19} /></button></> :
            <><span className="upload-symbol"><ImagePlus size={33} strokeWidth={1.5} /></span><strong>Drop your photo here</strong>
              <span>Use a clear, well-lit photo showing the whole object.</span>
              <div className="button-row">
                <button type="button" className="button primary" onClick={() => fileInput.current?.click()}><Upload size={17} /> Choose photo</button>
                <button type="button" className="button secondary" disabled={cameraPending} onClick={() => void openCamera()}><Camera size={18} /> {cameraPending ? 'Opening camera…' : 'Use camera'}</button>
              </div></>}
        </div>
        {photo && <div className="photo-controls">
          <button type="button" className="button secondary" onClick={() => setRotation(value => (value + 90) % 360)} disabled={pending}><RotateCw size={17} /> Rotate</button>
          <label>Crop edges <input type="range" min="0" max="65" value={crop} disabled={pending} onChange={e => setCrop(Number(e.target.value))} /></label>
          {crop > 0 && <><label>Horizontal position <input type="range" min="0" max="100" value={cropX} disabled={pending} onChange={e => setCropX(Number(e.target.value))} /></label>
            <label>Vertical position <input type="range" min="0" max="100" value={cropY} disabled={pending} onChange={e => setCropY(Number(e.target.value))} /></label></>}
        </div>}
        {error && <div className="notice error" role="alert"><CircleAlert size={19} />{error}</div>}
      </section>
      <section className="panel scanner-details" aria-labelledby="scanner-details">
        <h2 id="scanner-details">Add context</h2>
        <label htmlFor="object-notes">What do you know about it? <span className="muted">(optional)</span></label>
        <textarea id="object-notes" maxLength={600} rows={5} value={notes} onChange={e => setNotes(e.target.value)} placeholder="E.g. An old wooden caddy. The handle is loose and I have a small balcony." />
        <div className="notice"><LockKeyhole size={18} /><div>
          <strong>{privatePath ? 'On-device processing only' : options.mode === 'hybrid' ? 'Cloud fallback allowed' : 'Cloud processing allowed'}</strong>
          <p>{privatePath ? 'This request stays on this device. Local AI needs a compatible Chrome model.' : 'The photo and notes may be sent to Firebase AI Logic. You can change your consent in Settings.'}</p>
          <span>Local model: {availability}</span> · <a href={urlFor('settings')}>Privacy settings</a>
        </div></div>
        <button type="submit" className="button primary wide" disabled={!photo || pending}><ScanLine size={18} /> {pending ? 'Analyzing photo…' : 'Analyze object'}</button>
        {pending && <p role="status">The first on-device request may need a model download.</p>}
      </section>
    </form>
  </>
}
