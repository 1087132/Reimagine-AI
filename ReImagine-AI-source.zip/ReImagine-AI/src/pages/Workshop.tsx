import { useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import {
  Activity, Boxes, Check, ClipboardList, Clock3, Cloud, Cpu, FolderOpen, GitMerge, HeartHandshake,
  HelpCircle, ImagePlus, Leaf, Pencil, Plus, Recycle, Search, ShieldCheck, Trash2, Wallet, Weight, Wifi, WifiOff, X
} from 'lucide-react'
import type {
  BudgetCategory, BudgetEstimate, BudgetLine, DeletedRecord, InventoryItem, Project, SustainabilityRecord, WorkshopData
} from '../services/storage/workshop'
import type { ObjectAnalysis, TransformationConcept } from '../types/ai'
import { calculateBudget, calculateImpact, formatMoney } from '../features/workshop/metrics'
import '../styles/workshop.css'

export type WorkshopRoute = 'inventory' | 'combine' | 'rescue' | 'budget' | 'projects' | 'impact' | 'transparency' | 'help'

export interface CombinationInput {
  items: InventoryItem[]
  budget: { maximum: number; currency: string }
  experience: string
  tools: string
  rescue: boolean
}

export interface CombinationResult {
  concepts: TransformationConcept[]
  recommendedIndex?: number
}

interface ConceptContext {
  analysis?: ObjectAnalysis
  originalImage?: string
  notes?: string
  objectCount?: number
  private?: boolean
}

export interface WorkshopProps {
  route: WorkshopRoute
  data: WorkshopData
  onInventoryChange: (item: InventoryItem | DeletedRecord) => Promise<void>
  onProjectChange: (project: Project | DeletedRecord) => Promise<void>
  onImpactChange: (record: SustainabilityRecord | DeletedRecord) => Promise<void>
  onOpenProject: (project: Project) => void
  onOpenConcept: (concept: TransformationConcept, context: ConceptContext) => void
  navigate?: (route: 'scanner' | 'inventory' | 'projects' | 'settings' | 'budget') => void
  mode: string
  online: boolean
  runCombination: (input: CombinationInput) => Promise<CombinationResult>
  availability?: string
}

const materials = ['Wood', 'Cardboard', 'Plastic', 'Metal', 'Fabric', 'Glass', 'Ceramic', 'Mixed', 'Other']
const conditions = ['Like new', 'Good', 'Worn', 'Needs repair']
const categories: BudgetCategory[] = ['Materials', 'Tools', 'Decor', 'Other']
const currencies = ['AED', 'USD', 'EUR', 'GBP', 'INR', 'CAD', 'AUD']
const statuses = { planned: 'Planned', 'in-progress': 'In progress', complete: 'Complete' }
const now = () => new Date().toISOString()
const id = () => crypto.randomUUID()
const errorMessage = (error: unknown) => error instanceof Error ? error.message : 'Something went wrong. Please try again.'

function Heading({ tag, title, description, action }: { tag: string; title: string; description: string; action?: ReactNode }) {
  return <header className="wk-heading">
    <div><p className="wk-kicker">{tag}</p><h1>{title}</h1><p>{description}</p></div>
    {action}
  </header>
}

function Empty({ icon, title, children, action }: { icon: ReactNode; title: string; children: ReactNode; action?: ReactNode }) {
  return <div className="wk-empty"><span className="wk-icon">{icon}</span><h2>{title}</h2><p>{children}</p>{action}</div>
}

function Action({ children, onClick, secondary = false }: { children: ReactNode; onClick: () => void; secondary?: boolean }) {
  return <button type="button" className={secondary ? 'wk-button wk-secondary' : 'wk-button'} onClick={onClick}>{children}</button>
}

function Feedback({ error, message }: { error: string; message?: string }) {
  return <>{error && <p className="wk-feedback wk-error" role="alert">{error}</p>}
    {!error && message && <p className="wk-feedback" role="status">{message}</p>}</>
}

async function readInventoryPhoto(file: File) {
  if (!['image/jpeg', 'image/png'].includes(file.type)) throw new Error('Choose a JPEG or PNG image.')
  if (file.size > 12 * 1024 * 1024) throw new Error('Choose an image smaller than 12 MB.')
  const bitmap = await createImageBitmap(file)
  try {
    const scale = Math.min(1, 960 / Math.max(bitmap.width, bitmap.height))
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(bitmap.width * scale))
    canvas.height = Math.max(1, Math.round(bitmap.height * scale))
    const context = canvas.getContext('2d')
    if (!context) throw new Error('This browser could not process the image.')
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
    return canvas.toDataURL('image/jpeg', 0.8)
  } finally {
    bitmap.close()
  }
}

function InventoryEditor({ editing, privateMode, onChange, onClose }: {
  editing: InventoryItem | null
  privateMode: boolean
  onChange: WorkshopProps['onInventoryChange']
  onClose: () => void
}) {
  const [photo, setPhoto] = useState(editing?.photo)
  const [busy, setBusy] = useState(false)
  const [decoding, setDecoding] = useState(false)
  const [error, setError] = useState('')

  async function handlePhoto(file?: File) {
    if (!file) return
    setError('')
    setDecoding(true)
    try {
      setPhoto(await readInventoryPhoto(file))
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setDecoding(false)
    }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const values = new FormData(event.currentTarget)
    const name = String(values.get('name') ?? '').trim()
    const quantity = Number(values.get('quantity'))
    if (!name || !Number.isSafeInteger(quantity) || quantity < 1) {
      setError('Enter an item name and a whole-number quantity.')
      return
    }
    setError('')
    setBusy(true)
    try {
      await onChange({
        id: editing?.id ?? id(),
        name,
        quantity,
        material: String(values.get('material')),
        condition: String(values.get('condition')),
        dimensions: String(values.get('dimensions') ?? '').trim(),
        photo,
        addedAt: editing?.addedAt ?? now(),
        updatedAt: now(),
        private: privateMode || values.get('private') === 'on'
      })
      onClose()
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setBusy(false)
    }
  }

  return <form className="wk-panel wk-form" onSubmit={event => void submit(event)}>
    <div className="wk-row"><h2>{editing ? 'Edit item' : 'Add an item'}</h2>
      <button type="button" className="wk-icon-button" aria-label="Close item editor" onClick={onClose}><X size={18} /></button>
    </div>
    <div className="wk-fields">
      <label>Item name<input name="name" maxLength={120} placeholder="e.g. Pine offcuts" defaultValue={editing?.name} required /></label>
      <label>Quantity<input name="quantity" type="number" min="1" max="10000" step="1" defaultValue={editing?.quantity ?? 1} required /></label>
      <label>Material<select name="material" defaultValue={editing?.material ?? 'Wood'}>{materials.map(material => <option key={material}>{material}</option>)}</select></label>
      <label>Condition<select name="condition" defaultValue={editing?.condition ?? 'Good'}>{conditions.map(condition => <option key={condition}>{condition}</option>)}</select></label>
      <label className="wk-wide">Dimensions <span className="wk-muted">(optional)</span><input name="dimensions" maxLength={120} placeholder="e.g. 40 × 12 × 2 cm" defaultValue={editing?.dimensions} /></label>
    </div>
    <div className="wk-photo-controls">
      <ImagePlus size={19} aria-hidden="true" />
      <label>Item photo <span className="wk-muted">(optional)</span>
        <input type="file" accept="image/jpeg,image/png" onChange={event => void handlePhoto(event.target.files?.[0])} />
      </label>
      {photo && <><img className="wk-thumb" src={photo} alt="Item photo preview" />
        <Action secondary onClick={() => setPhoto(undefined)}>Remove photo</Action></>}
    </div>
    <label className="wk-check">
      <input type="checkbox" name="private" defaultChecked={privateMode || !!editing?.private} disabled={privateMode} /> Keep on this device
    </label>
    <Feedback error={error} />
    <div className="wk-actions"><button type="submit" className="wk-button" disabled={busy || decoding}>{decoding ? 'Reading photo…' : busy ? 'Saving…' : 'Save item'}</button>
      <Action secondary onClick={onClose}>Cancel</Action></div>
  </form>
}

function Inventory({ data, mode, onInventoryChange, navigate }: WorkshopProps) {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('')
  const [editing, setEditing] = useState<InventoryItem | null | undefined>()
  const [error, setError] = useState('')
  const visible = data.inventory.filter(item =>
    (!filter || item.material === filter) && [item.name, item.material, item.condition].join(' ').toLowerCase().includes(query.trim().toLowerCase())
  )

  async function remove(item: InventoryItem) {
    if (!window.confirm('Delete “' + item.name + '” from your inventory?')) return
    setError('')
    try {
      await onInventoryChange({ id: item.id, deleted: true, private: item.private, updatedAt: now() })
    } catch (error) {
      setError(errorMessage(error))
    }
  }

  return <>
    <Heading tag="Workshop" title="Material Inventory" description="Catalog the things you already own and bring them into your next build."
      action={<Action onClick={() => setEditing(null)}><Plus size={18} /> Add item</Action>} />
    {editing !== undefined && <InventoryEditor key={editing?.id ?? 'new'} editing={editing} privateMode={mode === 'private'}
      onChange={onInventoryChange} onClose={() => setEditing(undefined)} />}
    <Feedback error={error} />
    {data.inventory.length ? <>
      <div className="wk-toolbar">
        <label className="wk-search"><Search size={18} /><span className="wk-sr">Search inventory</span>
          <input type="search" placeholder="Search inventory" value={query} onChange={event => setQuery(event.target.value)} />
        </label>
        <label className="wk-inline"><span>Material</span>
          <select value={filter} onChange={event => setFilter(event.target.value)}>
            <option value="">All materials</option>{materials.map(material => <option key={material}>{material}</option>)}
          </select>
        </label>
      </div>
      {visible.length ? <div className="wk-grid">
        {visible.map(item => <article className="wk-panel wk-card" key={item.id}>
          <div className="wk-item-visual">{item.photo ? <img src={item.photo} alt={item.name} /> : <Boxes size={29} aria-hidden="true" />}</div>
          <div className="wk-card-inner">
            <div className="wk-row wk-start"><div><h2>{item.name}</h2><p>{item.material} · {item.condition}</p></div>
              <span className="wk-chip">×{item.quantity}</span></div>
            {item.dimensions && <p>Size {item.dimensions}</p>}
            <p className="wk-muted">Added {new Date(item.addedAt).toLocaleDateString()}{item.private && ' · On this device'}</p>
            <div className="wk-actions">
              <button type="button" className="wk-button wk-secondary" onClick={() => setEditing(item)}><Pencil size={15} /> Edit</button>
              <button type="button" className="wk-icon-button" aria-label={'Delete ' + item.name} onClick={() => void remove(item)}><Trash2 size={17} /></button>
            </div>
          </div>
        </article>)}
      </div> : <Empty icon={<Search />} title="No matching items">Change the search or material filter to see more items.</Empty>}
    </> : <Empty icon={<Boxes />} title="Your shelf is empty" action={<Action onClick={() => setEditing(null)}><Plus size={18} /> Add a material</Action>}>
      Start with a useful offcut, a container, or an object that needs a second life.
    </Empty>}
    {navigate && data.inventory.length > 0 && <div className="wk-actions">
      <Action secondary onClick={() => navigate('projects')}><FolderOpen size={17} /> View saved projects</Action>
    </div>}
  </>
}

function chooseRecommendation(concepts: TransformationConcept[], input: CombinationInput) {
  const ranks = ['Beginner', 'Intermediate', 'Advanced']
  const available = input.tools.toLowerCase().split(/[,;\n]/).map(tool => tool.trim()).filter(Boolean)
  const score = (concept: TransformationConcept) => {
    const difficulty = Math.max(0, ranks.indexOf(concept.difficulty) - ranks.indexOf(input.experience))
    const overBudget = concept.currency !== input.budget.currency || concept.costMax > input.budget.maximum
    const missingTools = available.length ? concept.tools.filter(tool => !available.some(item => tool.toLowerCase().includes(item))).length : 0
    return (overBudget ? 100 : 0) + difficulty * 10 + missingTools
  }
  return concepts.reduce((best, concept, index) => score(concept) < score(concepts[best]) ? index : best, 0)
}

function Combinations({ route, data, mode, runCombination, onOpenConcept, navigate }: WorkshopProps) {
  const rescue = route === 'rescue'
  const [selected, setSelected] = useState<string[]>([])
  const [temporary, setTemporary] = useState<InventoryItem[]>([])
  const [newName, setNewName] = useState('')
  const [newMaterial, setNewMaterial] = useState('Wood')
  const [newCondition, setNewCondition] = useState('Good')
  const [maximum, setMaximum] = useState(25)
  const [currency, setCurrency] = useState('AED')
  const [experience, setExperience] = useState('Beginner')
  const [tools, setTools] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [answer, setAnswer] = useState<{ result: CombinationResult; input: CombinationInput; private: boolean }>()
  const available = [...temporary, ...data.inventory]
  const chosen = available.filter(item => selected.includes(item.id))

  function addTemporary(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const name = newName.trim()
    if (!name) return
    const item = { id: id(), name, quantity: 1, material: newMaterial, condition: newCondition, addedAt: now(), updatedAt: now() }
    setTemporary(previous => [...previous, item])
    setSelected(previous => [...previous, item.id])
    setNewName('')
  }

  async function run(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (chosen.length < 2 || chosen.length > 12) {
      setError('Choose 2 to 12 objects to find a combination.')
      return
    }
    setError('')
    setAnswer(undefined)
    setBusy(true)
    const input: CombinationInput = {
      items: chosen.map(item => ({ ...item, photo: undefined })),
      budget: { maximum, currency }, experience, tools, rescue
    }
    try {
      const result = await runCombination(input)
      if (!result.concepts.length) throw new Error('The AI returned no usable concepts. Add more details and try again.')
      setAnswer({ result, input, private: mode === 'private' || chosen.some(item => item.private) })
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setBusy(false)
    }
  }

  return <>
    <Heading tag={rescue ? 'Circular design' : 'Workshop'} title={rescue ? 'Rescue Mode' : 'Combine and Create'}
      description={rescue ? 'Select objects headed for disposal. Find a practical way to use them together before they go.' : 'Pair materials you already have and turn them into a single build.'} />
    <div className="wk-split">
      <section className="wk-panel wk-form">
        <div className="wk-row"><h2>{rescue ? 'Objects to rescue' : 'Available materials'}</h2><span className="wk-chip">{chosen.length} selected</span></div>
        {available.length ? <ul className="wk-pick-list">{available.map(item => <li key={item.id}>
          <label className="wk-check">
            <input type="checkbox" checked={selected.includes(item.id)} onChange={event => {
              const checked = event.target.checked
              setSelected(previous => checked ? [...previous, item.id] : previous.filter(value => value !== item.id))
            }} />
            <span><strong>{item.name}</strong><small>{item.material} · {item.condition} · Qty {item.quantity}</small></span>
          </label>
        </li>)}</ul> : <p className="wk-muted">Add two objects here or choose items from your inventory.</p>}
        <form className="wk-form wk-subform" onSubmit={addTemporary}>
          <label>Object name<input required maxLength={100} value={newName} onChange={event => setNewName(event.target.value)} placeholder="e.g. Old picture frame" /></label>
          <div className="wk-fields">
            <label>Material<select value={newMaterial} onChange={event => setNewMaterial(event.target.value)}>{materials.map(material => <option key={material}>{material}</option>)}</select></label>
            <label>Condition<select value={newCondition} onChange={event => setNewCondition(event.target.value)}>{conditions.map(condition => <option key={condition}>{condition}</option>)}</select></label>
          </div>
          <div className="wk-actions"><button className="wk-button wk-secondary" type="submit"><Plus size={17} /> Add object</button>
            {navigate && <Action secondary onClick={() => navigate('inventory')}>Manage inventory</Action>}</div>
        </form>
      </section>
      <form className="wk-panel wk-form" onSubmit={event => void run(event)}>
        <h2>Build constraints</h2>
        <div className="wk-fields">
          <label>Budget ceiling<input type="number" required min="0" max="100000" step="0.01" value={maximum}
            onChange={event => setMaximum(Number(event.target.value))} /></label>
          <label>Currency<select value={currency} onChange={event => setCurrency(event.target.value)}>{currencies.map(value => <option key={value}>{value}</option>)}</select></label>
        </div>
        <label>Experience<select value={experience} onChange={event => setExperience(event.target.value)}>
          {['Beginner', 'Intermediate', 'Advanced'].map(level => <option key={level}>{level}</option>)}
        </select></label>
        <label>Tools on hand<textarea maxLength={400} value={tools} placeholder="e.g. Scissors, sanding block, screwdriver"
          onChange={event => setTools(event.target.value)} /></label>
        <p className="wk-muted">Choose 2 to 12 objects. AI uses their descriptions and your build constraints.</p>
        <Feedback error={error} />
        <button className="wk-button" type="submit" disabled={busy}>{rescue ? <HeartHandshake size={18} /> : <GitMerge size={18} />}
          {busy ? 'Exploring combinations…' : rescue ? 'Find rescue concepts' : 'Generate combinations'}
        </button>
      </form>
    </div>
    {answer && <section className="wk-results" aria-label="Combination concepts">
      <h2>Transformation concepts</h2>
      <div className="wk-grid">{answer.result.concepts.map((concept, index) => {
        const recommended = rescue && index === (answer.result.recommendedIndex ?? chooseRecommendation(answer.result.concepts, answer.input))
        return <article className="wk-panel wk-form" key={concept.title + index}>
          {recommended && <span className="wk-chip wk-fit"><Check size={14} /> Best fit for your constraints</span>}
          <h3>{concept.title}</h3><p>{concept.description}</p>
          <div className="wk-chips"><span className="wk-chip">{concept.difficulty}</span><span className="wk-chip">{concept.duration}</span></div>
          <p className="wk-muted">Estimated cost {formatMoney(concept.costMin, concept.currency)} – {formatMoney(concept.costMax, concept.currency)}</p>
          <Action onClick={() => onOpenConcept(concept, {
            notes: 'Available objects: ' + answer.input.items.map(item => item.quantity + ' × ' + item.name + ' (' + item.material + ', ' + item.condition + ')').join(', '),
            objectCount: answer.input.items.reduce((total, item) => total + item.quantity, 0),
            private: answer.private
          })}>Open in studio</Action>
        </article>
      })}</div>
    </section>}
  </>
}

function Projects({ data, onOpenProject, onProjectChange, navigate }: WorkshopProps) {
  const [status, setStatus] = useState<'' | Project['status']>('')
  const [error, setError] = useState('')
  const shown = data.projects.filter(project => !status || project.status === status)

  async function change(project: Project, value: Project['status']) {
    setError('')
    try {
      await onProjectChange({
        ...project,
        status: value,
        completedAt: value === 'complete' ? project.completedAt ?? now() : undefined,
        updatedAt: now()
      })
    } catch (error) {
      setError(errorMessage(error))
    }
  }

  async function remove(project: Project) {
    if (!window.confirm('Delete “' + project.title + '”?')) return
    setError('')
    try {
      await onProjectChange({ id: project.id, deleted: true, private: project.private, updatedAt: now() })
    } catch (error) {
      setError(errorMessage(error))
    }
  }

  return <>
    <Heading tag="Project library" title="My Projects" description="Pick up a saved idea, revisit your visualizations, or track your progress."
      action={navigate && <Action onClick={() => navigate('scanner')}><Plus size={18} /> Start project</Action>} />
    <Feedback error={error} />
    {!!data.projects.length && <div role="group" aria-label="Filter projects by status" className="wk-tabs">
      <button type="button" aria-pressed={!status} onClick={() => setStatus('')}>All projects</button>
      {Object.entries(statuses).map(([value, label]) => <button key={value} type="button" aria-pressed={status === value}
        onClick={() => setStatus(value as Project['status'])}>{label}</button>)}
    </div>}
    {shown.length ? <div className="wk-grid">{shown.map(project => <article className="wk-panel wk-card" key={project.id}>
      <div className="wk-project-visual">
        {project.image || project.originalImage ? <img src={project.image?.dataUrl ?? project.originalImage}
          alt={project.image ? 'AI concept for ' + project.title : 'Original object for ' + project.title} /> : <FolderOpen size={36} aria-hidden="true" />}
        {(project.image || project.example) && <span className="wk-image-badge">{project.example ? 'Example project' : 'AI concept'}</span>}
      </div>
      <div className="wk-card-inner">
        <div className="wk-row wk-start"><div><h2>{project.title}</h2><p>{project.concept.difficulty} · {project.concept.duration}</p></div>
          {project.private && <span className="wk-chip"><ShieldCheck size={14} /> Private</span>}</div>
        {project.guide && <p className="wk-muted">{project.completedSteps.length} of {project.guide.steps.length} steps checked</p>}
        <label className="wk-inline">Status
          <select value={project.status} aria-label={'Status of ' + project.title} onChange={event => void change(project, event.target.value as Project['status'])}>
            {Object.entries(statuses).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </label>
        <div className="wk-row"><Action onClick={() => onOpenProject(project)}>Open project</Action>
          <button type="button" className="wk-icon-button" aria-label={'Delete ' + project.title} onClick={() => void remove(project)}><Trash2 size={17} /></button>
        </div>
      </div>
    </article>)}</div> : <Empty icon={<FolderOpen />} title={status ? 'No projects with this status' : 'Your project library is empty'}
      action={!status && navigate && <Action onClick={() => navigate('scanner')}>Scan an object</Action>}>
      {status ? 'Choose a different filter to see more saved builds.' : 'Save a transformation concept from the studio to find it here.'}
    </Empty>}
  </>
}

function defaultBudget(currency = 'AED'): BudgetEstimate {
  return { currency, maximum: 25, replacementCost: null, lines: [] }
}

function Budget({ data, onProjectChange, navigate }: WorkshopProps) {
  const [projectId, setProjectId] = useState('')
  const [budget, setBudget] = useState<BudgetEstimate>(() => defaultBudget())
  const [preset, setPreset] = useState('25')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const project = data.projects.find(item => item.id === projectId)
  const amounts = calculateBudget(budget)

  function select(nextId: string) {
    setProjectId(nextId)
    const nextProject = data.projects.find(item => item.id === nextId)
    const nextBudget = nextProject?.budget ?? defaultBudget(nextProject?.concept.currency)
    setBudget(nextBudget)
    setPreset([0, 25, 50, 100].includes(nextBudget.maximum) ? String(nextBudget.maximum) : 'custom')
    setMessage('')
    setError('')
  }

  function changeBudget(next: Partial<BudgetEstimate>) {
    setMessage('')
    setError('')
    setBudget(previous => ({ ...previous, ...next }))
  }

  function changeLine(lineId: string, next: Partial<BudgetLine>) {
    setMessage('')
    setError('')
    setBudget(previous => ({ ...previous, lines: previous.lines.map(line => line.id === lineId ? { ...line, ...next } : line) }))
  }

  function conceptEstimate() {
    if (!project) return
    const concept = project.concept
    if (budget.currency !== concept.currency) {
      setMessage('')
      setError('Set the currency to ' + concept.currency + ' to use the concept estimate.')
      return
    }
    setError('')
    const midpointCents = Math.round((concept.costMin + concept.costMax) * 50)
    const owned = data.inventory.map(item => item.name.trim().toLowerCase())
    const missing = (items: string[]) => items.some(item => !owned.includes(item.toLowerCase()))
    const weights = [
      { category: 'Materials' as const, name: 'Additional supplies (estimate)', weight: missing(concept.materials) ? 65 : 0 },
      { category: 'Tools' as const, name: 'Tool access (estimate)', weight: missing(concept.tools) ? 25 : 0 },
      { category: 'Decor' as const, name: 'Decorative supplies (estimate)', weight: ['Home decoration', 'Art and creativity'].includes(concept.category) ? 10 : 0 }
    ]
    const weightTotal = weights.reduce((sum, entry) => sum + entry.weight, 10)
    const lines = weights.map(({ category, name, weight }) => ({
      id: 'concept-estimate-' + category,
      category,
      name,
      quantity: 1,
      price: Math.floor(midpointCents * weight / weightTotal) / 100
    }))
    const remaining = (midpointCents - lines.reduce((sum, line) => sum + Math.round(line.price * 100), 0)) / 100
    changeBudget({
      lines: [
        ...budget.lines.filter(line => !line.id.startsWith('concept-estimate-')),
        ...lines,
        { id: 'concept-estimate-Other', name: 'Other expenses (estimate)', category: 'Other', quantity: 1, price: remaining }
      ]
    })
    setMessage('Drafted from the concept’s estimated cost range, with larger shares for missing supplies and tools. Adjust each price for your build.')
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!project) return
    if (budget.lines.some(line => !line.name.trim())) {
      setError('Give each expense a name before saving.')
      return
    }
    setError('')
    setMessage('')
    setBusy(true)
    try {
      await onProjectChange({ ...project, budget, updatedAt: now() })
      setMessage('Budget saved to ' + project.title + '.')
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setBusy(false)
    }
  }

  return <>
    <Heading tag="Workshop" title="Smart Budget Planner" description="Set a spending ceiling, itemize your costs, and test whether a reuse project fits." />
    <div className="wk-stats">
      <Stat icon={<Wallet />} label="Estimated total" value={formatMoney(amounts.total, budget.currency)} />
      <Stat icon={<ClipboardList />} label={amounts.remaining < 0 ? 'Above budget' : 'Budget remaining'} value={formatMoney(Math.abs(amounts.remaining), budget.currency)} />
      <Stat icon={<Leaf />} label={amounts.savings !== null && amounts.savings < 0 ? 'Extra cost vs. replacement' : 'Estimated savings'} value={
        amounts.savings === null ? '—' : formatMoney(Math.abs(amounts.savings), budget.currency)
      } />
    </div>
    <form className="wk-panel wk-form" onSubmit={event => void save(event)}>
      <div className="wk-row">
        <div><h2>Budget details</h2><p className="wk-muted">Prices are your estimates. Currency changes keep the entered amounts.</p></div>
        {project && <Action secondary onClick={conceptEstimate}>Add concept estimate</Action>}
      </div>
      <div className="wk-fields wk-fields-four">
        <label>Saved project<select value={projectId} onChange={event => select(event.target.value)}>
          <option value="">Planning a new project</option>{data.projects.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}
        </select></label>
        <label>Currency<select value={budget.currency} onChange={event => changeBudget({ currency: event.target.value })}>
          {Array.from(new Set([...currencies, budget.currency])).map(value => <option key={value}>{value}</option>)}
        </select></label>
        <label>Spending limit<select value={preset} onChange={event => {
          setPreset(event.target.value)
          if (event.target.value !== 'custom') changeBudget({ maximum: Number(event.target.value) })
        }}><option value="0">Zero spending</option><option value="25">Up to {budget.currency} 25</option>
          <option value="50">Up to {budget.currency} 50</option><option value="100">Up to {budget.currency} 100</option><option value="custom">Custom budget</option>
        </select></label>
        {preset === 'custom' && <label>Custom limit<input type="number" min="0" max="1000000" step="0.01" required value={budget.maximum}
          onChange={event => changeBudget({ maximum: Number(event.target.value) })} /></label>}
        <label>Replacement cost <span className="wk-muted">(optional)</span><input type="number" min="0" max="1000000" step="0.01"
          placeholder="Comparable new item" value={budget.replacementCost ?? ''} onChange={event =>
            changeBudget({ replacementCost: event.target.value === '' ? null : Number(event.target.value) })
          } /></label>
      </div>
      <div className="wk-row"><h3>Expenses</h3>
        <Action secondary onClick={() => changeBudget({ lines: [...budget.lines, { id: id(), name: '', category: 'Materials', quantity: 1, price: 0 }] })}>
          <Plus size={17} /> Add expense
        </Action></div>
      {budget.lines.length ? <div className="wk-budget-lines">
        {budget.lines.map((line, index) => <div className="wk-budget-line" key={line.id}>
          <label>Expense<input required maxLength={120} aria-label={'Expense ' + (index + 1)} value={line.name} onChange={event => changeLine(line.id, { name: event.target.value })} placeholder="e.g. Sandpaper" /></label>
          <label>Category<select value={line.category} aria-label={'Expense ' + (index + 1) + ' category'}
            onChange={event => changeLine(line.id, { category: event.target.value as BudgetCategory })}>{categories.map(value => <option key={value}>{value}</option>)}
          </select></label>
          <label>Quantity<input required type="number" min="0" max="10000" step="0.01" value={line.quantity}
            aria-label={'Expense ' + (index + 1) + ' quantity'} onChange={event => changeLine(line.id, { quantity: Number(event.target.value) })} /></label>
          <label>Unit price<input required type="number" min="0" max="1000000" step="0.01" value={line.price}
            aria-label={'Expense ' + (index + 1) + ' unit price'} onChange={event => changeLine(line.id, { price: Number(event.target.value) })} /></label>
          <button type="button" className="wk-icon-button" aria-label={'Remove ' + (line.name || 'expense ' + (index + 1))}
            onClick={() => changeBudget({ lines: budget.lines.filter(item => item.id !== line.id) })}><Trash2 size={17} /></button>
        </div>)}
      </div> : <p className="wk-muted">Add any materials, tools, decor, or other purchases you’ll need.</p>}
      <div className="wk-budget-total">
        {categories.map(category => <div key={category}><span>{category}</span>
          <strong>{formatMoney(budget.lines.filter(line => line.category === category).reduce((sum, line) => sum + line.quantity * line.price, 0), budget.currency)}</strong>
        </div>)}
      </div>
      <Feedback error={error} message={message} />
      {project ? <button className="wk-button" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save budget to project'}</button>
        : <div className="wk-actions"><p className="wk-muted">{data.projects.length ? 'Select a saved project to keep this budget.' : 'Save a concept in the studio to keep its budget here.'}</p>
          {navigate && !data.projects.length && <Action secondary onClick={() => navigate('scanner')}>Start a project</Action>}</div>}
    </form>
  </>
}

function Stat({ icon, label, value, detail }: { icon: ReactNode; label: string; value: string | number; detail?: string }) {
  return <article className="wk-panel wk-stat">
    <span className="wk-icon" aria-hidden="true">{icon}</span>
    <div><p>{label}</p><strong>{value}</strong>{detail && <small>{detail}</small>}</div>
  </article>
}

function ImpactEditor({ record, data, privateMode, onChange, onClose }: {
  record?: SustainabilityRecord
  data: WorkshopData
  privateMode: boolean
  onChange: WorkshopProps['onImpactChange']
  onClose: () => void
}) {
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const fields = new FormData(event.currentTarget)
    const projectId = String(fields.get('projectId') ?? '') || undefined
    const linkedProject = data.projects.find(project => project.id === projectId)
    const weightKg = Number(fields.get('weightKg'))
    const savingsValue = fields.get('savings')
    const savings = savingsValue === '' ? undefined : Number(savingsValue)
    setBusy(true)
    setError('')
    try {
      await onChange({
        id: record?.id ?? id(),
        projectId,
        weightKg,
        savings,
        currency: String(fields.get('currency')),
        material: String(fields.get('material')),
        recordedAt: record?.recordedAt ?? now(),
        updatedAt: now(),
        private: privateMode || linkedProject?.private || record?.private
      })
      onClose()
    } catch (error) {
      setError(errorMessage(error))
    } finally {
      setBusy(false)
    }
  }
  return <form className="wk-panel wk-form" onSubmit={event => void save(event)}>
    <div className="wk-row"><h2>{record ? 'Edit measurement' : 'Record a measurement'}</h2>
      <button type="button" className="wk-icon-button" aria-label="Close measurement editor" onClick={onClose}><X size={18} /></button></div>
    <div className="wk-fields wk-fields-four">
      <label>Material<select name="material" defaultValue={record?.material}>{materials.map(value => <option key={value}>{value}</option>)}</select></label>
      <label>Material reused (kg)<input required name="weightKg" type="number" min="0.001" max="100000" step="0.001" defaultValue={record?.weightKg} placeholder="e.g. 0.75" /></label>
      <label>Estimated money saved<input name="savings" type="number" min="0" max="1000000" step="0.01" defaultValue={record?.savings} placeholder="Optional" /></label>
      <label>Currency<select name="currency" defaultValue={record?.currency ?? 'AED'}>{currencies.map(value => <option key={value}>{value}</option>)}</select></label>
      <label>Related project<select name="projectId" defaultValue={record?.projectId ?? ''}><option value="">Optional</option>
        {data.projects.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
    </div>
    <p className="wk-muted">Use a measured weight. For savings, enter your own estimate based on what a comparable new item would cost.</p>
    <Feedback error={error} />
    <button className="wk-button" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save measurement'}</button>
  </form>
}

function Impact({ data, mode, onImpactChange }: WorkshopProps) {
  const [editing, setEditing] = useState<SustainabilityRecord | null | undefined>(undefined)
  const [metric, setMetric] = useState<'kilograms' | 'completed'>('kilograms')
  const [month, setMonth] = useState<number | null>(null)
  const [error, setError] = useState('')
  const report = calculateImpact(data.projects, data.impact)
  const chartMax = Math.max(0.1, ...report.months.map(item => item[metric]))
  const selectedMonth = month === null ? undefined : report.months[month]
  const savings = [...report.savings.entries()]
  const savedSummary = savings.length ? savings.map(([currency, amount]) => formatMoney(amount, currency)).join(' + ') : '—'

  async function remove(record: SustainabilityRecord) {
    if (!window.confirm('Delete this impact measurement?')) return
    setError('')
    try {
      await onImpactChange({ id: record.id, deleted: true, private: record.private, updatedAt: now() })
    } catch (error) {
      setError(errorMessage(error))
    }
  }

  return <>
    <Heading tag="Sustainability" title="Environmental Impact" description="Track the items you give a second life and the materials you keep in use."
      action={<Action onClick={() => setEditing(null)}><Plus size={17} /> Record impact</Action>} />
    <div className="wk-stats wk-four-stats">
      <Stat icon={<Recycle />} label="Objects repurposed" value={report.objectsRepurposed} detail="From completed projects" />
      <Stat icon={<Check />} label="Completed projects" value={report.completed} detail={data.projects.filter(project => !project.example).length + ' projects saved'} />
      <Stat icon={<Weight />} label="Material reused" value={Number(report.kilograms.toFixed(3)) + ' kg'} detail="From your measurements" />
      <Stat icon={<Wallet />} label="Estimated savings" value={savedSummary} detail="From your entries" />
    </div>
    {editing !== undefined && <ImpactEditor key={editing?.id ?? 'new'} record={editing ?? undefined} data={data} privateMode={mode === 'private'}
      onChange={onImpactChange} onClose={() => setEditing(undefined)} />}
    <Feedback error={error} />
    <div className="wk-split">
      <section className="wk-panel wk-form">
        <h2>Monthly progress</h2>
        <div role="group" aria-label="Progress chart metric" className="wk-tabs">
          <button type="button" aria-pressed={metric === 'kilograms'} onClick={() => setMetric('kilograms')}>Material reused</button>
          <button type="button" aria-pressed={metric === 'completed'} onClick={() => setMetric('completed')}>Projects completed</button>
        </div>
        <div className="wk-bars" aria-label="Monthly data">
          {report.months.map((item, index) => <button type="button" key={item.key} onClick={() => setMonth(index)}
            aria-pressed={month === index} aria-label={item.label + ' · ' + Number(item[metric].toFixed(3)) + (metric === 'kilograms' ? ' kilograms' : ' completed projects')}>
            <span className="wk-bar-well"><span className="wk-bar" style={{ height: ((item[metric] / chartMax) * 100) + '%' }} /></span>
            <span>{item.label}</span>
          </button>)}
        </div>
        <p className="wk-muted" role="status">{selectedMonth
          ? selectedMonth.label + ' · ' + Number(selectedMonth[metric].toFixed(3)) + (metric === 'kilograms' ? ' kg reused' : ' projects completed')
          : 'Select a month to see its total.'}</p>
      </section>
      <section className="wk-panel wk-form">
        <h2>Materials in use</h2>
        {report.materials.length ? <dl className="wk-material-bars">{report.materials.map(([material, kilograms]) => <div key={material}>
          <div className="wk-row"><dt>{material}</dt><dd>{Number(kilograms.toFixed(3))} kg</dd></div>
          <progress value={kilograms} max={report.kilograms} aria-label={material + ' share of measured weight'} />
        </div>)}</dl> : <p className="wk-muted">Your recorded materials appear here.</p>}
        <h3>Project status</h3>
        <dl className="wk-project-counts">{Object.entries(statuses).map(([value, label]) => <div className="wk-row" key={value}>
          <dt>{label}</dt><dd>{data.projects.filter(item => !item.example && item.status === value).length}</dd>
        </div>)}</dl>
      </section>
    </div>
    <section className="wk-panel wk-form">
      <h2>Recorded measurements</h2>
      <p className="wk-muted">Material totals use the weights you enter. Savings use your estimates and are totaled by currency.</p>
      {data.impact.length > 0 ? <ul className="wk-records">
        {data.impact.map(record => <li className="wk-row" key={record.id}>
          <div><strong>{record.material} · {record.weightKg} kg</strong><p>{new Date(record.recordedAt).toLocaleDateString()}
            {record.savings !== undefined && ' · ' + formatMoney(record.savings, record.currency) + ' estimated savings'}</p></div>
          <div className="wk-actions">
            <button className="wk-icon-button" type="button" aria-label={'Edit ' + record.material + ' measurement'} onClick={() => setEditing(record)}><Pencil size={17} /></button>
            <button className="wk-icon-button" type="button" aria-label={'Delete ' + record.material + ' measurement'} onClick={() => void remove(record)}><Trash2 size={17} /></button>
          </div>
        </li>)}
      </ul> : <p className="wk-muted">Your impact log is empty.</p>}
    </section>
  </>
}

const availabilityText: Record<string, string> = {
  available: 'Available', downloadable: 'Available to download', downloading: 'Downloading',
  unavailable: 'Unavailable', unknown: 'Unknown'
}

const sourceText = { 'on-device': 'On-device', cloud: 'Cloud', unknown: 'Unknown' }
const taskText = { analysis: 'Object analysis', concepts: 'Concept generation', guide: 'Construction guide', assistant: 'Design assistant', image: 'Image generation' }

function Transparency({ data, mode, online, availability, navigate }: WorkshopProps) {
  const latest = data.inference[0]
  const count = data.inference.reduce((total, event) => {
    if (event.source === 'on-device') total.local++
    if (event.source === 'cloud') total.cloud++
    if (event.fallback && event.status === 'success') total.fallback++
    if (event.status === 'failed') total.failed++
    return total
  }, { local: 0, cloud: 0, fallback: 0, failed: 0 })
  const availabilityState = availability ?? 'unknown'
  return <>
    <Heading tag="Privacy and performance" title="AI Transparency" description="See where inference ran, how long it took, and which model Firebase reported."
      action={navigate && <Action secondary onClick={() => navigate('settings')}><ShieldCheck size={17} /> AI settings</Action>} />
    <div className="wk-stats wk-four-stats">
      <Stat icon={<Cpu />} label="On-device requests" value={count.local} />
      <Stat icon={<Cloud />} label="Cloud requests" value={count.cloud} />
      <Stat icon={<GitMerge />} label="Successful fallbacks" value={count.fallback} />
      <Stat icon={<Activity />} label="Failed requests" value={count.failed} />
    </div>
    <div className="wk-split">
      <section className="wk-panel wk-form">
        <h2>Inference status</h2>
        <dl className="wk-detail">
          <div><dt>Active mode</dt><dd className="wk-capitalize">{mode}</dd></div>
          <div><dt>Local model</dt><dd><span className={'wk-chip wk-source-' + (availabilityState === 'available' ? 'on-device' : availabilityState === 'unknown' ? 'unknown' : 'warning')}>
            {availabilityText[availabilityState] ?? availabilityState}
          </span></dd></div>
          <div><dt>Connection</dt><dd>{online ? <Wifi size={16} /> : <WifiOff size={16} />} {online ? 'Online' : 'Offline'}</dd></div>
        </dl>
      </section>
      <section className="wk-panel wk-form">
        <h2>Latest request</h2>
        {latest ? <dl className="wk-detail">
          <div><dt>Observed source</dt><dd><span className={'wk-chip wk-source-' + latest.source}>{sourceText[latest.source]}</span></dd></div>
          <div><dt>Reported model</dt><dd>{latest.model ?? 'Unavailable'}</dd></div>
          <div><dt>Measured latency</dt><dd><Clock3 size={16} /> {latest.latencyMs.toLocaleString()} ms</dd></div>
        </dl> : <p className="wk-muted">Run an AI task to see its measured details.</p>}
      </section>
    </div>
    <section className="wk-panel wk-form">
      <h2>Recent inference events</h2>
      <p className="wk-muted">This device records request metadata. Prompts and photos are excluded.</p>
      {data.inference.length > 0 ? <ul className="wk-records">
        {data.inference.slice(0, 30).map(event => <li key={event.id} className="wk-row">
          <div><strong>{taskText[event.task]}</strong><p>{new Date(event.timestamp).toLocaleString()} · {event.latencyMs.toLocaleString()} ms
            {event.fallback && ' · Cloud fallback'}</p></div>
          <span className={'wk-chip ' + (event.status === 'failed' ? 'wk-source-warning' : 'wk-source-' + event.source)}>
            {event.status === 'failed' ? 'Failed' : sourceText[event.source]}
          </span>
        </li>)}
      </ul> : <Empty icon={<Activity />} title="No inference events yet">Run a scan or generate a design concept to begin.</Empty>}
    </section>
  </>
}

function Help() {
  return <>
    <Heading tag="Support" title="Help & Safety" description="Prepare your workspace, understand AI availability, and make informed choices about a build." />
    <div className="wk-split">
      <section className="wk-panel wk-form">
        <span className="wk-icon"><ShieldCheck size={22} /></span><h2>Work safely</h2>
        <p>Inspect an item for sharp edges, rot, chemical residue, cracks, or instability before you handle or alter it. Wear suitable protection and follow the instructions for the real tools and materials you use.</p>
        <p>Leave batteries, mains-powered equipment, gas equipment, pressure vessels, and load-bearing components for a qualified professional. Follow local waste guidance for items that could be hazardous.</p>
        <p>Check all measurements and load limits yourself. Concept images are design illustrations and estimated dimensions require verification on the actual object.</p>
      </section>
      <section className="wk-panel wk-form">
        <span className="wk-icon"><HelpCircle size={22} /></span><h2>Using your workshop</h2>
        <details><summary>Open as an installed app</summary><p>Open ReImagine AI in Chrome. Use the install icon in the address bar or the browser menu when offered. Launch it online once to cache the app shell.</p></details>
        <details><summary>Use the camera or an uploaded photo</summary><p>Allow camera access when prompted, or upload a JPEG or PNG. Crop out people, addresses, and anything else you want to keep out of the scan.</p></details>
        <details><summary>Work offline</summary><p>Open a cached app to browse saved projects, review guides, and edit inventory. On-device AI requires a compatible browser and a model already downloaded on your device.</p></details>
        <details><summary>Handle unavailable AI services</summary><p>Check AI Transparency for the current mode and device availability. An offline or unavailable cloud service can also affect image generation. Saved guides and project data remain available locally.</p></details>
      </section>
    </div>
  </>
}

const pages = {
  inventory: Inventory, combine: Combinations, rescue: Combinations, budget: Budget,
  projects: Projects, impact: Impact, transparency: Transparency, help: Help
}

export function Workshop(props: WorkshopProps) {
  const Page = pages[props.route]
  return <section className="wk" aria-label="Workshop"><Page key={props.route} {...props} /></section>
}

export default Workshop
