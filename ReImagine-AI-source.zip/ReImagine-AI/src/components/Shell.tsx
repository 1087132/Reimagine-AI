import { useEffect, useState, type ReactNode } from 'react'
import { Activity, Boxes, Camera, CircleHelp, ClipboardList, FolderOpen, House, Leaf, Menu, Recycle, ScanLine, Settings, Sparkles, Sprout, WalletCards, WifiOff, X } from 'lucide-react'

export const routeNames = {
  home: 'Overview', landing: 'About', scanner: 'Object Scanner', studio: 'Transformation Studio',
  image: 'Image Studio', compare: 'Before & After', guide: 'Construction Guide',
  projects: 'My Projects', inventory: 'Material Inventory', combine: 'Combine & Create', rescue: 'Rescue Mode',
  budget: 'Budget Planner', impact: 'Impact Dashboard', transparency: 'AI Transparency',
  settings: 'Settings & Privacy', help: 'Help & Safety', account: 'Sign In',
} as const
export type Route = keyof typeof routeNames
export const urlFor = (route: Route) => route === 'home' ? '#/' : '#/' + route

const sections = [
  { name: 'Workspace', items: [
    ['home', House], ['scanner', ScanLine], ['studio', Sparkles], ['projects', FolderOpen],
  ] },
  { name: 'Your materials', items: [
    ['inventory', Boxes], ['combine', Sprout], ['rescue', Recycle], ['budget', WalletCards],
  ] },
  { name: 'Insights', items: [
    ['impact', Leaf], ['transparency', Activity],
  ] },
] as const

export function Brand() {
  return <span className="brand"><img src="/icon.svg" alt="" width={38} height={38} />
    <span><strong>ReImagine<span className="brand-ai"> AI</span></strong><small>UPCYCLING STUDIO</small></span>
  </span>
}

export function PageTitle({ title, description, children }: {title: string; description?: string; children?: ReactNode}) {
  return <div className="page-heading"><div><h1>{title}</h1>{description && <p>{description}</p>}</div>{children}</div>
}

export function Shell({ route, mode, online, account, children }: {
  route: Route; mode: string; online: boolean; account?: string; children: ReactNode
}) {
  const [open, setOpen] = useState(false)
  useEffect(() => {
    if (!open) return
    function closeOnEscape(event: KeyboardEvent) { if (event.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', closeOnEscape)
    return () => window.removeEventListener('keydown', closeOnEscape)
  }, [open])
  const selected = ['image', 'compare', 'guide'].includes(route) ? 'studio' : route
  return <>
    <a className="skip-link" href="#main-content" onClick={e => { e.preventDefault(); document.getElementById('main-content')?.focus() }}>Skip to content</a>
    <div className="app-shell">
      {open && <button type="button" className="mobile-backdrop" aria-label="Close navigation" onClick={() => setOpen(false)} />}
      <aside className={'sidebar' + (open ? ' open' : '')} id="site-sidebar">
        <a className="brand-link" href={urlFor('home')} onClick={() => setOpen(false)} aria-label="ReImagine AI home"><Brand /></a>
        <nav aria-label="Main navigation" onClick={() => setOpen(false)}>
          {sections.map(section => <div className="nav-group" key={section.name}>
            <div className="nav-label">{section.name}</div>
            {section.items.map(([key, Icon]) => <a key={key} href={urlFor(key)} className={'nav-link' + (selected === key ? ' current' : '')} aria-current={selected === key ? 'page' : undefined}>
              <Icon size={18} aria-hidden="true" /><span>{routeNames[key]}</span>
            </a>)}
          </div>)}
          <div className="nav-group nav-end">
            <a className={'nav-link' + (route === 'settings' ? ' current' : '')} href={urlFor('settings')} aria-current={route === 'settings' ? 'page' : undefined}><Settings size={18} />{routeNames.settings}</a>
            <a className={'nav-link' + (route === 'help' ? ' current' : '')} href={urlFor('help')} aria-current={route === 'help' ? 'page' : undefined}><CircleHelp size={18} />{routeNames.help}</a>
          </div>
        </nav>
        <a className="account-link" href={urlFor('account')} onClick={() => setOpen(false)}>
          <span className="account-avatar">{account ? account.charAt(0).toUpperCase() : <Leaf size={17} />}</span>
          <span><strong>{account || 'Guest workspace'}</strong><small>{account ? 'Manage account' : 'Sign in or register'}</small></span>
        </a>
      </aside>
      <div className="app-content">
        <header className="app-header">
          <div className="header-location">
            <button type="button" className="icon-button menu-button" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="site-sidebar" onClick={() => setOpen(!open)}>
              {open ? <X size={21} /> : <Menu size={21} />}
            </button>
            <span>Workspace</span><span className="crumb-slash">/</span><strong>{routeNames[route]}</strong>
          </div>
          <div className="header-status">
            <span className="connectivity">{online ? <span className="status-dot" /> : <WifiOff size={15} />}{online ? 'Online' : 'Offline'}</span>
            <a className="mode-pill" href={urlFor('transparency')}><Activity size={15} /><span>{mode} mode</span></a>
          </div>
        </header>
        <main tabIndex={-1} id="main-content" className="content-wrap">{children}</main>
        <footer className="app-footer"><span>ReImagine AI · Built for #BuildHybridAI</span><a href={urlFor('landing')}>About ReImagine</a></footer>
      </div>
    </div>
  </>
}

const quickActions = [
  { route: 'scanner', icon: Camera, title: 'Scan an object', detail: 'Find out what your item could become.', tone: 'green' },
  { route: 'rescue', icon: Recycle, title: 'Try Rescue Mode', detail: 'Turn a few unwanted items into one project.', tone: 'gold' },
  { route: 'inventory', icon: ClipboardList, title: 'Material inventory', detail: 'Keep track of the materials you already own.', tone: 'purple' },
] as const

export function Home({ landing, openExamples, onExample, busy }: {
  landing: boolean; openExamples: () => void; onExample: (id: string) => void; busy: boolean
}) {
  return <>
    <PageTitle title={landing ? 'About ReImagine AI' : 'Your workshop'} description={landing ? 'An upcycling studio powered by Firebase AI Logic.' : 'Make something new with what you already have.'} />
    <section className="hero" aria-label="Start an upcycling project">
      <div className="hero-copy">
        <div className="hero-kicker"><Sprout size={16} /> THE UPCYCLING STUDIO</div>
        <h2>Give good things<br /><em>a second life.</em></h2>
        <p>Don’t throw it away. ReImagine it.</p>
        <div className="hero-actions">
          <a className="button hero-primary" href={urlFor('scanner')}><ScanLine size={19} /> Scan an object</a>
          <button type="button" className="button hero-secondary" onClick={openExamples}>Explore examples</button>
        </div>
      </div>
      <div className="hero-caption"><span /> REIMAGINED WOOD & GLASS</div>
    </section>
    {landing ? <section className="panel about-panel">
      <h2>From an object to a project</h2><p>Photograph something you’re ready to discard. On supported Chrome devices, Firebase AI Logic can identify likely materials and suggest reuse ideas on-device. With your permission, cloud models can help refine a guide or visualize the finished concept.</p>
      <p>Save projects and inventory in your browser. Choose Private mode for local-only AI when the on-device model is available.</p>
    </section> : <section className="quick-section" aria-labelledby="quick-heading">
      <h2 id="quick-heading">Quick start</h2>
      <div className="quick-grid">{quickActions.map(({ route, icon: Icon, title, detail, tone }) => (
        <a href={urlFor(route)} className="quick-card" key={route}><span className={'quick-icon ' + tone}><Icon size={21} /></span>
          <span><strong>{title}</strong><small>{detail}</small></span>
        </a>
      ))}</div>
    </section>}
    <section className="examples-section" id="examples" aria-labelledby="examples-heading">
      <div className="section-intro"><div><h2 id="examples-heading" tabIndex={-1}>Inspiration gallery</h2><p>Explore preloaded projects and see what upcycling can look like.</p></div></div>
      <div className="example-grid">
        {[
          { id: 'herb', title: 'Windowsill Herb Garden', alt: 'A vintage wooden caddy filled with potted herbs', text: 'Wood · Beginner · 30–45 min' },
          { id: 'jars', title: 'Glass Jar Propagation Station', alt: 'Reused jam jars with rooted plant cuttings', text: 'Glass · Beginner · 15–25 min' },
        ].map(example => <article className="example-card" key={example.id}>
          <div className="example-photo"><img src={'/images/' + example.id + '-after.jpg'} alt={example.alt} /><span>EXAMPLE PROJECT</span></div>
          <div className="example-copy"><div><h3>{example.title}</h3><p>{example.text}</p></div>
            <button className="button secondary small" disabled={busy} onClick={() => onExample(example.id)} type="button">Open example</button>
          </div>
        </article>)}
      </div>
    </section>
  </>
}
