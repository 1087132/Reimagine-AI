import { useEffect, useRef, useState } from 'react'
import { ChevronsLeftRight, Maximize, Minus, Plus, X } from 'lucide-react'

export default function Comparison({ before, after, example }: { before: string; after: string; example?: boolean }) {
  const [reveal, setReveal] = useState(50)
  const [zoom, setZoom] = useState(1)
  const [fullscreen, setFullscreen] = useState(false)
  const dialog = useRef<HTMLDialogElement>(null)
  const trigger = useRef<HTMLButtonElement>(null)
  useEffect(() => {
    if (fullscreen && dialog.current && !dialog.current.open) dialog.current.showModal()
  }, [fullscreen])
  const image = (suffix: string) => <div className="comparison-frame">
    <div className="compare-image" style={{ '--zoom': zoom, '--reveal': reveal + '%' } as React.CSSProperties}>
      <img src={before} alt={example ? 'Before — example original object' : 'Before — original object'} draggable={false} />
      <img className="compare-after" src={after} alt="After — AI-generated concept" draggable={false} />
    </div>
    <span className="compare-badge compare-before-label">Before</span>
    <span className="compare-badge compare-after-label">After · AI concept</span>
    <label className="visually-hidden" htmlFor={'reveal-' + suffix}>Reveal after image</label>
    <input id={'reveal-' + suffix} className="compare-range" type="range" min="0" max="100" value={reveal} onChange={e => setReveal(Number(e.target.value))} />
    <span aria-hidden="true" className="compare-divider" style={{ left: reveal + '%' }}><span><ChevronsLeftRight size={22} /></span></span>
  </div>
  const zoomControls = <><button type="button" className="icon-button" aria-label="Zoom out" onClick={() => setZoom(Math.max(1, zoom - 0.25))} disabled={zoom <= 1}><Minus size={18} /></button>
    <output aria-label="Zoom level">{Math.round(zoom * 100)}%</output>
    <button type="button" className="icon-button" aria-label="Zoom in" onClick={() => setZoom(Math.min(2, zoom + 0.25))} disabled={zoom >= 2}><Plus size={18} /></button></>
  return <>
    {image('page')}
    <div className="comparison-tools">{zoomControls}
      <button ref={trigger} type="button" className="button secondary small" onClick={() => setFullscreen(true)}><Maximize size={16} /> Fullscreen</button>
    </div>
    {fullscreen && <dialog className="comparison-modal" aria-label="Fullscreen comparison" ref={dialog} onClose={() => { setFullscreen(false); requestAnimationFrame(() => trigger.current?.focus()) }}>
      <div className="comparison-tools"><strong>Before &amp; After</strong>{zoomControls}<button type="button" className="icon-button" aria-label="Close fullscreen" onClick={() => dialog.current?.close()}><X size={21} /></button></div>
      {image('fullscreen')}
    </dialog>}
  </>
}
