import { z } from 'zod';

const short = z.string().trim().min(1).max(260);
const text = z.string().trim().min(1).max(1800);
const list = z.array(short).max(16);
const isoTime = z.iso.datetime();

export const projectCategories = [
  'Home decoration', 'Garden and outdoor', 'Furniture', 'Art and creativity', 'Organization and storage'
] as const;

export const objectAnalysisSchema = z.object({
  name: short,
  category: short,
  materials: list,
  condition: text,
  components: list,
  damage: list,
  potential: text,
  safety: list,
  confidence: z.enum(['low', 'medium', 'high']),
  uncertainty: text,
  hazardous: z.boolean().optional()
});

export const transformationConceptSchema = z.object({
  title: short,
  description: text,
  difficulty: z.enum(['Beginner', 'Intermediate', 'Advanced']),
  duration: short,
  costMin: z.number().finite().min(0).max(1000000),
  costMax: z.number().finite().min(0).max(1000000),
  currency: z.string().regex(/^[A-Z]{3}$/),
  category: z.enum(projectCategories),
  materials: list,
  tools: list,
  benefits: list,
  limitations: list,
  safety: list
}).refine(({ costMin, costMax }) => costMin <= costMax, { message: 'Invalid cost range' });

export const conceptsResponseSchema = z.object({ concepts: z.array(transformationConceptSchema).length(5) });
export const constructionStepSchema = z.object({ title: short, instructions: text });
export const constructionGuideSchema = z.object({
  overview: text,
  originalObject: text,
  transformation: text,
  materials: list,
  tools: list,
  preparation: list,
  steps: z.array(constructionStepSchema).min(1).max(12),
  finishing: list,
  safety: list,
  cost: short,
  duration: short,
  alternatives: list,
  maintenance: list
});

export const assistantResponseSchema = z.object({
  reply: z.string().trim().min(1).max(3000)
});

export const generatedImageSchema = z.object({
  dataUrl: z.string().max(14000000).regex(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/),
  style: short,
  kind: short,
  timestamp: isoTime
});

export const aiModeSchema = z.enum(['hybrid', 'private', 'cloud']);

export const inferenceEventSchema = z.object({
  id: z.string().min(1).max(64),
  timestamp: isoTime,
  task: z.enum(['analysis', 'concepts', 'guide', 'assistant', 'image']),
  mode: aiModeSchema,
  source: z.enum(['on-device', 'cloud', 'unknown']),
  latencyMs: z.number().int().nonnegative(),
  model: z.string().max(160).optional(),
  fallback: z.boolean(),
  status: z.enum(['success', 'failed']),
  errorCode: z.string().max(64).optional()
});

export const featureFlagsSchema = z.object({
  enableImageGeneration: z.boolean(),
  enableAdvancedCloudModels: z.boolean(),
  enableImageEditing: z.boolean(),
  enableCloudSync: z.boolean(),
  maxImageGenerationsPerDay: z.number().int().min(0).max(100),
  maxCloudRequestsPerDay: z.number().int().min(0).max(500),
  cloudTextModel: z.string().regex(/^gemini-[a-z0-9.-]+$/).max(100),
  cloudImageModel: z.string().regex(/^gemini-[a-z0-9.-]+$/).max(100)
});

export const userProfileSchema = z.object({
  uid: z.string().min(1),
  displayName: z.string().nullable(),
  email: z.string().nullable(),
  photoURL: z.string().nullable()
});
