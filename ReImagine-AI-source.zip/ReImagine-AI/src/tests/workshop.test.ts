import { describe, expect, it } from 'vitest'
import { calculateBudget, calculateImpact } from '../features/workshop/metrics'
import { budgetEstimateSchema, inventoryItemSchema, sustainabilityRecordSchema } from '../services/storage/records'
import type { Project, SustainabilityRecord } from '../services/storage/workshop'
import type { TransformationConcept } from '../types/ai'

const timestamp = '2026-11-15T10:30:00.000Z'
const concept: TransformationConcept = {
  title: 'Pine tray', description: 'Refinish the offcuts into a tray.', difficulty: 'Beginner',
  duration: '45 min', costMin: 0, costMax: 5, currency: 'AED', category: 'Organization and storage',
  materials: ['Pine'], tools: ['Sandpaper'], safety: [], benefits: ['Reuses pine'], limitations: []
}

const project: Project = {
  id: 'project', title: concept.title, concept, status: 'complete', private: true,
  completedAt: timestamp, createdAt: timestamp, updatedAt: timestamp, completedSteps: [], objectCount: 2
}

const impact: SustainabilityRecord = {
  id: 'wood', material: 'Wood', weightKg: 0.42, savings: 13, currency: 'AED',
  recordedAt: timestamp, updatedAt: timestamp
}

describe('Workshop totals', () => {
  it('rounds amounts and keeps savings unknown until a replacement cost is provided', () => {
    const draft = {
      maximum: 15,
      currency: 'AED',
      replacementCost: null,
      lines: [{ id: 'sandpaper', name: 'Sandpaper', category: 'Materials' as const, quantity: 3, price: 2.025 }]
    }
    expect(calculateBudget(draft)).toEqual({ total: 6.08, remaining: 8.92, savings: null })
    expect(calculateBudget({ ...draft, replacementCost: 5 }).savings).toBe(-1.08)
  })

  it('counts only real completed projects and aggregates estimates per currency', () => {
    const report = calculateImpact([
      project, { ...project, id: 'example', example: true }, { ...project, id: 'planned', status: 'planned' }
    ], [
      impact,
      { ...impact, id: 'glass', material: 'Glass', weightKg: 0.58, savings: 2, currency: 'USD' },
      { ...impact, id: 'estimate', savings: undefined, weightKg: 0.5 }
    ], new Date('2026-11-20T00:00:00Z'))
    expect(report).toMatchObject({
      completed: 1, objectsRepurposed: 2, kilograms: 1.5
    })
    expect(report.materials.map(([material]) => material)).toEqual(['Wood', 'Glass'])
    expect(report.materials[0][1]).toBeCloseTo(0.92)
    expect(report.materials[1][1]).toBeCloseTo(0.58)
    expect([...report.savings.entries()]).toEqual([['AED', 13], ['USD', 2]])
    expect(report.months.at(-1)).toMatchObject({ completed: 1, kilograms: 1.5 })
  })
})

describe('Workshop validation', () => {
  it('rejects negative weights, invalid photos and expenses with invalid quantities', () => {
    expect(sustainabilityRecordSchema.safeParse({ ...impact, weightKg: -0.5 }).success).toBe(false)
    expect(inventoryItemSchema.safeParse({
      id: 'test', name: 'Wood scraps', quantity: 2, material: 'Wood', condition: 'Good', updatedAt: timestamp,
      addedAt: timestamp, photo: 'data:text/html;base64,PHNjcmlwdD4='
    }).success).toBe(false)
    expect(budgetEstimateSchema.safeParse({
      maximum: 10, currency: 'AED', replacementCost: null,
      lines: [{ id: 'sandpaper', name: 'Sandpaper', category: 'Materials', quantity: -2, price: 4 }]
    }).success).toBe(false)
  })
})
