import { beforeEach, describe, expect, it, vi } from 'vitest';
import { InferenceMode, InferenceSource } from 'firebase/ai';
import { objectAnalysisSchema } from '../schemas/ai';
import type { AIOptions, TransformationConcept } from '../types/ai';
import { defaultFlags } from '../services/firebase/flags';
import {
  analyzeObject, askAssistant, generateGuide, generateImage, getInferenceEvents, getLocalAvailability,
  getQuotaUsage, parseStructured, selectInferenceMode
} from '../services/ai';

const sdk = vi.hoisted(() => ({
  connected: true,
  generateContent: vi.fn(),
  getGenerativeModel: vi.fn(),
  initializeDeviceModel: vi.fn()
}));

vi.mock('firebase/ai', async (original) => ({
  ...await original<typeof import('firebase/ai')>(),
  getAI: vi.fn(),
  getGenerativeModel: sdk.getGenerativeModel
}));

vi.mock('../services/firebase/client', () => ({
  get firebaseCloudReady() {
    return sdk.connected;
  },
  getFirebaseApp: () => sdk.connected ? {} : undefined
}));

const object = {
  name: 'Glass jar',
  category: 'Container',
  materials: ['Glass'],
  condition: 'Intact, clear body',
  components: ['Jar', 'Lid'],
  damage: [],
  potential: 'Dry storage',
  safety: ['Inspect the rim for chips'],
  confidence: 'high',
  uncertainty: 'The lid material is unclear',
  hazardous: false
};
const idea: TransformationConcept = {
  title: 'Dry goods jar',
  description: 'Reuse the intact jar and lid for dry goods.',
  difficulty: 'Beginner',
  duration: '15 minutes',
  costMin: 0,
  costMax: 0,
  currency: 'AED',
  category: 'Organization and storage',
  materials: ['Glass jar'], tools: [], benefits: ['Reuse a container'], limitations: [], safety: ['Inspect the rim']
};
const photo = new Blob([new Uint8Array([255, 216, 255, 224])], { type: 'image/jpeg' });
const imageInput = { concept: idea, style: 'Minimalist' };
const hybrid: AIOptions = { mode: 'hybrid', allowCloud: true };
const doCloud: AIOptions = {
  mode: 'cloud', allowCloud: true, flags: { ...defaultFlags, enableImageGeneration: true }
};

beforeEach(() => {
  vi.clearAllMocks();
  const data = new Map<string, string>();
  vi.stubGlobal('localStorage', {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => data.set(key, value)
  });
  vi.stubGlobal('navigator', { onLine: true });
  vi.stubGlobal('window', { LanguageModel: { availability: async () => 'available' } });
  sdk.connected = true;
  sdk.initializeDeviceModel.mockResolvedValue(undefined);
  sdk.getGenerativeModel.mockReturnValue({
    initializeDeviceModel: sdk.initializeDeviceModel,
    generateContent: sdk.generateContent
  });
});

describe('structured inference', () => {
  it('validates object analysis and handles a Markdown JSON fence', () => {
    expect(parseStructured('```json\n' + JSON.stringify(object) + '\n```', objectAnalysisSchema)).toEqual(object);
    expect(() => parseStructured('{"name":"Jar"}', objectAnalysisSchema)).toThrow(/unexpected format/);
    expect(() => parseStructured('{', objectAnalysisSchema)).toThrow(/incomplete/);
  });

  it('validates images without calling AI', async () => {
    await expect(analyzeObject(new Blob(['hello'], { type: 'image/gif' }), '', hybrid)).rejects.toMatchObject({ code: 'invalid-image' });
    await expect(analyzeObject(new Blob(['hello'], { type: 'image/jpeg' }), '', hybrid)).rejects.toMatchObject({ code: 'invalid-image' });
    expect(sdk.generateContent).not.toHaveBeenCalled();
    expect(getInferenceEvents()).toHaveLength(0);
  });

  it('uses the device-only SDK mode and reads the SDK source', async () => {
    sdk.generateContent.mockResolvedValue({
      response: { text: () => JSON.stringify(object), inferenceSource: InferenceSource.ON_DEVICE }
    });
    const result = await analyzeObject(photo, 'Visible lid', { mode: 'private', allowCloud: true });
    expect(sdk.getGenerativeModel.mock.calls[0][1].mode).toBe(InferenceMode.ONLY_ON_DEVICE);
    expect(sdk.initializeDeviceModel).toHaveBeenCalledOnce();
    expect(result.event).toMatchObject({ source: 'on-device', fallback: false, status: 'success' });
    expect(getQuotaUsage().cloudRequests).toBe(0);
    expect(JSON.stringify(getInferenceEvents())).not.toContain('Visible lid');
  });

  it('does not display a result with an unverified source in private mode', async () => {
    sdk.generateContent.mockResolvedValue({ response: { text: () => JSON.stringify(object) } });
    await expect(analyzeObject(photo, '', { mode: 'private', allowCloud: false })).rejects.toMatchObject({ code: 'unverified-source' });
    expect(getInferenceEvents()[0]).toMatchObject({ source: 'unknown', status: 'failed' });
  });

  it('permits SDK fallback with explicit consent and records a cloud response', async () => {
    sdk.generateContent.mockResolvedValue({
      response: { text: () => JSON.stringify(object), inferenceSource: InferenceSource.IN_CLOUD }
    });
    const result = await analyzeObject(photo, '', hybrid);
    expect(sdk.getGenerativeModel.mock.calls[0][1].mode).toBe(InferenceMode.PREFER_ON_DEVICE);
    expect(result.event).toMatchObject({ source: 'cloud', fallback: true, status: 'success' });
    expect(getQuotaUsage().cloudRequests).toBe(1);
  });

  it('blocks the SDK cloud path when the device adapter would be missing', async () => {
    vi.stubGlobal('window', {});
    expect(await getLocalAvailability()).toBe('unavailable');
    await expect(analyzeObject(photo, '', { mode: 'private', allowCloud: true })).rejects.toMatchObject({ code: 'local-unavailable' });
    await expect(analyzeObject(photo, '', { mode: 'hybrid', allowCloud: false })).rejects.toMatchObject({ code: 'local-unavailable' });
    vi.stubGlobal('navigator', { onLine: false });
    await expect(analyzeObject(photo, '', hybrid)).rejects.toMatchObject({ code: 'offline-local-unavailable' });
    expect(sdk.getGenerativeModel).not.toHaveBeenCalled();
    expect(sdk.generateContent).not.toHaveBeenCalled();
  });

  it('runs a confirmed downloaded model while offline', async () => {
    vi.stubGlobal('navigator', { onLine: false });
    sdk.generateContent.mockResolvedValue({
      response: { text: () => JSON.stringify(object), inferenceSource: InferenceSource.ON_DEVICE }
    });
    await expect(analyzeObject(photo, '', hybrid)).resolves.toMatchObject({ event: { source: 'on-device' } });
    expect(sdk.getGenerativeModel.mock.calls[0][1].mode).toBe(InferenceMode.ONLY_ON_DEVICE);
  });

  it('keeps private and unconsented hybrid prompts off the cloud path', () => {
    expect(selectInferenceMode({ mode: 'private', allowCloud: true }, true, true, true)).toBe(InferenceMode.ONLY_ON_DEVICE);
    expect(selectInferenceMode({ mode: 'hybrid', allowCloud: false }, true, true, true)).toBe(InferenceMode.ONLY_ON_DEVICE);
    expect(selectInferenceMode(hybrid, true, true, false)).toBe(InferenceMode.ONLY_ON_DEVICE);
    expect(() => selectInferenceMode({ mode: 'cloud', allowCloud: false }, true, true, true)).toThrow(/Enable cloud processing/);
  });

  it('blocks potentially unsafe guide requests before inference', async () => {
    await expect(generateGuide(idea, 'A damaged lithium battery', hybrid)).rejects.toMatchObject({ code: 'hazardous-object' });
    await expect(askAssistant('How do I dismantle the pressure vessel?', '', hybrid)).rejects.toMatchObject({ code: 'hazardous-object' });
    expect(sdk.generateContent).not.toHaveBeenCalled();
  });
});

describe('optional cloud images', () => {
  it('requires consent, feature access, and billing confirmation before inference', async () => {
    await expect(generateImage(imageInput, { mode: 'private', allowCloud: true }, true)).rejects.toMatchObject({ code: 'consent-required' });
    await expect(generateImage(imageInput, { mode: 'cloud', allowCloud: true }, true)).rejects.toMatchObject({ code: 'image-disabled' });
    await expect(generateImage(imageInput, doCloud, false)).rejects.toMatchObject({ code: 'billing-confirmation' });
    await expect(generateImage({ ...imageInput, reference: photo }, doCloud, true)).rejects.toMatchObject({ code: 'editing-disabled' });
    sdk.connected = false;
    await expect(generateImage(imageInput, doCloud, true)).rejects.toMatchObject({ code: 'not-configured' });
    expect(sdk.generateContent).not.toHaveBeenCalled();
    expect(getInferenceEvents()).toHaveLength(0);
  });

  it('stops at the configured device daily limit', async () => {
    await expect(generateImage(imageInput, {
      ...doCloud,
      flags: { ...doCloud.flags!, maxImageGenerationsPerDay: 0 }
    }, true)).rejects.toMatchObject({ code: 'quota' });
    expect(sdk.generateContent).not.toHaveBeenCalled();
  });

  it('handles quota rejects and records the failed attempt without content', async () => {
    sdk.generateContent.mockRejectedValue(new Error('HTTP 429 resource exhausted'));
    await expect(generateImage(imageInput, doCloud, true)).rejects.toMatchObject({ code: 'quota' });
    expect(getQuotaUsage()).toEqual({ cloudRequests: 1, imageGenerations: 1 });
    expect(getInferenceEvents()[0]).toMatchObject({ status: 'failed', source: 'unknown', errorCode: 'quota' });
    expect(JSON.stringify(getInferenceEvents())).not.toContain(idea.title);
  });

  it('reports an empty image response without substituting an example', async () => {
    sdk.generateContent.mockResolvedValue({
      response: { inlineDataParts: () => [], inferenceSource: InferenceSource.IN_CLOUD }
    });
    await expect(generateImage(imageInput, doCloud, true)).rejects.toMatchObject({ code: 'no-image' });
    expect(getInferenceEvents()[0]).toMatchObject({ status: 'failed', source: 'cloud', errorCode: 'no-image' });
  });
});
