import type { z } from 'zod';
import type {
  aiModeSchema,
  constructionGuideSchema,
  constructionStepSchema,
  featureFlagsSchema,
  generatedImageSchema,
  inferenceEventSchema,
  objectAnalysisSchema,
  transformationConceptSchema,
  userProfileSchema
} from '../schemas/ai';

export type InferenceMode = z.infer<typeof aiModeSchema>;
export type InferenceEvent = z.infer<typeof inferenceEventSchema>;
export type InferenceTask = InferenceEvent['task'];
export type ObjectAnalysis = z.infer<typeof objectAnalysisSchema>;
export type TransformationConcept = z.infer<typeof transformationConceptSchema>;
export type ConstructionStep = z.infer<typeof constructionStepSchema>;
export type ConstructionGuide = z.infer<typeof constructionGuideSchema>;
export type GeneratedImage = z.infer<typeof generatedImageSchema>;
export type FeatureFlags = z.infer<typeof featureFlagsSchema>;
export type UserProfile = z.infer<typeof userProfileSchema>;

export interface AIOptions {
  mode: InferenceMode;
  allowCloud: boolean;
  flags?: FeatureFlags;
  onDownloadProgress?: (progress: number) => void;
}

export interface AIResult<T> {
  data: T;
  event: InferenceEvent;
}

export interface IdeaBudget {
  maximum: number;
  currency: string;
}

export type LocalAvailability = 'available' | 'downloadable' | 'downloading' | 'unavailable' | 'unknown';
