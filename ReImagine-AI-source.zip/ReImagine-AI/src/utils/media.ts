export function asDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result))
    reader.onerror = () => reject(new Error('The image could not be read.'))
    reader.readAsDataURL(blob)
  })
}

export async function validatePhoto(file: File) {
  if (!['image/jpeg', 'image/png'].includes(file.type)) throw new Error('Choose a JPEG or PNG image.')
  if (file.size > 20 * 1024 * 1024) throw new Error('Choose an image smaller than 20 MB.')
  try {
    const bitmap = await createImageBitmap(file)
    bitmap.close()
  } catch {
    throw new Error('This image could not be opened. Try a different JPEG or PNG.')
  }
}

export async function editPhoto(file: Blob, rotation: number, crop: number, x = 50, y = 50): Promise<Blob> {
  const image = await createImageBitmap(file)
  try {
    const ratio = Math.min(1, 1600 / Math.max(image.width, image.height))
    const width = Math.max(1, Math.round(image.width * ratio))
    const height = Math.max(1, Math.round(image.height * ratio))
    const turned = rotation % 180 !== 0
    const source = document.createElement('canvas')
    source.width = turned ? height : width
    source.height = turned ? width : height
    const context = source.getContext('2d')!
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, source.width, source.height)
    context.translate(source.width / 2, source.height / 2)
    context.rotate(rotation * Math.PI / 180)
    context.drawImage(image, -width / 2, -height / 2, width, height)
    const result = document.createElement('canvas')
    result.width = Math.max(1, Math.round(source.width * (1 - crop / 100)))
    result.height = Math.max(1, Math.round(source.height * (1 - crop / 100)))
    result.getContext('2d')!.drawImage(source, (source.width - result.width) * x / 100, (source.height - result.height) * y / 100,
      result.width, result.height, 0, 0, result.width, result.height)
    return await new Promise((resolve, reject) => result.toBlob(blob => blob ? resolve(blob) : reject(new Error('Photo could not be prepared.')), 'image/jpeg', 0.9))
  } finally {
    image.close()
  }
}
