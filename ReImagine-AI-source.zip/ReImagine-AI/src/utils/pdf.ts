import type { Project } from '../services/storage/workshop'
import { editPhoto, asDataUrl } from './media'

export async function downloadGuide(project: Project, includePhoto: boolean, includeConcept: boolean) {
  const guide = project.guide
  if (!guide) throw new Error('Generate a construction guide first.')
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF()
  let y = 25
  const left = 21
  const gap = 6
  const clean = (value: string) => value.replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, '-')
  const newPage = () => { doc.addPage(); y = 24 }
  function write(value: string, size = 11, color = '#28342c', bold = false) {
    doc.setFont('helvetica', bold ? 'bold' : 'normal')
    doc.setFontSize(size)
    doc.setTextColor(color)
    for (const line of doc.splitTextToSize(clean(value), 168) as string[]) {
      if (y > 269) newPage()
      doc.text(line, left, y)
      y += Math.max(gap, size * 0.42)
    }
  }
  function section(title: string, lines: string[]) {
    if (!lines.length) return
    if (y > 251) newPage()
    y += 4
    write(title.toUpperCase(), 10, '#325d46', true)
    lines.forEach(line => write(line))
  }
  write('REIMAGINE AI  /  FIELD GUIDE', 10, '#325d46', true)
  y += 5
  write(project.title, 25, '#143b2c', true)
  write(project.example ? 'Preloaded example project' : 'AI-assisted project guide')
  write(guide.overview)
  for (const { url, label } of [
    { url: includePhoto ? project.originalImage : undefined, label: project.example ? 'Original object — example illustration' : 'Original object photograph' },
    { url: includeConcept ? project.image?.dataUrl : undefined, label: 'AI-generated concept illustration' },
  ]) {
    if (!url) continue
    const response = await fetch(url)
    if (!response.ok) throw new Error('An image selected for this guide could not be opened.')
    const image = await asDataUrl(await editPhoto(await response.blob(), 0, 0))
    const dimensions = doc.getImageProperties(image)
    const width = Math.min(114, 70 * dimensions.width / dimensions.height)
    const height = width * dimensions.height / dimensions.width
    if (y + height + 15 > 269) newPage()
    doc.addImage(image, 'JPEG', left, y, width, height)
    y += height + 6
    write(label, 9, '#43564a')
  }
  section('Original object', [guide.originalObject])
  section('Transformation', [guide.transformation])
  section('Cost and time estimates', [guide.cost, guide.duration, 'Verify measurements and prices before you start.'])
  section('Safety', guide.safety)
  section('Materials checklist', guide.materials.map(item => '[ ] ' + item))
  section('Tools checklist', guide.tools.map(item => '[ ] ' + item))
  section('Preparation', guide.preparation)
  section('Construction', guide.steps.map((step, i) => (i + 1) + '. ' + step.title + ' — ' + step.instructions))
  section('Finishing', guide.finishing)
  section('Alternative materials', guide.alternatives)
  section('Maintenance', guide.maintenance)
  const pageCount = doc.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setDrawColor('#d9e3d8')
    doc.line(left, 279, 189, 279)
    doc.setFontSize(9)
    doc.setTextColor('#43564a')
    doc.text('REIMAGINE AI', left, 285)
    doc.text(i + ' / ' + pageCount, 189, 285, { align: 'right' })
  }
  doc.save(project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-guide.pdf')
}
