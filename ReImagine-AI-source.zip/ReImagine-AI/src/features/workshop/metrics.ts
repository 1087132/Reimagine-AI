import type { BudgetEstimate, Project, SustainabilityRecord } from '../../services/storage/workshop'

export function formatMoney(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency, currencyDisplay: 'code', maximumFractionDigits: 2 }).format(amount)
  } catch {
    return amount.toFixed(2) + ' ' + currency
  }
}

function roundMoney(value: number) {
  const adjusted = value + Number.EPSILON * Math.max(1, Math.abs(value))
  return Math.round(adjusted * 100) / 100
}

export function calculateBudget(budget: BudgetEstimate) {
  const total = roundMoney(budget.lines.reduce((sum, line) => sum + line.quantity * line.price, 0))
  return {
    total,
    remaining: roundMoney(budget.maximum - total),
    savings: budget.replacementCost === null ? null : roundMoney(budget.replacementCost - total)
  }
}

const monthKey = (date: Date) => String(date.getFullYear()) + '-' + String(date.getMonth() + 1).padStart(2, '0')

export function calculateImpact(projects: Project[], impact: SustainabilityRecord[], now = new Date()) {
  const complete = projects.filter(project => project.status === 'complete' && !project.example)
  const kilograms = impact.reduce((sum, record) => sum + record.weightKg, 0)
  const savings = new Map<string, number>()
  const materials = new Map<string, number>()
  for (const record of impact) {
    materials.set(record.material, (materials.get(record.material) ?? 0) + record.weightKg)
    if (record.savings !== undefined) savings.set(record.currency, (savings.get(record.currency) ?? 0) + record.savings)
  }
  const months = Array.from({ length: 6 }, (_, index) => {
    const date = new Date(now.getFullYear(), now.getMonth() + index - 5, 1)
    const key = monthKey(date)
    return {
      key,
      label: date.toLocaleDateString(undefined, { month: 'short' }),
      completed: complete.filter(project => monthKey(new Date(project.completedAt ?? project.updatedAt)) === key).length,
      kilograms: impact
        .filter(record => monthKey(new Date(record.recordedAt)) === key)
        .reduce((sum, record) => sum + record.weightKg, 0)
    }
  })
  return {
    completed: complete.length,
    objectsRepurposed: complete.reduce((sum, project) => sum + (project.objectCount ?? 1), 0),
    kilograms,
    savings,
    materials: [...materials.entries()].sort((a, b) => b[1] - a[1]),
    months
  }
}
