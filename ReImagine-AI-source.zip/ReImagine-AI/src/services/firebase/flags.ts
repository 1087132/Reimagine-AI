import { fetchAndActivate, getBoolean, getNumber, getRemoteConfig, getString, isSupported } from 'firebase/remote-config';
import { featureFlagsSchema } from '../../schemas/ai';
import type { FeatureFlags } from '../../types/ai';
import { firebaseCloudReady, getFirebaseApp } from './client';

export const defaultFlags: FeatureFlags = Object.freeze({
  enableImageGeneration: false,
  enableAdvancedCloudModels: false,
  enableImageEditing: false,
  enableCloudSync: false,
  maxImageGenerationsPerDay: 2,
  maxCloudRequestsPerDay: 15,
  cloudTextModel: 'gemini-3.5-flash-lite',
  cloudImageModel: 'gemini-nano-banana-2.1'
});

export async function loadFeatureFlags(): Promise<FeatureFlags> {
  if (!firebaseCloudReady || typeof navigator === 'undefined' || !navigator.onLine) return defaultFlags;
  try {
    const app = getFirebaseApp();
    if (!app || !(await isSupported())) return defaultFlags;
    const remote = getRemoteConfig(app);
    remote.settings.minimumFetchIntervalMillis = import.meta.env.DEV ? 60000 : 3600000;
    remote.settings.fetchTimeoutMillis = 5000;
    remote.defaultConfig = { ...defaultFlags };
    await fetchAndActivate(remote);
    const parsed = featureFlagsSchema.safeParse({
      enableImageGeneration: getBoolean(remote, 'enableImageGeneration'),
      enableAdvancedCloudModels: getBoolean(remote, 'enableAdvancedCloudModels'),
      enableImageEditing: getBoolean(remote, 'enableImageEditing'),
      enableCloudSync: getBoolean(remote, 'enableCloudSync'),
      maxImageGenerationsPerDay: getNumber(remote, 'maxImageGenerationsPerDay'),
      maxCloudRequestsPerDay: getNumber(remote, 'maxCloudRequestsPerDay'),
      cloudTextModel: getString(remote, 'cloudTextModel'),
      cloudImageModel: getString(remote, 'cloudImageModel')
    });
    return parsed.success ? parsed.data : defaultFlags;
  } catch {
    return defaultFlags;
  }
}
