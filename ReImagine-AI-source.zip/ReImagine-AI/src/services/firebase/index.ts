export { firebaseAuthReady, firebaseCloudReady, firebaseConfigured } from './client';
export { defaultFlags, loadFeatureFlags } from './flags';
export { deleteAccount, firebaseAuthMessage, logInEmail, logInGoogle, logout, observeAuth, registerEmail } from './auth';
export { clearCloudData, syncCloudRecords, type CloudCollection } from './sync';
