import {
  EmailAuthProvider, GoogleAuthProvider, createUserWithEmailAndPassword, deleteUser, onAuthStateChanged,
  reauthenticateWithCredential, reauthenticateWithPopup, signInWithEmailAndPassword, signInWithPopup, signOut,
  type User
} from 'firebase/auth';
import { userProfileSchema } from '../../schemas/ai';
import type { UserProfile } from '../../types/ai';
import { getFirebaseAuth } from './client';
import { clearCloudData } from './sync';

function requireAuth() {
  const auth = getFirebaseAuth();
  if (!auth) throw new Error('Account sign-in needs a Firebase project and App Check setup.');
  return auth;
}

function profile(user: User): UserProfile {
  const { uid, displayName, email, photoURL } = user;
  return userProfileSchema.parse({ uid, displayName, email, photoURL });
}

export function observeAuth(listener: (user: UserProfile | null) => void) {
  const auth = getFirebaseAuth();
  if (!auth) {
    listener(null);
    return () => {};
  }
  return onAuthStateChanged(auth, (user) => listener(user ? profile(user) : null));
}

export async function logInEmail(email: string, password: string) {
  const { user } = await signInWithEmailAndPassword(requireAuth(), email.trim(), password);
  return profile(user);
}

export async function registerEmail(email: string, password: string) {
  const { user } = await createUserWithEmailAndPassword(requireAuth(), email.trim(), password);
  return profile(user);
}

export async function logInGoogle() {
  const { user } = await signInWithPopup(requireAuth(), new GoogleAuthProvider());
  return profile(user);
}

export async function logout() {
  await signOut(requireAuth());
}

export async function deleteAccount(password?: string) {
  const auth = requireAuth();
  const user = auth.currentUser;
  if (!user) throw new Error('Sign in before deleting your account.');
  const passwordProvider = user.providerData.some((provider) => provider.providerId === EmailAuthProvider.PROVIDER_ID);
  const googleProvider = user.providerData.some((provider) => provider.providerId === GoogleAuthProvider.PROVIDER_ID);
  if (password && user.email && passwordProvider) {
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password));
  } else if (googleProvider) {
    await reauthenticateWithPopup(user, new GoogleAuthProvider());
  } else {
    throw new Error('Enter your account password to verify account deletion.');
  }
  await clearCloudData(user.uid);
  await deleteUser(user);
}

export function firebaseAuthMessage(error: unknown) {
  const code = typeof error === 'object' && error && 'code' in error ? error.code : '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return 'The email or password did not match.';
    case 'auth/email-already-in-use':
      return 'An account already uses this email. Sign in or use another address.';
    case 'auth/invalid-email':
      return 'Enter a valid email address.';
    case 'auth/weak-password':
      return 'Choose a stronger password with at least six characters.';
    case 'auth/popup-closed-by-user':
      return 'Google sign-in was closed. Open it again to finish.';
    case 'auth/popup-blocked':
      return 'Your browser blocked the Google sign-in window. Allow popups for this site and try again.';
    case 'auth/network-request-failed':
      return 'Could not reach Firebase. Check your connection and try again.';
    case 'auth/operation-not-allowed':
    case 'auth/unauthorized-domain':
    case 'auth/app-not-authorized':
      return 'This sign-in provider or domain needs to be enabled in Firebase Authentication.';
    case 'auth/requires-recent-login':
      return 'Sign in again, then retry deleting your account.';
    case 'permission-denied':
      return 'Firebase denied cloud data access. Verify the deployed rules and App Check registration.';
    default:
      return error instanceof Error && !code ? error.message : 'The account operation could not complete. Try again.';
  }
}
