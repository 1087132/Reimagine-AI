import {
  collection, doc, getDocsFromServer, runTransaction, writeBatch,
  type DocumentData
} from 'firebase/firestore';
import { deleteObject, getBlob, list, ref, uploadBytes, type StorageReference } from 'firebase/storage';
import { z } from 'zod';
import { getFirebaseAuth, getFirebaseFirestore, getFirebaseStorage } from './client';

export type CloudCollection = 'projects' | 'inventory' | 'impact';

interface CloudRecord {
  id: string;
  updatedAt?: string;
  private?: boolean;
  deleted?: boolean;
}

interface SynchronizationConsent {
  allowMedia?: boolean;
  isAllowed?: () => boolean;
}

const deletionInProgress = new Set<string>();
const activeSync = new Map<string, Set<Promise<unknown>>>();
const collections = ['projects', 'inventory', 'impact', 'inferenceStats', 'settings'] as const;
const mediaGroups: readonly CloudCollection[] = ['projects', 'inventory'];
type MediaField = 'original' | 'concept' | 'photo';
const recordKey = z.object({ id: z.string().regex(/^[A-Za-z0-9_-]{1,128}$/), updatedAt: z.iso.datetime() });
const inlineImage = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/;

function ownDatabase(uid: string) {
  const auth = getFirebaseAuth();
  const db = getFirebaseFirestore();
  if (!db || !auth || auth.currentUser?.uid !== uid) {
    throw new Error('Sign in to this account before using cloud data.');
  }
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('Connect to the internet to use cloud data.');
  }
  return db;
}

function assertSyncConsent(uid: string, options: SynchronizationConsent) {
  if (deletionInProgress.has(uid)) throw new Error('Cloud data is being deleted. Sync will be available afterward.');
  if (getFirebaseAuth()?.currentUser?.uid !== uid || options.isAllowed?.() === false) {
    throw new Error('Cloud sync permission changed. Sync stopped.');
  }
}

function mediaFile(uid: string, group: CloudCollection, id: string, field: MediaField, timestamp: string) {
  const storage = getFirebaseStorage();
  if (!storage || !mediaGroups.includes(group)) return undefined;
  const suffix = timestamp.replace(/[^0-9]/g, '');
  return ref(storage, `users/${uid}/${group}/${id}/${field}-${suffix}`);
}

async function putMedia(target: StorageReference | undefined, data: unknown) {
  if (!target || typeof data !== 'string' || data.length > 11200000) return false;
  const parts = inlineImage.exec(data);
  if (!parts) return false;
  const bytes = Uint8Array.from(atob(parts[2]), (character) => character.charCodeAt(0));
  if (!bytes.length || bytes.length > 8 * 1024 * 1024) return false;
  await uploadBytes(target, bytes, { contentType: parts[1], cacheControl: 'private, no-store' });
  return true;
}

async function getMedia(source: StorageReference | undefined) {
  if (!source) return undefined;
  try {
    const blob = await getBlob(source, 8 * 1024 * 1024);
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(blob.type)) return undefined;
    return await new Promise<string | undefined>((resolve) => {
      const reader = new FileReader();
      reader.onerror = () => resolve(undefined);
      reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : undefined);
      reader.readAsDataURL(blob);
    });
  } catch {
    return undefined;
  }
}

function withoutUndefined(data: DocumentData): DocumentData {
  return JSON.parse(JSON.stringify(data));
}

function metadata(record: CloudRecord) {
  const clean = { ...record } as DocumentData;
  delete clean.originalImage;
  delete clean.photo;
  delete clean._media;
  if (clean.image && typeof clean.image === 'object') {
    const { dataUrl: _data, ...imageMetadata } = clean.image;
    clean.image = imageMetadata;
  }
  return withoutUndefined(clean);
}

function recordMedia(group: CloudCollection, record: CloudRecord) {
  const data = record as DocumentData;
  const source: Partial<Record<MediaField, string>> = group === 'projects'
    ? { original: data.originalImage, concept: data.image?.dataUrl }
    : group === 'inventory' ? { photo: data.photo } : {};
  return Object.entries(source).flatMap(([field, data]) => typeof data === 'string' && data.length <= 11200000 && inlineImage.test(data)
    ? [[field as MediaField, data] as const] : []);
}

async function prepareMedia(
  uid: string, group: CloudCollection, record: CloudRecord, items: ReturnType<typeof recordMedia>, options: SynchronizationConsent
) {
  const result: Partial<Record<MediaField, true>> = {};
  for (const [field, data] of items) {
    assertSyncConsent(uid, options);
    if (await putMedia(mediaFile(uid, group, record.id, field, record.updatedAt!), data)) result[field] = true;
  }
  return result;
}

async function readRemote<T extends CloudRecord>(
  uid: string, group: CloudCollection, data: DocumentData, options: SynchronizationConsent, local?: T
): Promise<T | undefined> {
  const identity = recordKey.safeParse(data);
  if (!identity.success || data.private === true) return;
  const { id, updatedAt } = identity.data;
  if (data.deleted === true) return { id, updatedAt, deleted: true } as T;
  const rest = metadata(data as CloudRecord);
  const sourceImage = rest.image;
  delete rest.image;
  if (options.allowMedia && data._media) {
    const cached = local && local.updatedAt === updatedAt ? new Map(recordMedia(group, local)) : undefined;
    const read = (field: MediaField) => {
      assertSyncConsent(uid, options);
      return cached?.get(field) ?? getMedia(mediaFile(uid, group, id, field, updatedAt));
    };
    if (data._media.original === true) rest.originalImage = await read('original');
    if (data._media.photo === true) rest.photo = await read('photo');
    if (data._media.concept === true && sourceImage && typeof sourceImage === 'object') {
      const asset = await read('concept');
      if (asset) rest.image = { ...sourceImage, dataUrl: asset };
    }
  }
  return rest as T;
}

async function deleteMedia(prefix: StorageReference, atOrBefore?: string): Promise<void> {
  let pageToken: string | undefined;
  do {
    const page = await list(prefix, { maxResults: 100, pageToken });
    await Promise.all(page.items.map(async (item) => {
      const revision = /-(\d+)$/.exec(item.name)?.[1];
      if (atOrBefore && (!revision || revision > atOrBefore)) return;
      try {
        await deleteObject(item);
      } catch (error) {
        if (!(typeof error === 'object' && error && 'code' in error && error.code === 'storage/object-not-found')) throw error;
      }
    }));
    await Promise.all(page.prefixes.map((child) => deleteMedia(child, atOrBefore)));
    pageToken = page.nextPageToken;
  } while (pageToken);
}

export function syncCloudRecords<T extends CloudRecord>(
  uid: string, group: CloudCollection, localRecords: readonly T[], options: SynchronizationConsent = {}
): Promise<T[]> {
  const pending = synchronize(uid, group, localRecords, options);
  const groupSyncs = activeSync.get(uid) ?? new Set<Promise<unknown>>();
  groupSyncs.add(pending);
  activeSync.set(uid, groupSyncs);
  function finished() {
    groupSyncs.delete(pending);
    if (!groupSyncs.size) activeSync.delete(uid);
  }
  void pending.then(finished, finished);
  return pending;
}

async function synchronize<T extends CloudRecord>(
  uid: string, group: CloudCollection, localRecords: readonly T[], options: SynchronizationConsent
): Promise<T[]> {
  const db = ownDatabase(uid);
  const destination = collection(db, 'users', uid, group);
  const local = localRecords.filter((record) => !record.private && recordKey.safeParse(record).success);
  const localById = new Map(local.map((record) => [record.id, record]));
  assertSyncConsent(uid, options);
  const previous = await getDocsFromServer(destination);
  const previousById = new Map(previous.docs.map((record) => [record.id, record.data()]));
  let changed = false;
  const storage = getFirebaseStorage();
  for (const record of local) {
    assertSyncConsent(uid, options);
    const existing = previousById.get(record.id);
    const revision = record.updatedAt!;
    const sameRevision = existing?.updatedAt === revision;
    if (typeof existing?.updatedAt === 'string' && existing.updatedAt > revision) continue;
    const staged = options.allowMedia && storage && !record.deleted && !existing?.deleted
      ? recordMedia(group, record).filter(([field]) => !sameRevision || existing?._media?.[field] !== true)
      : [];
    const reference = doc(destination, record.id);
    const cleanupMedia = async () => {
      if (!storage || !mediaGroups.includes(group)) return;
      assertSyncConsent(uid, options);
      await deleteMedia(ref(storage, `users/${uid}/${group}/${record.id}`), revision.replace(/[^0-9]/g, ''));
      await runTransaction(db, async (transaction) => {
        const snapshot = await transaction.get(reference);
        assertSyncConsent(uid, options);
        if (snapshot.data()?.deleted === true && snapshot.data()?.updatedAt === revision) {
          transaction.update(reference, { mediaCleared: true });
        }
      });
    };
    if (sameRevision && !staged.length && (!record.deleted || existing?.deleted)) {
      if (record.deleted && existing?.mediaCleared !== true) await cleanupMedia();
      continue;
    }
    const assets = await prepareMedia(uid, group, record, staged, options);
    const committed = await runTransaction(db, async (transaction) => {
      const snapshot = await transaction.get(reference);
      assertSyncConsent(uid, options);
      const latest = snapshot.data();
      if (typeof latest?.updatedAt === 'string' && latest.updatedAt > revision) return false;
      if (latest?.updatedAt === revision && latest.deleted) return false;
      if (record.deleted) {
        transaction.set(reference, { id: record.id, updatedAt: revision, deleted: true });
        return true;
      }
      if (latest?.updatedAt === revision) {
        if (!Object.keys(assets).length) return false;
        transaction.update(reference, { _media: { ...latest._media, ...assets } });
        return true;
      }
      transaction.set(reference, { ...metadata(record), _media: assets });
      return true;
    });
    changed ||= committed;
    if (record.deleted && committed) await cleanupMedia();
  }
  assertSyncConsent(uid, options);
  const merged = changed ? await getDocsFromServer(destination) : previous;
  const data = await Promise.all(merged.docs.map((record) => readRemote<T>(uid, group, record.data(), options, localById.get(record.id))));
  assertSyncConsent(uid, options);
  return data.filter((record) => record !== undefined);
}

export async function clearCloudData(uid = getFirebaseAuth()?.currentUser?.uid): Promise<void> {
  if (!uid) throw new Error('Sign in before deleting cloud data.');
  const db = ownDatabase(uid);
  if (deletionInProgress.has(uid)) throw new Error('Cloud data deletion is already running.');
  deletionInProgress.add(uid);
  try {
    await Promise.allSettled(activeSync.get(uid) ?? []);
    const storage = getFirebaseStorage();
    if (storage) await deleteMedia(ref(storage, `users/${uid}`));
    for (const group of collections) {
      const records = await getDocsFromServer(collection(db, 'users', uid, group));
      for (let index = 0; index < records.docs.length; index += 400) {
        const batch = writeBatch(db);
        for (const record of records.docs.slice(index, index + 400)) batch.delete(record.ref);
        await batch.commit();
      }
    }
    await writeBatch(db).delete(doc(db, 'users', uid)).commit();
  } finally {
    deletionInProgress.delete(uid);
  }
}
