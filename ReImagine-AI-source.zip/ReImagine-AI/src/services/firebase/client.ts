import { getApps, initializeApp, type FirebaseOptions } from 'firebase/app';
import { initializeAppCheck, ReCaptchaEnterpriseProvider } from 'firebase/app-check';
import { connectAuthEmulator, getAuth } from 'firebase/auth';
import { connectFirestoreEmulator, getFirestore } from 'firebase/firestore';
import { connectStorageEmulator, getStorage } from 'firebase/storage';

const env = import.meta.env;
const emulatorMode = env.DEV && env.VITE_FIREBASE_USE_EMULATORS === 'true';
const config: FirebaseOptions = {
  apiKey: env.VITE_FIREBASE_API_KEY || (emulatorMode ? 'demo-reimagine-key' : undefined),
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || (emulatorMode ? 'demo-reimagine.firebaseapp.com' : undefined),
  projectId: env.VITE_FIREBASE_PROJECT_ID || (emulatorMode ? 'demo-reimagine' : undefined),
  appId: env.VITE_FIREBASE_APP_ID || (emulatorMode ? '1:123:web:demo' : undefined),
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || (emulatorMode ? 'demo-reimagine.appspot.com' : undefined),
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID
};
const siteKey: string | undefined = env.VITE_FIREBASE_APP_CHECK_SITE_KEY;
const debug = env.DEV && env.VITE_FIREBASE_APP_CHECK_DEBUG === 'true';

export const firebaseConfigured = Boolean(config.apiKey && config.authDomain && config.projectId && config.appId);
export const firebaseCloudReady = firebaseConfigured && Boolean(siteKey) && !emulatorMode;
const appName = 'reimagine';
let initialized = false;

export function getFirebaseApp() {
  if (!firebaseConfigured) return undefined;
  const app = getApps().find((existing) => existing.name === appName) ?? initializeApp(config, appName);
  if (!initialized && siteKey && !emulatorMode && typeof window !== 'undefined') {
    if (debug) {
      const appCheckGlobal = globalThis as typeof globalThis & { FIREBASE_APPCHECK_DEBUG_TOKEN?: boolean };
      appCheckGlobal.FIREBASE_APPCHECK_DEBUG_TOKEN = true;
    }
    initializeAppCheck(app, { provider: new ReCaptchaEnterpriseProvider(siteKey), isTokenAutoRefreshEnabled: false });
  }
  initialized = true;
  return app;
}

export function getFirebaseAuth() {
  const app = getFirebaseApp();
  if (!app || (!firebaseCloudReady && !emulatorMode)) return undefined;
  const auth = getAuth(app);
  if (emulatorMode && !auth.emulatorConfig) {
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  }
  return auth;
}

let connectedFirestore = false;
export function getFirebaseFirestore() {
  const app = getFirebaseApp();
  if (!app || (!firebaseCloudReady && !emulatorMode)) return undefined;
  const db = getFirestore(app);
  if (emulatorMode && !connectedFirestore) {
    connectFirestoreEmulator(db, '127.0.0.1', 8080);
    connectedFirestore = true;
  }
  return db;
}

let connectedStorage = false;
export function getFirebaseStorage() {
  if (env.VITE_FIREBASE_ENABLE_STORAGE !== 'true' || !config.storageBucket) return undefined;
  const app = getFirebaseApp();
  if (!app || (!firebaseCloudReady && !emulatorMode)) return undefined;
  const storage = getStorage(app);
  if (emulatorMode && !connectedStorage) {
    connectStorageEmulator(storage, '127.0.0.1', 9199);
    connectedStorage = true;
  }
  return storage;
}

export const firebaseAuthReady = firebaseCloudReady || emulatorMode;
