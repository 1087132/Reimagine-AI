import { z } from 'zod'
import {
  constructionGuideSchema, generatedImageSchema, inferenceEventSchema,
  objectAnalysisSchema, transformationConceptSchema
} from '../../schemas/ai'

const identifier = z.string().min(1).max(128)
const shortText = z.string().trim().min(1).max(260)
const timestamp = z.iso.datetime()
const currency = z.string().regex(/^[A-Z]{3}$/)
const dataImage = generatedImageSchema.shape.dataUrl
const record = z.object({ id: identifier, updatedAt: timestamp })
export const deletedRecordSchema = record.extend({ deleted: z.literal(true), private: z.boolean().optional() })

export const inventoryItemSchema = record.extend({
  name: shortText,
  quantity: z.number().int().min(1).max(10000),
  material: shortText,
  condition: shortText,
  dimensions: z.string().max(120).optional(),
  photo: dataImage.optional(),
  addedAt: timestamp,
  private: z.boolean().optional()
})

export const budgetLineSchema = z.object({
  id: identifier,
  name: shortText,
  category: z.enum(['Materials', 'Tools', 'Decor', 'Other']),
  quantity: z.number().min(0).max(10000),
  price: z.number().min(0).max(1000000)
})

export const budgetEstimateSchema = z.object({
  currency,
  maximum: z.number().min(0).max(1000000),
  replacementCost: z.number().min(0).max(1000000).nullable(),
  lines: z.array(budgetLineSchema).max(250)
})

export const projectSchema = record.extend({
  title: shortText,
  concept: transformationConceptSchema,
  analysis: objectAnalysisSchema.optional(),
  notes: z.string().max(4000).optional(),
  originalImage: dataImage.optional(),
  image: generatedImageSchema.optional(),
  guide: constructionGuideSchema.optional(),
  completedSteps: z.array(z.number().int().nonnegative()).max(12),
  status: z.enum(['planned', 'in-progress', 'complete']),
  createdAt: timestamp,
  private: z.boolean(),
  example: z.boolean().optional(),
  completedAt: timestamp.optional(),
  objectCount: z.number().int().positive().optional(),
  budget: budgetEstimateSchema.optional()
})

export const sustainabilityRecordSchema = record.extend({
  projectId: identifier.optional(),
  material: shortText,
  weightKg: z.number().positive().max(100000),
  savings: z.number().min(0).max(1000000).optional(),
  currency,
  recordedAt: timestamp,
  private: z.boolean().optional()
})

export const recordSchemas = {
  inventory: inventoryItemSchema,
  projects: projectSchema,
  impact: sustainabilityRecordSchema,
  inference: inferenceEventSchema.extend({ updatedAt: timestamp })
}
