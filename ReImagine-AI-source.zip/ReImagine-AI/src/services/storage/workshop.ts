import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ConstructionGuide, GeneratedImage, InferenceEvent, ObjectAnalysis, TransformationConcept } from '../../types/ai'
import { deletedRecordSchema, recordSchemas } from './records'

export interface InventoryItem {
  id: string
  name: string
  quantity: number
  material: string
  condition: string
  dimensions?: string
  photo?: string
  addedAt: string
  updatedAt: string
  private?: boolean
}

export type BudgetCategory = 'Materials' | 'Tools' | 'Decor' | 'Other'

export interface BudgetLine {
  id: string
  name: string
  category: BudgetCategory
  quantity: number
  price: number
}

export interface BudgetEstimate {
  currency: string
  maximum: number
  replacementCost: number | null
  lines: BudgetLine[]
}

export interface Project {
  id: string
  title: string
  concept: TransformationConcept
  analysis?: ObjectAnalysis
  notes?: string
  originalImage?: string
  image?: GeneratedImage
  guide?: ConstructionGuide
  completedSteps: number[]
  status: 'planned' | 'in-progress' | 'complete'
  createdAt: string
  updatedAt: string
  private: boolean
  example?: boolean
  completedAt?: string
  objectCount?: number
  budget?: BudgetEstimate
}

export interface SustainabilityRecord {
  id: string
  projectId?: string
  material: string
  weightKg: number
  savings?: number
  currency: string
  recordedAt: string
  updatedAt: string
  private?: boolean
}

export interface WorkshopData {
  inventory: InventoryItem[]
  projects: Project[]
  impact: SustainabilityRecord[]
  inference: InferenceEvent[]
}

export interface DeletedRecord {
  id: string
  deleted: true
  private?: boolean
  updatedAt?: string
}

type Collection = keyof WorkshopData
type ShareableCollection = Exclude<Collection, 'inference'>
type CollectionItem<T extends Collection> = WorkshopData[T][number]
type StoredRecord = (CollectionItem<Collection> | DeletedRecord) & { updatedAt: string }
export type Tombstones = Partial<Record<ShareableCollection, DeletedRecord[]>>

const collections = ['inventory', 'projects', 'impact', 'inference'] as const
const emptyData: WorkshopData = { inventory: [], projects: [], impact: [], inference: [] }
const emptyTombstones: Tombstones = {}

function result<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

function commit(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve()
    transaction.onabort = () => reject(transaction.error ?? new Error('Local storage transaction was cancelled.'))
    transaction.onerror = () => reject(transaction.error ?? new Error('Local storage transaction failed.'))
  })
}

function fillMissingMedia(receiver: StoredRecord, donor: StoredRecord): StoredRecord {
  if ('concept' in receiver && 'concept' in donor) {
    const originalImage = receiver.originalImage ?? donor.originalImage
    const image = receiver.image ?? donor.image
    if (receiver.originalImage !== originalImage || receiver.image !== image) {
      return { ...receiver, originalImage, image }
    }
  }
  if ('quantity' in receiver && 'quantity' in donor && !receiver.photo && donor.photo) {
    return { ...receiver, photo: donor.photo }
  }
  return receiver
}

export function createWorkshopStore(scope: string) {
  let opening: Promise<IDBDatabase> | undefined
  const name = 'reimagine-ai:' + scope

  function database() {
    if (!opening) {
      opening = new Promise((resolve, reject) => {
        const request = indexedDB.open(name, 1)
        request.onupgradeneeded = () => {
          for (const collection of collections) {
            request.result.createObjectStore(collection, { keyPath: 'id' })
          }
        }
        request.onerror = () => reject(request.error)
        request.onsuccess = () => {
          request.result.onversionchange = () => {
            request.result.close()
            opening = undefined
          }
          resolve(request.result)
        }
      })
      void opening.catch(() => { opening = undefined })
    }
    return opening
  }

  async function readSnapshot(): Promise<{ data: WorkshopData; tombstones: Tombstones }> {
    const db = await database()
    const transaction = db.transaction([...collections], 'readonly')
    const records = await Promise.all(
      collections.map(collection => result<StoredRecord[]>(transaction.objectStore(collection).getAll()))
    )
    const tombstones: Tombstones = {}
    const next = Object.fromEntries(records.map((group, index) => {
      const collection = collections[index]
      const data = []
      const deleted = []
      for (const record of group) {
        if (record && 'deleted' in record) {
          const entry = deletedRecordSchema.safeParse(record)
          if (entry.success && !entry.data.private) deleted.push(entry.data)
        } else {
          const entry = recordSchemas[collection].safeParse(record)
          if (entry.success) data.push(entry.data)
        }
      }
      if (collection !== 'inference') tombstones[collection] = deleted
      return [collection, data.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))]
    }))
    return { data: next as unknown as WorkshopData, tombstones }
  }

  async function read() {
    return (await readSnapshot()).data
  }

  async function write<T extends Collection>(collection: T, item: CollectionItem<T> | DeletedRecord) {
    const record = {
      ...item,
      updatedAt: ('updatedAt' in item ? item.updatedAt : 'timestamp' in item ? item.timestamp : undefined) ??
        new Date().toISOString()
    }
    const validated = ('deleted' in record ? deletedRecordSchema : recordSchemas[collection]).safeParse(record)
    if (!validated.success) throw new Error('This record contains invalid project or inventory data.')
    const db = await database()
    const transaction = db.transaction(collection, 'readwrite')
    const complete = commit(transaction)
    const store = transaction.objectStore(collection)
    const next = validated.data
    const request: IDBRequest<StoredRecord | undefined> = store.get(next.id)
    request.onsuccess = () => {
      const current = request.result
      if (current && (current.updatedAt > next.updatedAt ||
        (current.updatedAt === next.updatedAt && 'deleted' in current))) return
      if ('deleted' in next && current && (
        ('private' in current && current.private) || ('example' in current && current.example)
      )) next.private = true
      store.put(next)
    }
    await complete
  }

  async function merge(snapshot: Partial<WorkshopData>, tombstones: Tombstones = {}) {
    const db = await database()
    const transaction = db.transaction([...collections], 'readwrite')
    const completed = commit(transaction)
    for (const collection of collections) {
      if (collection === 'inference') continue
      const store = transaction.objectStore(collection)
      const incoming = new Map<string, StoredRecord>()
      for (const item of [...(snapshot[collection] ?? []), ...(tombstones[collection] ?? [])]) {
        const schema = 'deleted' in item ? deletedRecordSchema : recordSchemas[collection]
        const validated = schema.safeParse(item)
        if (!validated.success) continue
        const record = validated.data
        if ('private' in record && record.private) continue
        const current = incoming.get(record.id)
        if (!current || current.updatedAt <= record.updatedAt) incoming.set(record.id, record)
      }
      for (const item of incoming.values()) {
        const request: IDBRequest<StoredRecord | undefined> = store.get(item.id)
        request.onsuccess = () => {
          const current = request.result
          if (current && 'private' in current && current.private) return
          if (current && current.updatedAt > item.updatedAt) return
          if (current?.updatedAt === item.updatedAt) {
            if ('deleted' in current) return
            if (!('deleted' in item)) {
              const enriched = fillMissingMedia(current, item)
              if (enriched !== current) store.put(enriched)
              return
            }
          }
          store.put(current ? fillMissingMedia(item, current) : item)
        }
      }
    }
    await completed
  }

  async function clear() {
    const db = await database()
    const transaction = db.transaction([...collections], 'readwrite')
    for (const collection of collections) transaction.objectStore(collection).clear()
    await commit(transaction)
  }

  return { read, readSnapshot, write, merge, clear, name }
}

export function useWorkshopData(scope = 'guest') {
  const store = useMemo(() => createWorkshopStore(scope), [scope])
  const current = useRef(store)
  current.current = store
  const channel = useRef<BroadcastChannel | null>(null)
  const [state, setState] = useState<{ scope: string; data?: WorkshopData; tombstones?: Tombstones; error?: string }>({ scope })

  const refresh = useCallback(async () => {
    try {
      const snapshot = await store.readSnapshot()
      if (current.current === store) setState({ scope, ...snapshot })
    } catch (error) {
      if (current.current === store) {
        setState({ scope, error: error instanceof Error ? error.message : 'Unable to open local storage.' })
      }
    }
  }, [store, scope])

  useEffect(() => {
    void refresh()
    if (typeof BroadcastChannel === 'undefined') return
    const connection = new BroadcastChannel(store.name)
    connection.onmessage = () => void refresh()
    channel.current = connection
    return () => {
      connection.close()
      channel.current = null
    }
  }, [refresh, store])

  const changed = useCallback(async () => {
    if (current.current === store) channel.current?.postMessage('updated')
    await refresh()
  }, [refresh, store])

  const mutate = useCallback(async <T extends Collection>(collection: T, item: CollectionItem<T> | DeletedRecord) => {
    await store.write(collection, item)
    await changed()
  }, [store, changed])

  const actions = useMemo(() => ({
    updateInventory: (item: InventoryItem | DeletedRecord) => mutate('inventory', item),
    updateProject: (item: Project | DeletedRecord) => mutate('projects', item),
    updateImpact: (item: SustainabilityRecord | DeletedRecord) => mutate('impact', item),
    addInference: (event: InferenceEvent) => mutate('inference', event),
    mergeRemote: async (snapshot: Partial<WorkshopData>, tombstones?: Tombstones) => {
      await store.merge(snapshot, tombstones)
      await changed()
    },
    clearData: async () => {
      await store.clear()
      await changed()
    }
  }), [mutate, store, changed])

  return {
    data: state.scope === scope ? state.data ?? emptyData : emptyData,
    tombstones: state.scope === scope ? state.tombstones ?? emptyTombstones : emptyTombstones,
    ready: state.scope === scope && !!state.data,
    error: state.scope === scope ? state.error : undefined,
    ...actions
  }
}
