import {
  getAI, getGenerativeModel, GoogleAIBackend, InferenceMode, InferenceSource, ResponseModality, Schema,
  type EnhancedGenerateContentResponse, type GenerativeModel, type GenerationConfig, type InlineDataPart,
  type LanguageModelExpected
} from 'firebase/ai';
import { z } from 'zod';
import {
  assistantResponseSchema, conceptsResponseSchema, constructionGuideSchema, generatedImageSchema,
  objectAnalysisSchema, projectCategories
} from '../../schemas/ai';
import type {
  AIOptions, AIResult, ConstructionGuide, GeneratedImage, IdeaBudget, InferenceEvent, InferenceTask,
  LocalAvailability, ObjectAnalysis, TransformationConcept
} from '../../types/ai';
import { firebaseCloudReady, getFirebaseApp } from '../firebase/client';
import { defaultFlags } from '../firebase/flags';
import { isHazardous, professionalHelp, projectSafetyPolicy, userFacingError, WorkshopAIError } from './policy';
import { quotaAvailable, recordInferenceEvent, reserveCloudRequest } from './telemetry';

export { clearInferenceEvents, getInferenceEvents, getQuotaUsage, subscribeInferenceEvents } from './telemetry';
export { WorkshopAIError } from './policy';

const stringValue = Schema.string();
const stringList = Schema.array({ items: stringValue });
const objectShape = Schema.object({
  properties: {
    name: stringValue, category: stringValue, materials: stringList, condition: stringValue, components: stringList,
    damage: stringList, potential: stringValue, safety: stringList,
    confidence: Schema.enumString({ enum: ['low', 'medium', 'high'] }), uncertainty: stringValue,
    hazardous: Schema.boolean()
  }
});
const conceptShape = Schema.object({
  properties: {
    title: stringValue, description: stringValue,
    difficulty: Schema.enumString({ enum: ['Beginner', 'Intermediate', 'Advanced'] }),
    duration: stringValue, costMin: Schema.number(), costMax: Schema.number(), currency: stringValue,
    category: Schema.enumString({ enum: [...projectCategories] }),
    materials: stringList, tools: stringList, benefits: stringList, limitations: stringList, safety: stringList
  }
});
const guideShape = Schema.object({
  properties: {
    overview: stringValue, originalObject: stringValue, transformation: stringValue, materials: stringList,
    tools: stringList, preparation: stringList,
    steps: Schema.array({ items: Schema.object({ properties: { title: stringValue, instructions: stringValue } }) }),
    finishing: stringList, safety: stringList, cost: stringValue, duration: stringValue,
    alternatives: stringList, maintenance: stringList
  }
});

const textInput: LanguageModelExpected = { type: 'text', languages: ['en'] };
const imageInput: LanguageModelExpected = { type: 'image' };
const localStatuses = ['available', 'downloadable', 'downloading', 'unavailable'];
const deviceOptions = (image: boolean) => ({
  expectedInputs: image ? [textInput, imageInput] : [textInput],
  expectedOutputs: [textInput]
});

function getPromptApi() {
  if (typeof window === 'undefined') return undefined;
  return (window as typeof window & {
    LanguageModel?: { availability(options: ReturnType<typeof deviceOptions>): Promise<string> };
  }).LanguageModel;
}

export async function getLocalAvailability(image = true): Promise<LocalAvailability> {
  try {
    const promptApi = getPromptApi();
    if (!promptApi) return 'unavailable';
    const availability = await promptApi.availability(deviceOptions(image));
    return localStatuses.includes(availability) ? availability as LocalAvailability : 'unknown';
  } catch {
    return 'unknown';
  }
}

const inputTypes = ['image/jpeg', 'image/png'];
const outputTypes = [...inputTypes, 'image/webp'];
const online = () => typeof navigator === 'undefined' || navigator.onLine !== false;

function checkPhoto(photo: Blob) {
  if (!inputTypes.includes(photo.type) || photo.size === 0 || photo.size > 8 * 1024 * 1024) {
    throw new WorkshopAIError('invalid-image', 'Choose a JPEG or PNG photo of up to 8 MB.');
  }
}

async function imagePart(photo: Blob): Promise<InlineDataPart> {
  const bytes = new Uint8Array(await photo.arrayBuffer());
  const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
  const isPng = pngSignature.every((value, index) => bytes[index] === value);
  if ((photo.type === 'image/jpeg' && !isJpeg) || (photo.type === 'image/png' && !isPng)) {
    throw new WorkshopAIError('invalid-image', 'The photo format does not match its file type. Export it again as JPEG or PNG.');
  }
  const buffer = [];
  for (let start = 0; start < bytes.length; start += 8192) {
    buffer.push(String.fromCharCode(...bytes.subarray(start, start + 8192)));
  }
  return { type: 'inlineData', inlineData: { mimeType: photo.type, data: btoa(buffer.join('')) } };
}

export function parseStructured<T>(value: string, validator: z.ZodType<T>): T {
  let decoded: unknown;
  try {
    const json = value.trim().replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, '$1');
    decoded = JSON.parse(json);
  } catch {
    throw new WorkshopAIError('invalid-response', 'The model returned incomplete project details. Try the request again.');
  }
  const parsed = validator.safeParse(decoded);
  if (!parsed.success) {
    throw new WorkshopAIError('invalid-response', 'The model returned project details in an unexpected format. Try again with simpler details.');
  }
  return parsed.data;
}

export function selectInferenceMode(
  options: AIOptions, cloudReady: boolean, isOnline: boolean, hasQuota: boolean, image = false
): InferenceMode {
  const cloudOnly = image || options.mode === 'cloud';
  if (cloudOnly) {
    if (options.mode === 'private' || !options.allowCloud) {
      throw new WorkshopAIError('consent-required', 'Enable cloud processing in Settings before using this feature.');
    }
    if (!isOnline) throw new WorkshopAIError('offline', 'Connect to the internet to use cloud AI.');
    if (!cloudReady) throw new WorkshopAIError('not-configured', 'Cloud AI needs a Firebase project and App Check setup.');
    if (!hasQuota) throw new WorkshopAIError('quota', 'This browser reached its daily cloud AI limit.');
    return InferenceMode.ONLY_IN_CLOUD;
  }
  if (options.mode === 'hybrid' && options.allowCloud && cloudReady && isOnline && hasQuota) {
    return InferenceMode.PREFER_ON_DEVICE;
  }
  return InferenceMode.ONLY_ON_DEVICE;
}

function requireApp() {
  const app = getFirebaseApp();
  if (!app) throw new WorkshopAIError('not-configured', 'Add the Firebase Web App configuration to use live AI. You can explore the example gallery in the meantime.');
  return app;
}

interface ModelCall<T> {
  task: InferenceTask;
  options: AIOptions;
  prompt: string;
  configuration: GenerationConfig;
  photo?: Blob;
  decode: (response: EnhancedGenerateContentResponse) => T;
}

async function execute<T>(call: ModelCall<T>): Promise<AIResult<T>> {
  if (call.photo) checkPhoto(call.photo);
  const app = requireApp();
  const image = call.task === 'image';
  const flags = call.options.flags ?? defaultFlags;
  const mode = selectInferenceMode(call.options, firebaseCloudReady, online(), quotaAvailable(flags, image), image);
  const localOnly = mode === InferenceMode.ONLY_ON_DEVICE;
  // Firebase 13.4.0 uses its cloud path when it cannot construct a browser
  // adapter. Refuse a local-only request before handing it to that SDK path.
  if (localOnly && typeof getPromptApi()?.availability !== 'function') {
    if (!online()) {
      throw new WorkshopAIError('offline-local-unavailable', 'The on-device model is unavailable offline. Reconnect and prepare it on supported Chrome desktop.');
    }
    throw new WorkshopAIError('local-unavailable', 'On-device AI requires supported Chrome desktop with the Gemini Nano Prompt API enabled.');
  }
  const cloudModel = image ? flags.cloudImageModel : flags.enableAdvancedCloudModels ? flags.cloudTextModel : defaultFlags.cloudTextModel;
  const service = getAI(app, { backend: new GoogleAIBackend(), useLimitedUseAppCheckTokens: true });
  const model: GenerativeModel = getGenerativeModel(service, {
    mode,
    inCloudParams: { model: cloudModel, generationConfig: call.configuration },
    onDeviceParams: mode === InferenceMode.ONLY_IN_CLOUD ? undefined : {
      createOptions: deviceOptions(Boolean(call.photo)),
      promptOptions: call.configuration.responseSchema ? { responseConstraint: call.configuration.responseSchema } : undefined
    }
  });

  // Start this before awaiting photo bytes to preserve Chrome's user activation.
  const deviceSetup = mode !== InferenceMode.ONLY_IN_CLOUD
    ? model.initializeDeviceModel(call.options.onDownloadProgress).then(() => undefined, (error: unknown) => error)
    : Promise.resolve(undefined);
  const request = call.photo ? [call.prompt, await imagePart(call.photo)] : call.prompt;

  if (localOnly) {
    if (!online() && await getLocalAvailability(Boolean(call.photo)) !== 'available') {
      throw new WorkshopAIError('offline-local-unavailable', 'The on-device model is unavailable offline. Reconnect and prepare it on supported Chrome desktop.');
    }
    const setupError = await deviceSetup;
    if (setupError) throw userFacingError(setupError, true);
    if (await getLocalAvailability(Boolean(call.photo)) !== 'available') {
      throw new WorkshopAIError('local-unavailable', 'Chrome is still preparing the on-device model or this device does not support the requested input.');
    }
  }

  let releaseQuota: (() => void) | undefined;
  if (!localOnly) {
    releaseQuota = reserveCloudRequest(flags, image);
    if (!releaseQuota) throw new WorkshopAIError('quota', 'This browser reached its daily cloud AI limit.');
  }

  const started = performance.now();
  const event: InferenceEvent = {
    id: crypto.randomUUID(), timestamp: new Date().toISOString(), task: call.task, mode: call.options.mode,
    source: 'unknown', latencyMs: 0, fallback: false, status: 'failed'
  };

  try {
    const { response } = await model.generateContent(request);
    event.latencyMs = Math.round(performance.now() - started);
    if (response.inferenceSource === InferenceSource.ON_DEVICE) {
      event.source = 'on-device';
      releaseQuota?.();
    } else if (response.inferenceSource === InferenceSource.IN_CLOUD) {
      event.source = 'cloud';
      event.fallback = mode === InferenceMode.PREFER_ON_DEVICE;
    }
    if (localOnly && event.source !== 'on-device') {
      throw new WorkshopAIError('unverified-source', 'The result could not be verified as on-device.');
    }
    if (event.source === 'cloud' && typeof model.model === 'string') {
      event.model = model.model.replace(/^models\//, '');
    }
    const data = call.decode(response);
    event.status = 'success';
    recordInferenceEvent(event);
    return { data, event };
  } catch (error) {
    event.latencyMs = Math.round(performance.now() - started);
    const friendly = userFacingError(error, localOnly);
    event.errorCode = friendly.code;
    recordInferenceEvent(event);
    throw friendly;
  }
}

function structured<T>(
  task: InferenceTask, instruction: string, options: AIOptions, responseSchema: Schema,
  validate: z.ZodType<T>, photo?: Blob, review?: (value: T) => void
) {
  return execute({
    task, options, photo,
    prompt: `${projectSafetyPolicy}\n\n${instruction}\nReturn JSON that conforms to the supplied schema.`,
    configuration: { responseMimeType: 'application/json', responseSchema, maxOutputTokens: 4096 },
    decode(response) {
      const result = parseStructured(response.text(), validate);
      review?.(result);
      return result;
    }
  });
}

export function analyzeObject(image: Blob, details: string, options: AIOptions): Promise<AIResult<ObjectAnalysis>> {
  return structured('analysis', [
    'Analyze the primary unwanted object visible in the photo. Describe visible condition, likely materials, damage, reusable components, and reuse potential.',
    'Mark hazardous true for suspected electrical, pressure, battery, structural, toxic, or otherwise dangerous items. Record reasons for uncertainty.',
    `User observations (may be inaccurate): ${JSON.stringify(details.slice(0, 1800))}`
  ].join(' '), options, objectShape, objectAnalysisSchema, image);
}

const safetyError = () => new WorkshopAIError('hazardous-object', professionalHelp);

export async function generateConcepts(
  input: ObjectAnalysis | string, options: AIOptions, budget?: IdeaBudget
): Promise<AIResult<TransformationConcept[]>> {
  const context = typeof input === 'string' ? input : JSON.stringify(input);
  const relevantDetails = typeof input === 'string' ? input : [input.name, input.category, ...input.materials, ...input.components].join(' ');
  if ((typeof input !== 'string' && input.hazardous) || isHazardous(relevantDetails)) throw safetyError();
  const currency = budget?.currency.toUpperCase() ?? 'AED';
  const maximum = budget?.maximum;
  if (!/^[A-Z]{3}$/.test(currency) || (maximum !== undefined && (!Number.isFinite(maximum) || maximum < 0))) {
    throw new WorkshopAIError('budget-invalid', 'Enter a non-negative budget and a three-letter currency code.');
  }
  const { data, event } = await structured('concepts', [
    'Propose exactly five distinct, practical concepts. Put the best match for available materials, tools, skill and budget first.',
    'Use owned materials before recommending purchases. Describe qualitative sustainability benefits and limitations.',
    `Use ${currency} for all costs. Prices are unverified estimates. ${maximum !== undefined ? `Keep each estimated maximum at or below ${maximum} ${currency}; make use of materials and tools already available.` : ''}`,
    `Project context: ${JSON.stringify(context.slice(0, 4200))}`
  ].join(' '), options, Schema.object({ properties: { concepts: Schema.array({ items: conceptShape, minItems: 5, maxItems: 5 }) } }), conceptsResponseSchema, undefined, ({ concepts }) => {
    if (concepts.some((concept) => concept.currency !== currency || (maximum !== undefined && concept.costMax > maximum))) {
      throw new WorkshopAIError('budget-response', 'The ideas did not match your budget or currency. Try again with additional details about the materials you already have.');
    }
    if (concepts.some((concept) => isHazardous(concept.title, concept.description, ...concept.materials))) throw safetyError();
  });
  return { data: data.concepts, event };
}

export async function generateGuide(concept: TransformationConcept, context: string, options: AIOptions): Promise<AIResult<ConstructionGuide>> {
  if (isHazardous(concept.title, concept.description, ...concept.materials, context)) throw safetyError();
  return structured('guide', [
    'Create a concise, practical construction guide with preparation, 3 to 8 numbered steps, finishing, safety, alternatives, and maintenance.',
    'Provide estimated costs and time. Treat all dimensions as estimates unless supplied by the user.',
    `Selected concept: ${JSON.stringify(concept)}. Object context: ${JSON.stringify(context.slice(0, 2000))}`
  ].join(' '), options, guideShape, constructionGuideSchema, undefined, (guide) => {
    if (isHazardous(guide.overview, guide.originalObject, guide.transformation, ...guide.preparation,
      ...guide.steps.map(({ title, instructions }) => `${title} ${instructions}`), ...guide.finishing, ...guide.maintenance)) throw safetyError();
  });
}

export async function askAssistant(prompt: string, context: string, options: AIOptions): Promise<AIResult<string>> {
  if (isHazardous(prompt, context)) throw safetyError();
  const { data, event } = await structured('assistant', [
    'Respond to this question about an upcycling project. Suggest practical refinements, substitutions, or cost reductions.',
    `Question: ${JSON.stringify(prompt.slice(0, 1500))}. Recent context summary: ${JSON.stringify(context.slice(-2500))}`
  ].join(' '), options, Schema.object({ properties: { reply: stringValue } }), assistantResponseSchema, undefined, ({ reply }) => {
    if (isHazardous(reply)) throw safetyError();
  });
  return { data: data.reply, event };
}

interface ImageRequest {
  concept: TransformationConcept;
  style: string;
  kind?: string;
  reference?: Blob;
}

export async function generateImage(input: ImageRequest, options: AIOptions, confirmed: boolean): Promise<AIResult<GeneratedImage>> {
  const flags = options.flags ?? defaultFlags;
  if (options.mode === 'private' || !options.allowCloud) {
    throw new WorkshopAIError('consent-required', 'Enable cloud processing to generate an image.');
  }
  if (!flags.enableImageGeneration) {
    throw new WorkshopAIError('image-disabled', 'Image generation is disabled for this Firebase project. You can continue with the construction guide.');
  }
  if (input.reference && !flags.enableImageEditing) {
    throw new WorkshopAIError('editing-disabled', 'Photo references are disabled for this Firebase project. Try generating from the concept description.');
  }
  if (!confirmed) throw new WorkshopAIError('billing-confirmation', 'Confirm the potentially billable image request to continue.');
  if (isHazardous(input.concept.title, input.concept.description, ...input.concept.materials)) throw safetyError();
  const kind = input.kind?.trim().slice(0, 90) || 'Transformation concept';
  const style = input.style.trim().slice(0, 90) || 'Minimalist';
  const prompt = [
    'Create one original AI-generated design visualization for a safe upcycling project.',
    `Render: ${JSON.stringify(kind)}. Style: ${JSON.stringify(style)}.`,
    `Selected concept: ${JSON.stringify(input.concept.title)}. Description: ${JSON.stringify(input.concept.description)}.`,
    `Reuse these materials: ${JSON.stringify(input.concept.materials)}.`,
    input.reference ? 'Preserve recognizable surface texture, proportions, and source materials where feasible.' : '',
    'Use clear framing. Treat any assembly illustration as conceptual, without technical dimensions or engineering claims.'
  ].join(' ');

  return execute({
    task: 'image', options, prompt, photo: input.reference,
    configuration: { responseModalities: [ResponseModality.IMAGE] },
    decode(response) {
      const image = response.inlineDataParts()?.find((part) => outputTypes.includes(part.inlineData.mimeType));
      if (!image) throw new WorkshopAIError('no-image', 'Firebase returned no image. Try a simpler visualization or continue with the guide.');
      const result = generatedImageSchema.safeParse({
        dataUrl: `data:${image.inlineData.mimeType};base64,${image.inlineData.data}`,
        timestamp: new Date().toISOString(), kind, style
      });
      if (!result.success) throw new WorkshopAIError('invalid-image-response', 'The generated image could not be validated.');
      return result.data;
    }
  });
}
