import { z } from 'zod';
import { inferenceEventSchema } from '../../schemas/ai';
import type { FeatureFlags, InferenceEvent } from '../../types/ai';

const historyKey = 'reimagine:inference-events';
const quotaKey = 'reimagine:ai-quota';
const quotaSchema = z.object({
  date: z.string(),
  cloudRequests: z.number().int().nonnegative(),
  imageGenerations: z.number().int().nonnegative()
});
const listeners = new Set<() => void>();

function read(key: string): unknown {
  try {
    return JSON.parse(localStorage.getItem(key) ?? 'null');
  } catch {
    return undefined;
  }
}

let memoryEvents: InferenceEvent[] | undefined;
let memoryQuota: z.infer<typeof quotaSchema> | undefined;

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

let cachedValue: unknown;
let cachedEvents: InferenceEvent[] = [];
export function getInferenceEvents(): InferenceEvent[] {
  if (memoryEvents) return memoryEvents;
  let raw: string | null = null;
  try {
    raw = localStorage.getItem(historyKey);
  } catch {
    return cachedEvents;
  }
  if (raw === cachedValue) return cachedEvents;
  cachedValue = raw;
  try {
    cachedEvents = inferenceEventSchema.array().parse(JSON.parse(raw ?? '[]'));
  } catch {
    cachedEvents = [];
  }
  return cachedEvents;
}

function notify() {
  for (const listener of listeners) listener();
}

export function subscribeInferenceEvents(listener: () => void) {
  listeners.add(listener);
  function onStorage(event: StorageEvent) {
    if (event.key === historyKey || event.key === quotaKey || event.key === null) listener();
  }
  if (typeof window !== 'undefined') window.addEventListener('storage', onStorage);
  return () => {
    listeners.delete(listener);
    if (typeof window !== 'undefined') window.removeEventListener('storage', onStorage);
  };
}

export function recordInferenceEvent(event: InferenceEvent) {
  const events = [inferenceEventSchema.parse(event), ...getInferenceEvents()].slice(0, 250);
  memoryEvents = write(historyKey, events) ? undefined : events;
  notify();
}

export function clearInferenceEvents() {
  memoryEvents = write(historyKey, []) ? undefined : [];
  notify();
}

function dailyQuota() {
  const date = new Date().toISOString().slice(0, 10);
  const parsed = quotaSchema.safeParse(memoryQuota ?? read(quotaKey));
  return parsed.success && parsed.data.date === date
    ? parsed.data
    : { date, cloudRequests: 0, imageGenerations: 0 };
}

export function getQuotaUsage() {
  const { cloudRequests, imageGenerations } = dailyQuota();
  return { cloudRequests, imageGenerations };
}

export function quotaAvailable(flags: FeatureFlags, image: boolean) {
  const usage = dailyQuota();
  return usage.cloudRequests < flags.maxCloudRequestsPerDay
    && (!image || usage.imageGenerations < flags.maxImageGenerationsPerDay);
}

// Reserve capacity before a potential cloud request. Release it only when supported
// response metadata confirms that the request ran on-device.
export function reserveCloudRequest(flags: FeatureFlags, image: boolean) {
  if (!quotaAvailable(flags, image)) return undefined;
  const usage = dailyQuota();
  const reserved = {
    ...usage,
    cloudRequests: usage.cloudRequests + 1,
    imageGenerations: usage.imageGenerations + Number(image)
  };
  memoryQuota = write(quotaKey, reserved) ? undefined : reserved;
  notify();
  let released = false;
  return () => {
    if (released) return;
    released = true;
    const latest = dailyQuota();
    if (latest.date !== reserved.date) return;
    const updated = {
      ...latest,
      cloudRequests: Math.max(0, latest.cloudRequests - 1),
      imageGenerations: Math.max(0, latest.imageGenerations - Number(image))
    };
    memoryQuota = write(quotaKey, updated) ? undefined : updated;
    notify();
  };
}
