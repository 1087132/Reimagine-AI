# Working on ReImagine AI

- Keep app code in `src` and static PWA assets in `public`. Build output belongs in the ignored `dist` directory.
- Use the modular Firebase Web SDK through `src/services/firebase` and `src/services/ai`. Verify model identifiers and SDK capabilities against official Firebase documentation before changing them.
- Preserve the private path. Private requests must use on-device-only inference. Projects created privately must stay out of cloud sync. Obtain consent before cloud processing of user data. Keep photographs, prompts, and model replies out of telemetry.
- Validate untrusted model output before rendering or saving it. Generated designs, costs, durations, and dimensions must carry their appropriate estimates and provenance. Keep unsafe modifications out of instructions.
- Keep the example gallery labeled. Record only real requests in AI Transparency.
- Use keyboard-accessible controls with visible focus, labeled forms, and meaningful status feedback. Check desktop and mobile layouts.
- Run unit checks and a production build before handing off. Use Playwright for user flows and the Emulator Suite for Firebase rules. Report credential-, billing-, and device-gated checks separately.
- Keep `.env.local`, App Check debug tokens, private credentials, and production secrets out of Git. Confirm the target project before invoking any publishing command.
