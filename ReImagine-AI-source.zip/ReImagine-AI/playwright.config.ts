import { env } from 'node:process'
import { defineConfig, devices } from '@playwright/test'

const output = 'node_modules/.cache/reimagine-e2e'
const baseURL = 'http://127.0.0.1:4173'

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  workers: 2,
  reporter: 'list',
  use: {
    baseURL,
    channel: env.PLAYWRIGHT_CHANNEL || undefined,
    trace: 'retain-on-failure',
  },
  projects: [{ name: 'desktop-chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: `npm run build -- --outDir ${output} && npm run preview -- --outDir ${output} --host 127.0.0.1 --port 4173 --strictPort`,
    url: baseURL,
    timeout: 120_000,
    env: {
      VITE_FIREBASE_API_KEY: '',
      VITE_FIREBASE_AUTH_DOMAIN: '',
      VITE_FIREBASE_PROJECT_ID: '',
      VITE_FIREBASE_APP_ID: '',
      VITE_FIREBASE_APP_CHECK_SITE_KEY: '',
      VITE_FIREBASE_USE_EMULATORS: 'false',
      VITE_FIREBASE_ENABLE_STORAGE: 'false',
    },
  },
})
