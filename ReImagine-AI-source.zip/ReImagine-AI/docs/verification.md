# Verification

Run commands from the repository root. Firebase emulator checks use an isolated `demo-reimagine` project. See the [Firebase setup guide](firebase-setup.md) for environment and evidence requirements.

| Area | Command or protocol |
| --- | --- |
| Response parsing, routing, quota, and local logic | `npm test` |
| Type checking and Vite production build | `npm run build` |
| Browser navigation, upload, examples, project persistence, PDF, comparison, mobile, accessibility and offline shell | `npm run test:e2e` |
| Email/password account flow and Firestore owner isolation | `npx firebase-tools@latest emulators:exec --project demo-reimagine --only auth,firestore "npm run test:rules"` |

## Results from the local build

| Check | Result |
| --- | --- |
| Vitest | 16 passed across AI routing, validation, quota and workshop logic. |
| TypeScript and Vite production build | Passed. Vite reports a size warning for the main client chunk. |
| Firebase Auth and Firestore emulators | 2 passed. Verified email/password registration, login and deletion, and owner-only access rules for workspace records. |
| Browser smoke test | Verified the responsive menu, JPEG upload, missing-Firebase error, keyboard comparison, construction checklist, image-bearing PDF download, and saved project after reload. With the preview server stopped, the cached shell and saved inventory item still loaded. |
| Playwright suite | Nine tests discovered. The macOS sandbox blocked Chromium startup before any test body ran. |
| Live Firebase models and providers | On-device Gemini Nano, real Hybrid fallback, live App Check, Google sign-in, live sync and Storage, and billable generation remain unverified. |

## Live acceptance checks

These need an authorized Firebase project and a secure local or deployed origin. Local-model checks also need an eligible physical device. Record the actual source, elapsed observation, and version and configuration in the test run.

| Check | Evidence to capture |
| --- | --- |
| Private mode on a supported device | Successful real JPEG/PNG request with at least one local event and no Firebase AI Logic inference network request. Repeat while offline after the model and app are cached. |
| Private mode on an unsupported device | Honest unavailable state. No fallback or Firebase AI Logic inference request. |
| Hybrid without cloud permission | No cloud AI request. |
| Hybrid with cloud permission and no on-device model | Real SDK cloud fallback result, with event source shown when exposed. |
| Cloud processing | Real configured App Check and model request. Declining local app consent avoids AI cloud transmission. |
| Image generation | Real generated image inside the comparison, labeled as a concept. Confirm fresh consent for an image request and handling of denied or unavailable model access. |
| Google sign-in and account deletion | Authorized-domain popup test, opt-in Firestore sync, cross-account isolation, deletion of account and data. |
| Quota response | A configured test project returns the actual error during approved testing, then local projects and the existing guide continue working. Local counter tests can be run without billing. |

Tests against Firebase AI Logic and Google sign-in are **unverified until run** in that environment. Local unit doubles support validation of control flow and errors. They cannot establish device or service capability.
