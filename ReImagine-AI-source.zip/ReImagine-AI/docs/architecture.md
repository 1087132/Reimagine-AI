# Architecture

ReImagine AI is a React and TypeScript progressive web app built with Vite. The browser handles photo framing, project editing, guide downloads, and the offline library. Data validation and inference live in shared modules so future native implementations can mirror the business rules and Firestore paths.

## Data flow

```mermaid
flowchart LR
    Photo[Camera or local file] --> Scan[Object scanner]
    Scan --> Gate[Mode, consent and availability]
    Gate --> SDK[Firebase AI Logic SDK]
    SDK --> Nano[Chrome Prompt API and Gemini Nano]
    SDK --> Cloud[Gemini Developer API through Firebase]
    Nano --> Schema[Validate AI result]
    Cloud --> Schema
    Schema --> Studio[Concepts and guide]
    Studio --> Local[(IndexedDB)]
    Studio --> PDF[PDF export]
    Local --> Sync[Optional authenticated sync]
    Sync --> Store[(Firestore and optional Storage)]
    SDK --> Events[Inference event metadata]
    Events --> Local
```

## Inference routing

| Mode | Routing | Consent |
| --- | --- | --- |
| Private | `InferenceMode.ONLY_ON_DEVICE` | Local processing only. Private projects stay on the device. |
| Hybrid | `InferenceMode.PREFER_ON_DEVICE` when cloud processing is allowed and available. Otherwise use an on-device-only request. | A user setting controls whether a request may be sent to the cloud. A local download may be needed before use. |
| Cloud | `InferenceMode.ONLY_IN_CLOUD` | Requires cloud permission, an accessible Firebase project and an online connection. Image generation also requires confirmation and operator enablement. |

Image generation uses the separately configured cloud image model. With editing enabled and explicit reference-photo permission, the app includes the original as input. Failed or unavailable image requests leave the saved project and text workflow usable.

The service validates output with Zod and renders uncertainty alongside observations. The design assistant uses bounded context in single-turn requests. Telemetry records operation, measured elapsed time, inference result, SDK source/model when available, and failure status. It excludes photos, prompts, and the content of results. A Hybrid setting alone cannot establish inference provenance. [Firebase hybrid inference](https://firebase.google.com/docs/ai-logic/hybrid)

## Persistence and trust

- IndexedDB stores user-created workspace data and image content on the current browser. The service worker caches the production app shell and its public assets. It does not cache Firebase API traffic.
- Guest users can explore examples and manage their own local workshop. Firebase Authentication identifies the account for optional cloud sync, and App Check attests access to protected services.
- Firestore documents are scoped under `users/{uid}`. Collections include `projects`, `inventory`, and `impact`, with `settings/preferences` available for settings. Inference statistics remain local. When Storage and media sync are enabled, owner-scoped paths support remote image attachments. Local photos are stored independently of Firebase Storage.
- User-recorded weights and savings feed impact views. Other values are totals or groupings derived from saved data. Budget and AI estimates are presented separately from recorded values.
- The project guide is an editable workflow generated from an idea and its safety context. PDF export is produced in the browser. Generated visuals illustrate concepts. User-provided measurements carry a different provenance from AI estimates.

## Deliberate deployment boundaries

Firebase Hosting serves the static application. The browser uses Firebase AI Logic’s built-in gateway. The operator chooses feature limits in Remote Config and configures billing and provider quotas in Google Cloud. The sample configuration keeps cloud sync, image generation, and image editing off until the operator enables them.

The PWA targets Web/Chrome. Native Android and iOS are future platform-specific implementations with their own local-model eligibility and App Check providers.
