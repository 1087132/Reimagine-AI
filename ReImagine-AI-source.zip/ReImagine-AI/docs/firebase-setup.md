# Firebase setup

Use a dedicated Firebase project you are authorized to configure. Keep the project ID consistent across the console, environment file, CLI, and App Check registration.

## Provision the web app and AI Logic

1. In the Firebase console, create or select the project and register a Web app in **Project settings**. Copy its Web SDK configuration into `.env.local`, using `.env.example` for the variable names.
2. Enable Firebase AI Logic with the **Gemini Developer API** provider. Use the Firebase console’s AI Logic setup or verify the target project and provision through the CLI.

   ```bash
   npx firebase-tools@latest login
   npx firebase-tools@latest projects:list
   npx firebase-tools@latest apps:list --project YOUR_PROJECT_ID
   npx firebase-tools@latest init ailogic --project YOUR_PROJECT_ID
   ```

3. Under **Authentication → Sign-in method**, enable Google and Email/Password. Set the Google support email. Add your Firebase Hosting host and any approved preview or localhost hosts in **Authentication → Settings → Authorized domains** as needed.
4. In **Firestore Database**, create the default database in the location approved for your users. Use the shipped rules. Create a Storage bucket only if remote attachments are required and the project is authorized for the applicable plan. Set its bucket name and opt in with `VITE_FIREBASE_ENABLE_STORAGE=true`.

[Firebase AI Logic setup](https://firebase.google.com/docs/ai-logic/get-started) · [Firebase Auth Web](https://firebase.google.com/docs/auth/web/start) · [Cloud Firestore setup](https://firebase.google.com/docs/firestore/quickstart) · [Cloud Storage setup](https://firebase.google.com/docs/storage/web/start)

### Optional Storage CORS

The browser downloads attachments through Firebase Storage’s authenticated SDK. Configure the bucket to accept GET requests from your approved web origins. Save the following as a local `cors.json`, replacing the example host, then apply it to the verified bucket. Include any approved staging origin you intend to use.

```json
[
  {
    "origin": ["https://YOUR_PROJECT_ID.web.app"],
    "method": ["GET"],
    "maxAgeSeconds": 3600
  }
]
```

```bash
gsutil cors set cors.json gs://YOUR_STORAGE_BUCKET
```

[Firebase Storage SDK downloads and CORS](https://firebase.google.com/docs/storage/web/download-files)

## App Check

1. Create a reCAPTCHA Enterprise score-based website key in the same Google Cloud project for the allowed hostnames. Register the Firebase Web app with that key in **App Check** and set `VITE_FIREBASE_APP_CHECK_SITE_KEY` to its public site key.
2. Use reCAPTCHA Enterprise in deployed builds. Register production and approved staging hostnames. Review metrics for Firestore and Storage before enabling those products’ enforcement. Firebase AI Logic enforces App Check.
3. For local development with a real project, set the development boolean `VITE_FIREBASE_APP_CHECK_DEBUG=true` and restart Vite. Register the SDK-generated browser console token in **App Check → Apps → Manage debug tokens**. Treat it as a secret. Use it in a private development browser and keep it outside Git, public instructions, videos, and deployed builds. Revoke it when testing is complete.

Keep service account credentials, billing credentials, Gemini API keys, and debug tokens out of `VITE_` variables and published source. The Firebase Web config and reCAPTCHA Enterprise site key are identifiers used by the client. Use appropriate API restrictions, Auth scopes, App Check, and rules to protect the project. [App Check on Web](https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider) · [Debug provider](https://firebase.google.com/docs/app-check/web/debug-provider) · [App Check for AI Logic](https://firebase.google.com/docs/ai-logic/app-check)

## Local Gemini Nano

1. Use a current supported **desktop** version of Google Chrome. Firebase’s web integration supports Chrome 139+ and requires a device that satisfies Chrome’s built-in AI requirements.
2. On HTTPS or localhost, check AI Transparency. If Chrome reports a downloadable model, allow it to finish while online. Use the official Prompt API troubleshooting steps if Chrome reports unavailable.
3. Select **Private** in Settings, upload a safe item such as a cardboard box, and run a scan. Verify the reported source on AI Transparency.
4. After the app shell has been cached and the model is available, repeat with the browser offline. On an unsupported device the app offers its offline library and labels the local AI limitation. Phone browsers can use the responsive UI, with cloud requests subject to consent.

[Firebase's Web hybrid guide](https://firebase.google.com/docs/ai-logic/hybrid/web/get-started) · [Chrome Prompt API requirements](https://developer.chrome.com/docs/ai/prompt-api)

## Remote Config and quotas

Create the following parameters in **Remote Config** using the listed types. Publish model and policy values only for your verified Firebase project.

| Parameter | Type | Local default |
| --- | --- | --- |
| `enableImageGeneration` | Boolean | `false` |
| `enableAdvancedCloudModels` | Boolean | `false` |
| `enableImageEditing` | Boolean | `false` |
| `enableCloudSync` | Boolean | `false` |
| `maxImageGenerationsPerDay` | Number | `2` |
| `maxCloudRequestsPerDay` | Number | `15` |
| `cloudTextModel` | String | `gemini-3.5-flash-lite` |
| `cloudImageModel` | String | `gemini-nano-banana-2.1` |

The text model override is used when `enableAdvancedCloudModels` is enabled. Keep image generation and editing off until the selected model and project have been tested with the approved billing or organizer-provisioned setup. The organizer’s optional four-day quota is tied to the approved account and period. The last application window in the published rules closed November 25, 2026 at 10 a.m. Pacific time. Confirm active allotment and its expiration before use. Core text inference uses a model listed as available without billing. [Official supported models](https://firebase.google.com/docs/ai-logic/models) · [Hackathon quota rules](https://firebasehybridaihackathon.devpost.com/rules)

Daily app counters are browser-side usability controls. Set project and model quotas with the Gemini Developer API and adjust the Firebase AI Logic per-user/per-region request quota in Google Cloud’s **Quotas & System Limits**. Review product usage in Firebase and enable appropriate billing budgets and alerts if billing is approved. Budget alerts send notifications and do not cap spending. Use feature switches and service quotas to limit exposure. [Firebase AI Logic rate limits](https://firebase.google.com/docs/ai-logic/quotas) · [Google Cloud budgets](https://cloud.google.com/billing/docs/how-to/budgets)

## Local emulators

For isolated security tests install a supported Firebase CLI and a Java version compatible with the Firestore emulator. The repository uses Auth port 9099, Firestore port 8080, and optional Storage port 9199.

```bash
npx firebase-tools@latest emulators:exec --project demo-reimagine --only auth,firestore "npm run test:rules"
```

To use a running local suite with Vite, set `VITE_FIREBASE_USE_EMULATORS=true` in your local development environment and run Vite in development mode. The app supplies dummy Web configuration for the default demo project. For optional Storage emulation, include `storage` in `--only` and enable its application flag. App Check, Remote Config, and Firebase AI Logic have no equivalent in this emulator workflow. Switch back to a genuine, configured project for live integration checks. [Firebase Emulator Suite](https://firebase.google.com/docs/emulator-suite/install_and_configure)

## Firebase Hosting

The included `firebase.json` serves `dist` and rewrites application routes to the React entry point. Build with the intended Web config and verify the project ID before deploying.

```bash
npm ci
npm run build
npx firebase-tools@latest projects:list
npx firebase-tools@latest deploy --project YOUR_PROJECT_ID --only firestore:rules,firestore:indexes
npx firebase-tools@latest deploy --project YOUR_PROJECT_ID --only hosting
```

With a configured Storage bucket, also deploy its security rules:

```bash
npx firebase-tools@latest deploy --project YOUR_PROJECT_ID --only storage
```

For an authorized staging project, use `hosting:channel:deploy` with an explicit `--project` and expiration. A preview URL uses its selected project’s backend resources, so choose a dedicated staging project for isolated testing. Check the hosted app shell, account flows, live AI, and privacy behavior on the exact final host before sharing. [Firebase Hosting](https://firebase.google.com/docs/hosting/quickstart) · [Hosting preview channels](https://firebase.google.com/docs/hosting/test-preview-deploy)
