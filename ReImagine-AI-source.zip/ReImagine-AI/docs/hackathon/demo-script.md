# Three-minute demonstration script

Record an eligible Chrome device with a downloaded local model. Use a non-sensitive photo of an ordinary cardboard box, plain jar, or bare wood. Verify local text and the optional cloud image request in advance using the configuration that will be disclosed to judges. Use a previously generated concept only if you identify it as a prior result and can reproduce the live path. Keep the final cut within 3:00.

| Timestamp | Screen | Voiceover |
| --- | --- | --- |
| 0:00–0:18 | Show the object on a workbench, then the dashboard. | “This box was headed for recycling. It’s also my next desk organizer. ReImagine AI helps me turn something I already own into a project I can finish.” |
| 0:18–0:50 | In Settings, select Hybrid and allow cloud processing for this demonstration. Upload the object on a Nano-capable device. Show the result and measured on-device source. | “A household photo can be sensitive. Here Gemini Nano reads the photo on this Chrome device through Firebase AI Logic. Private mode is available when I want my whole project to stay on this device.” |
| 0:50–1:18 | Open Transformation Studio. Select an idea that fits the object. Show difficulty, cost estimate, and household tools. | “I can choose an idea that fits my tools and budget. I’ll use the cardboard I have and finish the organizer with leftover fabric instead of buying materials.” |
| 1:18–1:52 | If enabled, open the Image Studio for the Hybrid project and confirm the optional cloud request. Drag the reveal slider and show the concept label. | “I’m choosing to request a cloud visual. It lets me check the design before I cut anything. Here’s the original, and here’s the AI concept.” |
| 1:52–2:18 | Open the guide. Check off a step, export the PDF, and save the project. | “The guide turns the idea into a materials checklist and a sequence I can take to the workbench. I can save it, record what I’ve completed, and download it with the images I choose.” |
| 2:18–2:40 | Show two or three items in Rescue Mode. Present the recommended use generated during the run. | “Rescue Mode takes several items I planned to discard and looks for a useful way to combine them.” |
| 2:40–2:59 | Reopen a saved project offline, then close on the project library. | “The saved workshop still opens offline. Local analysis keeps private photos on my device, and cloud inference extends the workflow when I choose it. Don’t throw it away. ReImagine it.” |

If the deployment cannot access image generation, use the 1:18–1:52 segment to show a real, consented Hybrid fallback on an unsupported device. Show the resulting cloud label and keep the cloud image control visibly disabled. For a labeled example preview, explain that it is example material.
