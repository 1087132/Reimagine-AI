# Submission checklist

Review the official rules before entering. The submission deadline is **November 30, 2026 at 2:00 p.m. PST**, or **December 1, 2026 at 2:00 a.m. in Dubai**. The judging period is December 10–16, 2026 Pacific time. [Official Devpost rules](https://firebasehybridaihackathon.devpost.com/rules)

- [ ] Confirm entrant eligibility, register the team, and select Web/Chrome.
- [ ] Run a real Private scan on eligible desktop Chrome. Verify source in AI Transparency and confirm that a Private request generates no cloud inference. Repeat with the cached app offline.
- [ ] Run a real Hybrid fallback on an unsupported device with cloud permission. Verify that the UI reports the SDK-observed source.
- [ ] Verify App Check, sign-in, approved cloud sync, rules, and deletion against the intended environment.
- [ ] If optional paid access is approved, verify generation and reference-photo editing. Confirm quota and billing protections. Recheck image availability after any temporary quota expires.
- [ ] Build, run the app and emulator suites, and review the verification matrix. Record remaining limitations accurately.
- [ ] Publish the approved repository to public GitHub or GitLab. Ensure it includes runnable source, assets, installation instructions, and a detectable open-source license. Review Git history for secrets and include any required asset attribution. Disclose the appropriate pre-existing material.
- [ ] Deploy to the approved Firebase project. Open the exact judge URL in a fresh browser profile. Provide free, working access through the judging period. If private access is necessary, supply dedicated test instructions without production secrets or personal data.
- [ ] Record live Web/Chrome footage. Upload an English video or a video with English subtitles, at most three minutes, publicly on YouTube.
- [ ] Complete the Devpost text description and describe the work built during the submission window. Include the repository, judge access, and video links. Submit before the deadline.
