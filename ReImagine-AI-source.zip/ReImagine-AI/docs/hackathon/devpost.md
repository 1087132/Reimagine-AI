# Devpost description

**One-line pitch**  
Turn things you’d throw away into projects you can actually finish.

## Inspiration

Imagine clearing out your home and finding a jar with no lid, a board too short for the old shelf, and leftover fabric. Each may have years of useful life left. We wanted to help people see the next use in the objects and tools they already have.

## What it does

Photograph an unwanted item. ReImagine AI describes its visible condition, suggests likely materials, and helps you explore upcycling ideas at different skill levels and budgets. Pick a design to get a construction checklist and downloadable guide. When cloud imagery is available, you can request a labeled AI concept and compare it with the original photograph. Rescue Mode brings several surplus objects together into a single plan. A material inventory, editable budget, and impact dashboard keep track of what you use and finish.

## How we built it

We built the Web/Chrome PWA with React, TypeScript, and the Firebase JavaScript SDK. Firebase AI Logic gives us two capabilities in the same scanning workflow. Gemini Nano can process a household photo on an eligible device, including when a previously cached app and ready model are offline. On devices without a local model, consented SDK fallback makes the workflow accessible through a Gemini cloud model. An optional cloud image model previews transformations. AI Transparency shows observed routing and measured latency.

App Check protects AI Logic access. Authentication and owner-scoped Firestore support optional sync, with Remote Config managing service availability, model selection, and client-side counters. IndexedDB keeps projects accessible in a local workshop.

## What we built during the submission period

We built the Web application and its scanning, concept, guide, project, material inventory, Rescue Mode, budget, and impact flows. We built the Firebase service boundary, privacy controls, and offline app shell alongside the UI. This entry uses open-source frontend dependencies and AI-assisted coding tools.

## What’s next

Test local inference on a broader range of eligible devices and build separate native clients. Improve household material tracking with more consistent user measurements. Expand the real-world project library with clearly documented material and tool requirements.

## Submission fields to complete

- Platform group: Web/Chrome
- Public source: enter the published GitHub or GitLab URL
- Try it: enter the verified Firebase Hosting URL and any judge access instructions
- Video: enter the public YouTube URL after recording actual behavior
