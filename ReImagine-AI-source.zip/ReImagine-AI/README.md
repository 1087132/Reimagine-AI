# ReImagine AI

**Don’t throw it away. ReImagine it.**

ReImagine AI is a web studio for turning unwanted household items into practical projects. Start with a photograph, choose an upcycling concept, and work through a construction guide. Keep a local material inventory and turn several would-be discards into a single project in Rescue Mode.

The application uses Firebase AI Logic for image understanding and project planning. On compatible desktop Chrome devices, Gemini Nano can handle a private scan even when the internet is unavailable. With permission, Hybrid mode can fall back to a cloud text model. The optional cloud image studio turns a selected idea into an explicitly labeled visual concept.

## Quick start

Use Node.js 22.12+ or 24 LTS and npm. From the project directory, run:

```bash
npm ci
npm run dev
```

Open the local URL printed by Vite. Guest mode and the labeled example gallery work without Firebase credentials. Add your own development Firebase project to run live inference, sign in, or test cloud sync. [Firebase setup](docs/firebase-setup.md)

```bash
npm test
npm run build
npm run preview
npx playwright install chromium
npm run test:e2e
```

The production preview enables the service worker. Use it once online, then revisit the app with the same browser profile while offline. Browser storage is specific to the origin, so localhost, a preview URL, and the public URL retain separate projects. Use Chrome’s Install option when available, or bookmark the site. Camera access requires HTTPS or a trusted localhost origin and browser permission.

## Start a project

1. Open **Object Scanner**, choose a camera capture or a JPEG/PNG, and optionally frame the object or add notes.
2. Select an inference mode in **Settings**. For a fully local request, choose **Private** and wait for the supported Chrome model to become ready.
3. Scan the object and review the AI’s uncertainty and any safety concerns. Choose one of the transformation ideas.
4. Generate an optional cloud concept only after reading the confirmation. Use the before-and-after viewer to inspect it.
5. Review the construction guide, save the project, and export a PDF. Use the inventory and budget planner to track what you own and what you still need.

Try a labeled example when live AI is unavailable. AI plans and concept images are starting points. Measure your materials and check the condition of the object and the suitability of its intended use before building.

## Example assets

The workshop hero and the before-and-after gallery panels were created specifically for ReImagine AI with OpenAI ImageGen. Gallery panels illustrate a wooden caddy becoming an herb garden and jam jars becoming a propagation station. The examples include authored project instructions and are tagged in the interface as preloaded examples. Live Firebase generations carry their own concept label.

## Project documentation

- [Architecture and data flow](docs/architecture.md)
- [Firebase, Chrome, quotas, emulators, and Hosting](docs/firebase-setup.md)
- [Verification matrix](docs/verification.md)
- [Hackathon materials and judge instructions](docs/hackathon/README.md)
- [Apache License 2.0](LICENSE)
