import { randomUUID } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import assert from 'node:assert/strict'
import { test } from 'node:test'
import { assertFails, assertSucceeds, initializeTestEnvironment } from '@firebase/rules-unit-testing'
import { deleteApp, initializeApp } from 'firebase/app'
import {
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  deleteUser,
  getAuth,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth'
import { collection, deleteDoc, doc, getDoc, getDocs, setDoc, updateDoc } from 'firebase/firestore'

const projectId = 'demo-reimagine'
const firestoreHost = process.env.FIRESTORE_EMULATOR_HOST
const authHost = process.env.FIREBASE_AUTH_EMULATOR_HOST
const localEmulator = /^(127\.0\.0\.1|localhost|\[::1\]):\d+$/

function requireLocalHost(host) {
  assert.match(host, localEmulator, 'This suite must use a loopback emulator.')
}

test('Firestore permits only the signed-in owner to read and modify workspace documents', {
  skip: !firestoreHost && 'Start the Firestore emulator to run rules tests.',
}, async () => {
  requireLocalHost(firestoreHost)
  const rules = await readFile(new URL('../firestore.rules', import.meta.url), 'utf8')
  const suite = await initializeTestEnvironment({ projectId, firestore: { rules } })
  try {
    const uid = 'owner-' + randomUUID()
    const owner = suite.authenticatedContext(uid).firestore()
    const stranger = suite.authenticatedContext('other-' + randomUUID()).firestore()
    const guest = suite.unauthenticatedContext().firestore()

    const basePath = 'users/' + uid + '/projects'
    const id = 'workbench-organizer'
    const projectPath = basePath + '/' + id
    const project = doc(owner, projectPath)
    const date = new Date().toISOString()
    const record = { id, title: 'Workbench organizer', updatedAt: date, private: false }

    await assertSucceeds(setDoc(project, record))
    await assertSucceeds(updateDoc(project, { title: 'Desk organizer' }))
    const read = await assertSucceeds(getDoc(project))
    assert.equal(read.get('title'), 'Desk organizer')
    await assertSucceeds(getDocs(collection(owner, basePath)))

    const strangerProject = doc(stranger, projectPath)
    await assertFails(getDoc(strangerProject))
    await assertFails(getDocs(collection(stranger, basePath)))
    await assertFails(setDoc(strangerProject, record))
    await assertFails(deleteDoc(strangerProject))
    await assertFails(getDoc(doc(guest, projectPath)))
    await assertFails(setDoc(doc(owner, 'users/' + uid + '/unknown/record'), record))
    await assertFails(updateDoc(project, { private: true }))
    await assertFails(setDoc(doc(owner, basePath + '/different-id'), record))

    await assertSucceeds(deleteDoc(project))
    assert.equal((await getDoc(project)).exists(), false)
  } finally {
    await suite.cleanup()
  }
})

test('Auth emulator handles registration, sign-out, sign-in and account deletion', {
  skip: !authHost && 'Start the Auth emulator to run this test.',
}, async () => {
  requireLocalHost(authHost)
  const app = initializeApp({
    projectId,
    apiKey: 'demo-reimagine-test',
    authDomain: projectId + '.firebaseapp.com',
  }, 'auth-rules-test')
  try {
    const auth = getAuth(app)
    connectAuthEmulator(auth, 'http://' + authHost, { disableWarnings: true })
    const email = randomUUID() + '@example.org'
    const password = 'LocalEmulator-Test42'
    const created = await createUserWithEmailAndPassword(auth, email, password)
    assert.equal(created.user.email, email)

    await signOut(auth)
    assert.equal(auth.currentUser, null)
    const session = await signInWithEmailAndPassword(auth, email, password)
    assert.equal(session.user.uid, created.user.uid)
    await deleteUser(session.user)
    assert.equal(auth.currentUser, null)
    await assert.rejects(() => signInWithEmailAndPassword(auth, email, password), /auth\//)
  } finally {
    await deleteApp(app)
  }
})
