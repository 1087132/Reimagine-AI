import { readFile } from 'node:fs/promises'
import { expect, test, type Page } from '@playwright/test'
import AxeBuilder from '@axe-core/playwright'

const jpeg = {
  name: 'box.jpg',
  mimeType: 'image/jpeg',
  buffer: await readFile(new URL('../../public/images/herb-before.jpg', import.meta.url)),
}

async function openExample(page: Page) {
  await page.goto('/')
  const example = page.getByRole('article').filter({ hasText: 'Windowsill Herb Garden' })
  await example.getByRole('button', { name: 'Open example' }).click()
}

test('studio opens without Firebase and displays its labeled example library', async ({ page }) => {
  await page.goto('/')
  await expect(page).toHaveTitle(/ReImagine AI/i)
  await expect(page.getByText(/Windowsill Herb Garden/i).first()).toBeVisible()
  await expect(page.getByText(/examples/i).first()).toBeVisible()
  await page.getByRole('link', { name: 'Object Scanner', exact: true }).click()
  await expect(page.getByRole('heading', { name: /Object Scanner/i })).toBeVisible()
})

test('scanner rejects a text file and a mislabeled image, then previews a JPEG', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('link', { name: 'Object Scanner', exact: true }).click()
  const file = page.getByLabel('Upload an image')
  await file.setInputFiles({ name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('hello') })
  await expect(page.getByRole('alert')).toContainText(/JPEG|PNG/i)

  await file.setInputFiles({ name: 'invalid.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('hello') })
  await expect(page.getByRole('alert')).toContainText(/image|photo|JPEG/i)

  await file.setInputFiles(jpeg)
  const preview = page.getByRole('img', { name: 'Object photo preview' })
  await expect(preview).toBeVisible()
  await expect.poll(() => preview.evaluate((image: HTMLImageElement) => image.naturalWidth)).toBeGreaterThan(0)
  await expect(page.getByRole('alert')).toHaveCount(0)

  const requestURLs: string[] = []
  page.on('request', request => requestURLs.push(request.url()))
  await expect(page.getByText('On-device processing only')).toBeVisible()
  await page.getByRole('button', { name: 'Analyze object' }).click()
  await expect(page.getByRole('alert')).toContainText(/Firebase|on-device model|local model/i)
  expect(requestURLs.filter(url => new URL(url).hostname.endsWith('.googleapis.com'))).toEqual([])
})

test('comparison is adjustable and supports keyboard-accessible fullscreen zoom', async ({ page }) => {
  await openExample(page)
  const slider = page.getByRole('slider', { name: 'Reveal after image' })
  await expect(slider).toBeVisible()
  const original = Number(await slider.inputValue())
  await slider.focus()
  await slider.press(original < 100 ? 'ArrowRight' : 'ArrowLeft')
  await expect.poll(() => slider.inputValue()).not.toBe(String(original))
  const keyboardValue = await slider.inputValue()
  const bounds = await slider.boundingBox()
  expect(bounds).not.toBeNull()
  await slider.click({ position: { x: bounds!.width * 0.2, y: bounds!.height * 0.5 } })
  await expect.poll(() => slider.inputValue()).not.toBe(keyboardValue)

  const fullscreen = page.getByRole('button', { name: 'Fullscreen', exact: true })
  await fullscreen.click()
  const dialog = page.getByRole('dialog', { name: 'Fullscreen comparison' })
  await expect(dialog).toBeVisible()
  await dialog.getByRole('button', { name: 'Zoom in' }).click()
  await expect(dialog.getByLabel('Zoom level')).toHaveText('125%')
  await page.keyboard.press('Escape')
  await expect(dialog).toHaveCount(0)
  await expect(fullscreen).toBeFocused()
})

test('example project guide downloads a PDF and project survives reload', async ({ page }) => {
  await openExample(page)
  await page.getByRole('link', { name: 'Construction Guide', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Construction Guide', exact: true })).toBeVisible()
  await page.getByRole('checkbox', { name: /Inspect and clean the caddy/ }).check()
  await expect(page.getByText('1 / 3 steps complete')).toBeVisible()
  await page.getByRole('checkbox', { name: 'Include original image' }).check()
  await page.getByRole('checkbox', { name: 'Include concept illustration' }).check()
  const downloadEvent = page.waitForEvent('download')
  await page.getByRole('button', { name: 'Download PDF' }).click()
  const pdf = await downloadEvent
  expect(pdf.suggestedFilename()).toMatch(/\.pdf$/i)
  const path = await pdf.path()
  const bytes = await readFile(path)
  expect(bytes.subarray(0, 5).toString()).toBe('%PDF-')
  expect(bytes.includes('/Subtype /Image')).toBe(true)

  await page.getByRole('button', { name: 'Save project' }).click()
  await expect(page.getByRole('status')).toContainText('Project saved')
  await page.getByRole('link', { name: 'My Projects', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Windowsill Herb Garden' })).toBeVisible()
  await page.reload()
  await expect(page.getByRole('heading', { name: 'Windowsill Herb Garden' })).toBeVisible()
})

test('material inventory persists across an offline reload', async ({ page, context, request }) => {
  await page.goto('/')
  const manifestLink = page.locator('link[rel="manifest"]')
  const manifestPath = await manifestLink.getAttribute('href')
  expect(manifestPath).toBeTruthy()
  const manifest = await request.get(manifestPath!)
  expect(manifest.ok()).toBe(true)
  expect(await manifest.json()).toMatchObject({ name: 'ReImagine AI', display: 'standalone' })

  await page.getByRole('link', { name: 'Material Inventory', exact: true }).click()
  await page.getByRole('button', { name: 'Add item' }).first().click()
  await page.getByRole('textbox', { name: 'Item name' }).fill('Cedar offcuts')
  await page.getByRole('spinbutton', { name: 'Quantity' }).fill('3')
  await page.getByRole('button', { name: 'Save item' }).click()
  await expect(page.getByRole('heading', { name: 'Cedar offcuts' })).toBeVisible()

  await expect.poll(() => page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true)
  await context.setOffline(true)
  await page.reload()
  await expect(page.getByRole('heading', { name: 'Cedar offcuts' })).toBeVisible()
  await expect(page.getByText(/offline/i).first()).toBeVisible()
})

test('private mode revokes cloud consent and guest mode is available without sign-in', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('link', { name: 'Settings & Privacy' }).click()
  const mode = page.getByLabel('Inference mode')
  const cloud = page.getByRole('checkbox', { name: 'Allow cloud AI processing' })
  await cloud.check()
  await mode.selectOption('private')
  await expect(cloud).toBeDisabled()
  await expect(cloud).not.toBeChecked()
  await expect(page.getByRole('checkbox', { name: 'Sync eligible projects and inventory' })).toBeDisabled()

  await page.getByLabel('Theme').selectOption('dark')
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
  await page.reload()
  await expect(mode).toHaveValue('private')
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')

  await page.getByRole('link', { name: 'Manage account', exact: true }).click()
  await expect(page.getByRole('button', { name: 'Continue with Google' })).toBeDisabled()
  await page.getByRole('link', { name: 'Continue as guest' }).click()
  await expect(page.getByRole('heading', { name: 'Your workshop' })).toBeVisible()
})

test('mobile shell fits and keyboard controls have usable accessible names', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto('/')
  await expect(page.getByRole('main')).toBeVisible()
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(1)
  await page.keyboard.press('Tab')
  await expect.poll(() => page.evaluate(() => document.activeElement?.tagName)).not.toBe('BODY')
  const menu = page.getByRole('button', { name: 'Open menu' })
  await menu.focus()
  await menu.press('Enter')
  await expect(page.getByRole('button', { name: 'Close menu' })).toHaveAttribute('aria-expanded', 'true')
  await page.keyboard.press('Escape')
  await expect(menu).toHaveAttribute('aria-expanded', 'false')

  const report = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()
  expect(report.violations.map(({ id, nodes }) => ({ id, targets: nodes.map(node => node.target) }))).toEqual([])
})
